package org.ponly.web.jsp.tags.form;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.DynamicAttributes;
import javax.servlet.jsp.tagext.TagSupport;
import java.util.HashMap;
import java.util.Map;

/**
 */
public abstract class HtmlElementTag extends TagSupport implements DynamicAttributes {
    private Map<String, Object> dynamicAttributes;

    @Override
    public int doStartTag() throws JspException {
        return super.doStartTag();
    }

    @Override
    public int doEndTag() throws JspException {
        return super.doEndTag();
    }

    /**
     * Get the map of dynamic attributes.
     */
    protected Map<String, Object> getDynamicAttributes() {
        return this.dynamicAttributes;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setDynamicAttribute(String uri, String localName, Object value) throws JspException {
        if (this.dynamicAttributes == null) {
            this.dynamicAttributes = new HashMap<String, Object>();
        }
        if (!isValidDynamicAttribute(localName, value)) {
            throw new IllegalArgumentException("Attribute " + localName + "=\"" + value + "\" is not allowed");
        }
        dynamicAttributes.put(localName, value);
    }

    /**
     * Whether the given name-value pair is a valid dynamic attribute.
     */
    protected boolean isValidDynamicAttribute(String localName, Object value) {
        return true;
    }
}
