package org.ponly.web.jsp.tags.form;

import org.springframework.util.StringUtils;
import org.springframework.web.servlet.tags.form.AbstractHtmlInputElementTag;
import org.springframework.web.servlet.tags.form.TagWriter;

import javax.servlet.jsp.JspException;

/**
 * 一个基于 <a href="http://www.my97.net" target="_blank">My97DatePicker</a> 实现的日期输入控件
 * <p>使用方式:<br>
 * &lt;ui:datepicker cssClass="input" path="endTime" format="yyyy-MM-dd" min="2099-12-31" minRef="startTime" max="2099-12-31" maxRef="maxTime" max="2099-12-31" /&gt
 * <p>生成代码: <br>
 * &lt;input type="text" id="endTime" name="endTime" class="Wdate input" onfocus="WdatePicker({dateFmt:'yyyy-MM-dd',minDate: '#F{$dp.$D(\'startTime\')||\'2099-12-31\'}',maxDate: '#F{$dp.$D(\'maxTime\')||\'2099-12-31\'}'});"&gt;
 *
 * @author vacoor
 */
public class DatePickerTag extends AbstractHtmlInputElementTag {
    private String format;      // 日期格式化字符串
    private String min;         // 最小日期
    private String max;         // 最大日期
    private String minRef;      // 最小日期引用
    private String maxRef;      // 最大日期引用

    @Override
    protected int writeTagContent(TagWriter tagWriter) throws JspException {
        String cssClass = getCssClass();
        if (StringUtils.hasText(cssClass)) {
            cssClass = "Wdate " + cssClass;
        } else {
            cssClass = "Wdate";
        }
        setCssClass(cssClass);
        StringBuilder buff = new StringBuilder();
        buff.append("WdatePicker({");
        buff.append("dateFmt:'").append(format).append("'");

        boolean hasMinRef = StringUtils.hasText(minRef);
        boolean hasMin = StringUtils.hasText(min);
        boolean hasMaxRef = StringUtils.hasText(maxRef);
        boolean hasMax = StringUtils.hasText(max);
        // 最小值
        if (hasMinRef || hasMin) {
            buff.append(",minDate: '#F{");
            if (hasMinRef) {
                buff.append("$dp.$D(\\'").append(minRef).append("\\')");
            }
            if (hasMin) {
                buff.append(hasMinRef ? "||" : "").append("\\'").append(min).append("\\'");
            }
            buff.append("}'");
        }
        // 最大值
        if (hasMaxRef || hasMax) {
            buff.append(",maxDate: '#F{");
            if (hasMaxRef) {
                buff.append("$dp.$D(\\'").append(maxRef).append("\\')");
            }
            if (hasMax) {
                buff.append(hasMaxRef ? "||" : "").append("\\'").append(max).append("\\'");
            }
            buff.append("}'");
        }

        buff.append("});");


        setOnfocus(buff.toString());

        tagWriter.startTag("input");
        this.writeDefaultAttributes(tagWriter);
        tagWriter.writeAttribute("type", "text");
        String value = this.getDisplayString(this.getBoundValue(), this.getPropertyEditor());
        tagWriter.writeAttribute("value", this.processFieldValue(this.getName(), value, "text"));
        tagWriter.endTag();

        return SKIP_BODY;
    }

    /**
     * 获取日期格式化字符串
     */
    public String getFormat() {
        return format;
    }

    /**
     * 设置日期格式化字符串
     */
    public void setFormat(String format) {
        this.format = format;
    }

    /**
     * 获取允许的最小日期
     */
    public String getMin() {
        return min;
    }

    /**
     * 设置允许的最小日期
     */
    public void setMin(String min) {
        this.min = min;
    }

    /**
     * 获取允许的最大的日期
     */
    public String getMax() {
        return max;
    }

    /**
     * 设置允许的最大的日期
     */
    public void setMax(String max) {
        this.max = max;
    }

    /**
     * 获取允许的最小日期参照元素ID
     */
    public String getMinRef() {
        return minRef;
    }

    /**
     * 设置允许最小日期参照元素ID
     */
    public void setMinRef(String minRef) {
        this.minRef = minRef;
    }

    /**
     * 获取允许的最大日期参照元素ID
     */
    public String getMaxRef() {
        return maxRef;
    }

    /**
     * 设置允许的最大日期参照元素ID
     */
    public void setMaxRef(String maxRef) {
        this.maxRef = maxRef;
    }
}
