package org.ponly.web.jsp.tags.form;

import org.springframework.web.servlet.tags.form.TagWriter;
import org.springframework.web.servlet.tags.form.TextareaTag;

import javax.servlet.jsp.JspException;

/**
 * @author vacoor
 */
public class RichEditorTag extends TextareaTag {
    @Override
    protected int writeTagContent(TagWriter tagWriter) throws JspException {
        String ctx = pageContext.getServletContext().getContextPath();
        String id = resolveId();
        int i = super.writeTagContent(tagWriter);

        tagWriter.startTag("script");
        tagWriter.writeAttribute("type", "text/javascript");
        tagWriter.appendValue("" +
                "                   require(['kindeditor', 'jquery'], function (K, $) {\n" +
                "                        //KindEditor.ready(function (K) {\n" +
                "                        K.create('#" + id + "', {\n" +
                "                            // basePath: '',\n" +
//                "                            width: 667,\n" +
//                "                            height: 280,\n" +
//                "                            minWidth: 667,\n" +
                "                            filterMode: false,\n" +
                "                            allowFileManager: false,\n" +
                "                            uploadJson: '" + ctx + "/storage/files/ul',\n" +
                "                            extraFileUploadParams: {},\n" +
                "                            filePostName: 'file',\n" +
                "                            afterCreate: function () {\n" +
                "                            },\n" +
                "                            afterChange: function () {\n" +
                "                                var el = this.srcElement.get(),\n" +
                "                                        validator = $(el.form).data('validator');\n" +
                "                                if (validator && validator.invalid[el.name]) {\n" +
                "                                    this.sync();\n" +
                "                                    validator.element(el);\n" +
                "                                }\n" +
                "                            },\n" +
                "                            afterFocus: function () {\n" +
                "                                var el = this.srcElement.get(),\n" +
                "                                        validator = $(el.form).data('validator');\n" +
                "                                if (validator) {\n" +
                "                                    validator.settings.onfocusin.call(validator, el);\n" +
                "                                }\n" +
                "                            },\n" +
                "                            afterBlur: function () {\n" +
                "                                var el = this.sync().srcElement.get(),\n" +
                "                                        validator = $(el.form).data('validator');\n" +
                "                                if (validator && validator.invalid[el.name]) {\n" +
                "                                    validator.element(el);\n" +
                "                                }\n" +
                "                            }\n" +
                "                        });\n" +
                "                    });");
        tagWriter.endTag(true);

        return i;
    }
}
