package org.ponly.web.jsp.tags.form;

import org.springframework.util.StringUtils;
import org.springframework.web.servlet.tags.form.AbstractHtmlElementTag;
import org.springframework.web.servlet.tags.form.TagWriter;

import javax.servlet.jsp.JspException;

/**
 */
public class Uploader2Tag extends AbstractHtmlElementTag {
    public static final String DEFAULT_ELEMENT = "span";
    private String element = DEFAULT_ELEMENT;
    // private String name;

    private String url;
    private String queueId;
    private String mode;
    private int maxFileCount;
    private String maxFileSize;
    private String uploadName;
    private String valueProp;
    private boolean autoStart = true;
    private String suffix;
    private String dropZoneId;
    private String baseUrl;

    private TagWriter tagWriter;

    @Override
    protected int writeTagContent(TagWriter tagWriter) throws JspException {
        tagWriter.startTag(element);
        // tagWriter.writeOptionalAttributeValue("name", name);
        writeDefaultAttributes(tagWriter);
         tagWriter.forceBlock();
        this.tagWriter = tagWriter;
        return EVAL_BODY_INCLUDE;
    }

    @Override
    public int doEndTag() throws JspException {
        String id = resolveId();
        tagWriter.endTag();

        tagWriter.startTag("script");
        tagWriter.writeAttribute("type", "text/javascript");
//        tagWriter.appendValue("$(function(){Uploader2({" +
        tagWriter.appendValue("require(['uploader2'], function(Uploader2){Uploader2({" +
                        "file_data_name: '" + getUploadName() + "'," +
                        // "url: undefined,\n" +
                        // "multi_selection: true,\n" +
                        "browse_button: '" + id + "',\n"
        );

        String url = getUrl();
        if (!StringUtils.hasText(url)) {
            String uname = getUploadName();
            String ctx = pageContext.getServletContext().getContextPath();
            if ("file".equals(uname)) {
                url = ctx + "/storage/files/ul";
            } else if ("img".equals(uname)) {
                url = ctx + "/storage/images/ul";
            } else {
                throw new JspException("url attribute must be not blank");
            }
        }
        tagWriter.appendValue("url:'" + url + "',");

        if (StringUtils.hasText(getName())) {
            tagWriter.appendValue("name: '" + getName() + "',");
        }
        if (StringUtils.hasText(getQueueId())) {
            tagWriter.appendValue("list: '" + getQueueId() + "',\n");
        }
        if (StringUtils.hasText(getSuffix())) {
            tagWriter.appendValue("filters: {mime_types: [{title: 'Allowd Files', extensions: '" + getSuffix() + "'}]},\n");
        }
        if (StringUtils.hasText(getMode())) {
            tagWriter.appendValue("mode: '" + getMode() + "',\n");
        }

        tagWriter.appendValue(
                // "browse_button_active: 'active',\n" +
                // "browse_button_hover: 'hover',\n" +
                        "max_file_count: '" + getMaxFileCount() + "',\n" +
                        "auto: " + isAutoStart() + ",\n"
        );

        String maxFileSize = getMaxFileSize();
        String valueProp = getValueProp();
        String baseUrl = getBaseUrl();
        if (null != maxFileSize) {
            tagWriter.appendValue("max_file_size: '" + getMaxFileSize() + "',\n");
        }
        if (null != valueProp) {
            tagWriter.appendValue("value: '" + getValueProp() + "',\n");
        }
        if (null != baseUrl) {
            tagWriter.appendValue("baseUrl: '" + baseUrl + "',\n");
        }
        tagWriter.appendValue("drop_element: '" + getDropZoneId() + "'\n");
        tagWriter.appendValue("});});");
        tagWriter.endTag(true);

        return EVAL_PAGE;
    }

    @Override
    public void doFinally() {
        super.doFinally();
        tagWriter = null;
        element = DEFAULT_ELEMENT;
        queueId = null;
        mode = null;
        maxFileCount = 0;
        maxFileSize = null;
        uploadName = null;
        valueProp = null;
        autoStart = true;
        suffix = null;
        dropZoneId = null;

    }

    public String getElement() {
        return element;
    }

    public void setElement(String element) {
        this.element = element;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getQueueId() {
        return queueId;
    }

    public void setQueueId(String queueId) {
        this.queueId = queueId;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public int getMaxFileCount() {
        return maxFileCount;
    }

    public void setMaxFileCount(int maxFileCount) {
        this.maxFileCount = maxFileCount;
    }

    public String getMaxFileSize() {
        return maxFileSize;
    }

    public void setMaxFileSize(String maxFileSize) {
        this.maxFileSize = maxFileSize;
    }

    public String getUploadName() {
        return uploadName;
    }

    public void setUploadName(String uploadName) {
        this.uploadName = uploadName;
    }

    public String getValueProp() {
        return valueProp;
    }

    public void setValueProp(String valueProp) {
        this.valueProp = valueProp;
    }

    public boolean isAutoStart() {
        return autoStart;
    }

    public void setAutoStart(boolean autoStart) {
        this.autoStart = autoStart;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getDropZoneId() {
        return dropZoneId;
    }

    public void setDropZoneId(String dropZoneId) {
        this.dropZoneId = dropZoneId;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }
}
