package org.ponly.web.jsp.tags.form;

import org.springframework.web.servlet.tags.form.AbstractHtmlInputElementTag;
import org.springframework.web.servlet.tags.form.TagWriter;

import javax.servlet.jsp.JspException;

/**
 * 数字输入器
 * <p/>当前只支持整数
 * <p/>使用:<br/>
 * &lt;ui:spinner path="position" cssClass="input ni" max="100" min="1" step="1" allowEmpty="true" /&gt;
 * <p/>生成:<br/>
 * <pre>
 * &lt;span id="position-spinner" class="spinner"&gt;
 *    &lt;input id="position" name="position" class="input ni" value=""&gt;
 *    &lt;span class="spin-buttons"&gt;
 *       &lt;span class="btn-up"&gt;&lt;/span&gt;
 *       &lt;span class="btn-down"&gt;&lt;/span&gt;
 *    &lt;/span&gt;
 *    &lt;script type="text/javascript"&gt;
 *    (function () {
 *       $('#position-spinner').spinner({
 *          max: 100
 *         ,min: 0
 *         ,step: 1
 *         ,allowEmpty: true
 *         ,minusBtn: '.btn-down'
 *         ,plusBtn: '.btn-up'
 *      });
 *    })();&lt;/script&gt;
 * &lt;/span&gt;
 * </pre>
 *
 * @author vacoor
 */
public class SpinnerTag extends AbstractHtmlInputElementTag {
    private int max = Integer.MAX_VALUE;    // 允许的最大值
    private int min = 0;                    // 允许的最小值
    private int step = 1;                   // 步进量
    private boolean allowEmpty = true;      // 是否允许空白

    @Override
    public void release() {
        super.release();
        max = Integer.MAX_VALUE;
        min = 0;
        step = 1;
        allowEmpty = true;
    }

    @Override
    protected int writeTagContent(TagWriter tagWriter) throws JspException {
        String id = resolveId();
        tagWriter.startTag("span");
        tagWriter.writeAttribute("id", id + "-spinner");
        tagWriter.writeAttribute("class", "spinner");

        tagWriter.startTag("input");
        writeDefaultAttributes(tagWriter);
        writeOptionalAttributes(tagWriter);

        String value = this.getDisplayString(this.getBoundValue(), this.getPropertyEditor());
        tagWriter.writeAttribute("value", this.processFieldValue(this.getName(), value, "text"));
        tagWriter.endTag();

        tagWriter.startTag("span");
        tagWriter.writeAttribute("class", "spin-buttons");

        tagWriter.startTag("span");
        tagWriter.writeAttribute("class", "btn-up");
        tagWriter.endTag(true);

        tagWriter.startTag("span");
        tagWriter.writeAttribute("class", "btn-down");
        tagWriter.endTag(true);

        tagWriter.endTag(true);

        tagWriter.startTag("script");
        tagWriter.writeAttribute("type", "text/javascript");
        tagWriter.appendValue("" +
                "require(['spinner'], function (Spinner) {\n" +
                //"(function () {\n" +
                "            $('#" + id + "-spinner').spinner({\n" +
                "                     max: " + getMax() + "\n" +
                "                    ,min: " + getMin() + "\n" +
                "                    ,step: " + getStep() + "\n" +
                "                    ,allowEmpty: " + isAllowEmpty() + "\n" +
                "                    ,minusBtn: '.btn-down'\n" +
                "                    ,plusBtn: '.btn-up'\n" +
                "            });\n" +
                // "        })();");
                "        });");
        tagWriter.endTag(true);

        tagWriter.endTag(true);

        return SKIP_BODY;
    }

    /**
     * 获取允许的最大值
     */
    public int getMax() {
        return max;
    }

    /**
     * 设置允许的最大值
     *
     * @param max 允许的最大值
     */
    public void setMax(int max) {
        this.max = max;
    }

    /**
     * 获取允许的最小值
     */
    public int getMin() {
        return min;
    }

    /**
     * 设置允许的最小值
     *
     * @param min 允许的最小值
     */
    public void setMin(int min) {
        this.min = min;
    }

    /**
     * 获取当前步进量
     */
    public int getStep() {
        return step;
    }

    /**
     * 设置步进量
     *
     * @param step 步进量
     */
    public void setStep(int step) {
        this.step = step;
    }

    /**
     * 返回当前是否允许空白
     */
    public boolean isAllowEmpty() {
        return allowEmpty;
    }

    /**
     * 设置当前是否允许空白
     *
     * @param allowEmpty 是否允许空白
     */
    public void setAllowEmpty(boolean allowEmpty) {
        this.allowEmpty = allowEmpty;
    }
}
