package org.ponly.web.jsp.tags.form;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.tags.form.AbstractHtmlElementTag;
import org.springframework.web.servlet.tags.form.TagWriter;

import javax.servlet.jsp.JspException;

/**
 */
public class TreePickerTag extends AbstractHtmlElementTag {
    private String url;
    private String rootNodeParam = "";
    private String nodeParam = "id";
    private String rootId;
    private String rootProp = "data";
    private String textProp = "name";
    private String valueProp = "id";
    private boolean multiple;

    @Override
    protected int writeTagContent(TagWriter tagWriter) throws JspException {

        tagWriter.startTag("input");
        this.writeDefaultAttributes(tagWriter);
        tagWriter.writeAttribute("type", "hidden");

        String id = this.resolveId();
        Object valueObj = getBindStatus().getActualValue();
        if (null != valueObj) {
            BeanWrapper bean = PropertyAccessorFactory.forBeanPropertyAccess(getBindStatus().getActualValue());
            // String value = this.getDisplayString(this.getBoundValue(), this.getPropertyEditor());
            String value = getDisplayString(bean.getPropertyValue(valueProp));
            String text = getDisplayString(bean.getPropertyValue(textProp));

            tagWriter.writeAttribute("value", this.processFieldValue(this.getName(), value, "hidden"));
            tagWriter.writeAttribute("data-text", text);
        }

        tagWriter.endTag();


        tagWriter.startTag("script");
        tagWriter.writeAttribute("type", "text/javascript");
        tagWriter.appendValue("" +
                         "require(['treepicker'], function () {\n" +
                        // "(function () {\n" +
                        "            $('#" + id + "').treepicker({\n" +
                        "                    multiple: " + multiple + "\n" +
                        "                    ,rootProp: '" + rootProp + "'\n" +
                        "                    ,valueProp: '" + valueProp + "'\n" +
                        "                    ,textProp: '" + textProp + "'\n" +
                        "                    ,nodeParam: '" + nodeParam + "'\n" +
                        "                    ,rootId: '" + (null != rootId ? rootId : "") + "'\n" +
                        "                    ,data: '" + url + "'\n"
        );
        if (StringUtils.hasText(rootNodeParam)) {
            tagWriter.appendValue("" +
                            "                    ,extraParams: function(node) {\n" +
                            "                       var params = {};\n" +
                            "                       if ('#' == node.id) {\n" +
                            "                          params['" + rootNodeParam + "'] = '" + rootId + "';\n" +
                            "                       }\n" +
                            "                       return params;\n" +
                            "                   }\n"
            );
        }
        tagWriter.appendValue("" +
                "            });\n" +
                 "        });");
//                "        })();");
        tagWriter.endTag(true);

        return SKIP_BODY;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNodeParam() {
        return nodeParam;
    }

    public void setNodeParam(String nodeParam) {
        this.nodeParam = nodeParam;
    }

    public String getRootId() {
        return rootId;
    }

    public void setRootId(String rootId) {
        this.rootId = rootId;
    }

    public String getRootProp() {
        return rootProp;
    }

    public void setRootProp(String rootProp) {
        this.rootProp = rootProp;
    }

    public String getTextProp() {
        return textProp;
    }

    public void setTextProp(String textProp) {
        this.textProp = textProp;
    }

    public String getValueProp() {
        return valueProp;
    }

    public void setValueProp(String valueProp) {
        this.valueProp = valueProp;
    }

    public boolean isMultiple() {
        return multiple;
    }

    public void setMultiple(boolean multiple) {
        this.multiple = multiple;
    }

    public String getRootNodeParam() {
        return rootNodeParam;
    }

    public void setRootNodeParam(String rootNodeParam) {
        this.rootNodeParam = rootNodeParam;
    }
}
