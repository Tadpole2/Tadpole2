/**
 * 用于在jsp中实现"类"的继承关系,
 * 包含 block,override tag, 具体使用请查看<a href='http://code.google.com/p/rapid-framework/wiki/rapid_jsp_extends'>使用说明</a>
 * <p>
 * Copy from rapid
 */
package org.ponly.web.jsp.tags.layout;