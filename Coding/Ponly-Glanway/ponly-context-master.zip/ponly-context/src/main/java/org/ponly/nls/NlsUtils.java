package org.ponly.nls;

import org.ponly.common.util.ThreadContext;

import java.util.Locale;

/**
 * 本地语言支持工具类
 *
 * @author vacoor
 */
public abstract class NlsUtils {
    public static final String THREAD_NBM_KEY = NlsUtils.class.getName() + ".THREAD_NBM_KEY";
    private static NlsBundleManager nlsBundleManager;

    /**
     * 获取当前区域的语言包
     *
     * @return 语言包
     */
    public static NlsBundle getNlsBundle() {
        return getNlsBundle(null);
    }

    /**
     * 获取给定区域的语言包
     *
     * @param loc 目标区域
     * @return 语言包
     */
    public static NlsBundle getNlsBundle(Locale loc) {
        loc = null != loc ? loc : Locale.getDefault();
        return getRequiredNlsBundleManager().getBundle(loc);
    }

    public static NlsBundleManager getRequiredNlsBundleManager() {
        NlsBundleManager nbm = getNlsBundleManager();
        if (null == nbm) {
            String msg = "No NlsBundleManager accessible to the calling code, either bound to the " + NlsUtils.class.getName() + " or as a vm static singleton.  This is an invalid application configuration.";
            throw new IllegalStateException(msg);
        }
        return nbm;
    }

    /**
     * 获取语言包管理器
     * <p/>
     * 该类首先尝试获取当前线程的 {@link NlsBundleManager},
     * 其次尝试获取静态 {@link NlsBundleManager}
     *
     * @return 语言包管理器
     */
    public static NlsBundleManager getNlsBundleManager() {
        NlsBundleManager nbm = (NlsBundleManager) ThreadContext.get(THREAD_NBM_KEY);
        if (null == nbm) {
            nbm = nlsBundleManager;
        }

        return nbm;
    }

    /**
     * 设置当前的静态语言包管理器
     *
     * @param nlsBundleManager 语言包管理器
     */
    public static void setNlsBundleManager(NlsBundleManager nlsBundleManager) {
        NlsUtils.nlsBundleManager = nlsBundleManager;
    }
}
