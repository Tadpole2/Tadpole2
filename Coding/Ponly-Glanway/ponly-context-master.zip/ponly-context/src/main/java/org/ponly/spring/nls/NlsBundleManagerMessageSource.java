package org.ponly.spring.nls;

import org.ponly.nls.NlsBundleManager;
import org.springframework.context.support.AbstractMessageSource;

import java.text.MessageFormat;
import java.util.Locale;

/**
 * 基于 {@link NlsBundleManager} 实现的 Spring MessageSource
 *
 * @author vacoor
 */
public class NlsBundleManagerMessageSource extends AbstractMessageSource {
    private NlsBundleManager nlsBundleManager;

    @Override
    protected MessageFormat resolveCode(String code, Locale locale) {
        return createMessageFormat(nlsBundleManager.translate(code, locale), locale);
    }

    public NlsBundleManager getNlsBundleManager() {
        return nlsBundleManager;
    }

    public void setNlsBundleManager(NlsBundleManager nlsBundleManager) {
        this.nlsBundleManager = nlsBundleManager;
    }
}
