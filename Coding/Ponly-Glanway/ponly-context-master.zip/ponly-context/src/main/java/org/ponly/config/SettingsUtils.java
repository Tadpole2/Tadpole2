/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.config;

import org.ponly.common.util.LazyValue;
import org.ponly.common.util.ThreadContext;
import org.ponly.config.mgt.ConfigManager;

import java.util.Date;
import java.util.Properties;

import static org.ponly.common.util.Castor.*;
import static org.ponly.common.util.Nulls.nvl;
import static org.ponly.common.util.proxy.ProxyUtils.getProxy;

/**
 * 配置工具类
 *
 * @author vacoor
 */
public abstract class SettingsUtils {
    public static final String THREAD_CONFIG_MANAGER_KEY = SettingsUtils.class.getName() + ".THREAD_CONFIG_MANAGER_KEY";
    private static ConfigManager configManager;

    /**
     * 获取 Boolean 类型配置项值
     *
     * @param key 配置项名称
     * @return 当配置项不存在或值为 null 返回 null
     */
    public static Boolean getBoolean(String key) {
        return asBoolean(get(key));
    }

    /**
     * 获取 Boolean 类型配置项值
     *
     * @param key 配置项名称
     * @param def 配置项默认值
     * @return 当配置项不存在或值为 null 返回默认值 def
     */
    public static Boolean getBoolean(String key, Boolean def) {
        return nvl(getBoolean(key), def);
    }

    /**
     * 获取 Integer 类型配置项值
     *
     * @param key 配置项名称
     * @return 当配置项不存在或值为 null 返回 null
     */
    public static Integer getInt(String key) {
        return asInt(get(key));
    }

    /**
     * 获取 Integer 类型配置项值
     *
     * @param key 配置项名称
     * @param def 配置项默认值
     * @return 当配置项不存在或值为 null 返回默认值 def
     */
    public static Integer getInt(String key, Integer def) {
        return nvl(getInt(key), def);
    }

    /**
     * 获取 Long 类型配置项值
     *
     * @param key 配置项名称
     * @return 当配置项不存在或值为 null 返回 null
     */
    public static Long getLong(String key) {
        return asLong(get(key));
    }

    /**
     * 获取 Long 类型配置项值
     *
     * @param key 配置项名称
     * @param def 配置项默认值
     * @return 当配置项不存在或值为 null 返回默认值 def
     */
    public static Long getLong(String key, Long def) {
        return nvl(getLong(key), def);
    }

    /**
     * 获取 Float 类型配置项值
     *
     * @param key 配置项名称
     * @return 当配置项不存在或值为 null 返回 null
     */
    public static Float getFloat(String key) {
        return asFloat(get(key));
    }

    /**
     * 获取 Float 类型配置项值
     *
     * @param key 配置项名称
     * @param def 配置项默认值
     * @return 当配置项不存在或值为 null 返回默认值 def
     */
    public static Float getFloat(String key, Float def) {
        return nvl(getFloat(key), def);
    }

    /**
     * 获取 Double 类型配置项值
     *
     * @param key 配置项名称
     * @return 当配置项不存在或值为 null 返回 null
     */
    public static Double getDouble(String key) {
        return asDouble(get(key));
    }

    /**
     * 获取 Double 类型配置项值
     *
     * @param key 配置项名称
     * @param def 配置项默认值
     * @return 当配置项不存在或值为 null 返回默认值 def
     */
    public static Double getDouble(String key, Double def) {
        return nvl(getDouble(key), def);
    }

    /**
     * 获取 Date 类型配置项值
     *
     * @param key 配置项名称
     * @return 当配置项不存在或值为 null 返回 null
     */
    public static Date getDate(String key) {
        return asDate(get(key));
    }

    /**
     * 获取 Date 类型配置项值
     *
     * @param key 配置项名称
     * @param def 配置项默认值
     * @return 当配置项不存在或值为 null 返回默认值 def
     */
    public static Date getDate(String key, Date def) {
        return nvl(getDate(key), def);
    }

    /**
     * 获取 Date 类型配置项值, 使用给定的日期格式来解析
     *
     * @param key     配置项名称
     * @param dateFmt 配置项日期格式
     * @return 当配置项不存在或值为 null 返回 null
     */
    public static Date getDate(String key, String dateFmt) {
        return asDate(get(key, dateFmt));
    }

    /**
     * 获取 Date 类型配置项值
     *
     * @param key     配置项名称
     * @param dateFmt 配置项日期格式
     * @param def     配置项默认值
     * @return 当配置项不存在或值为 null 返回默认值 def
     */
    public static Date getDate(String key, String dateFmt, Date def) {
        return nvl(getDate(key, dateFmt), def);
    }

    /**
     * 获取 String 类型配置项值
     *
     * @param key 配置项名称
     * @return 当配置项不存在或值为 null 返回 null
     */
    public static String get(String key) {
        return getAsProperties().getProperty(key);
    }

    /**
     * 获取 String 类型配置项值
     *
     * @param key 配置项名称
     * @param def 配置项默认值
     * @return 当配置项不存在或值为 null 返回默认值 def
     */
    public static String get(String key, String def) {
        return nvl(get(key), def);
    }

    /**
     * 获取所有配置项值
     */
    public static Properties getAsProperties() {
        return getProxy(Properties.class, new LazyValue<Properties>() {
            @Override
            protected Properties compute() {
                Properties props = getRequiredConfigManager().getAsProperties();
                return null != props ? props : new Properties();
            }
        });
    }

    public static ConfigManager getRequiredConfigManager() {
        ConfigManager configMgr = getConfigManager();
        if (null == configMgr) {
            String msg = "No ConfigManager accessible to the calling code, either bound to the " + SettingsUtils.class.getName() + " or as a vm static singleton.  This is an invalid application configuration.";
            throw new IllegalStateException(msg);
        }
        return configMgr;
    }

    /**
     * 设置当前工具类的静态 {@link ConfigManager} 实例
     */
    public static void setConfigManager(ConfigManager configManager) {
        SettingsUtils.configManager = configManager;
    }

    /**
     * 获取当前上下文的 {@link ConfigManager} 实例
     * 该方法首先获取线程上线文中的 {@link ConfigManager}
     * 如果不存在则获取当前类的静态 {@link ConfigManager}
     * <p/>
     * {@link ThreadContext}
     */
    public static ConfigManager getConfigManager() {
        ConfigManager configMgr = (ConfigManager) ThreadContext.get(THREAD_CONFIG_MANAGER_KEY);
        if (null == configMgr) {
            configMgr = configManager;
        }
        return configMgr;
    }

    private SettingsUtils() {
    }
}
