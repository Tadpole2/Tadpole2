/**
 * 缓存相关
 *
 * @author vacoor
 */
package org.ponly.cache;