package org.ponly.nls.mgt;

import org.ponly.nls.NlsBundle;
import org.ponly.nls.NlsBundleManager;

import java.util.Enumeration;
import java.util.Locale;
import java.util.Set;

/**
 * 代理语言包
 *
 * @author vacoor
 */
class DelegatingNlsBundle extends NlsBundle {
    private final NlsBundleManager nlsBundleManager;
    private final Locale locale;

    public DelegatingNlsBundle(NlsBundleManager nlsBundleManager, Locale locale) {
        this.nlsBundleManager = nlsBundleManager;
        this.locale = locale;
    }

    @Override
    public Locale getLocale() {
        return locale;
    }

    @Override
    protected Object handleGetObject(String key) {
        return nlsBundleManager.translate(key, locale, null);
    }

    @Override
    @SuppressWarnings("unchecked")
    public Enumeration<String> getKeys() {
        return nlsBundleManager.getKeys(locale);
    }

    @Override
    protected Set<String> handleKeySet() {
        return super.handleKeySet();
    }

}
