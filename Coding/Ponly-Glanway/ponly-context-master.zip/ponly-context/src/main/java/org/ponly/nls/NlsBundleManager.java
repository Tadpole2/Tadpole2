package org.ponly.nls;

import java.util.Enumeration;
import java.util.Locale;
import java.util.Properties;

/**
 * 本地语言包管理器
 *
 * @author vacoor
 */
public interface NlsBundleManager {

    /**
     * 翻译给定内容到目标语言, 如果失败返回null
     *
     * @param text 需要翻译的内容
     * @param loc  目标语言 Locale
     * @return 翻译后的内容或null
     */
    String translate(String text, Locale loc);

    /**
     * 翻译给定内容到目标语言, 如果失败返回默认值
     *
     * @param text 需要翻译的内容
     * @param loc  目标语言 Locale
     * @param def  默认值
     * @return 翻译后的内容或默认值
     */
    String translate(String text, Locale loc, String def);

    /**
     * 获取给定区域所有翻译 Key
     *
     * @param loc 目标区域
     * @return 翻译 Keys
     */
    Enumeration<String> getKeys(Locale loc);

    /**
     * 获取给定区域的语言包
     *
     * @param loc 目标区域
     * @return 目标区域语言包
     */
    NlsBundle getBundle(Locale loc);

    /**
     * 存储给定区域的语言包
     *
     * @param loc   目标区域
     * @param props 语言包信息
     */
    void store(Locale loc, Properties props);

}
