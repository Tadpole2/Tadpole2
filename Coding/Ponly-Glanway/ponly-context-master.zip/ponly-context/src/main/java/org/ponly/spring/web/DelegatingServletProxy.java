package org.ponly.spring.web;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.*;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.util.NestedServletException;

/**
 * Proxy for a standard Servlet 2.3 Servlet, delegating to a Spring-managed bean that implements the Filter interface.
 * Supports a "targetBeanName" filter init-param in {@code web.xml}, specifying the name of the target bean
 * in the Spring application context.
 */
public class DelegatingServletProxy extends GenericServlet implements InitializingBean, DisposableBean {
    protected final Logger logger = LoggerFactory.getLogger(getClass());
    private final Object delegateMonitor = new Object();
    private String contextAttribute;
    private WebApplicationContext webApplicationContext;
    private String targetBeanName;
    private boolean targetServletLifecycle = true;
    private volatile Servlet delegate;

    /**
     * {@inheritDoc}
     */
    @Override
    public final void init() throws ServletException {
        super.init();

        if (logger.isDebugEnabled()) {
            logger.debug("Initializing servlet '" + getServletName() + '\'');
        }

        try {
            // initialize bean.
            final ServletConfigPropertyValues pvs = new ServletConfigPropertyValues(getServletConfig(), null);
            final BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(this);
            // final ServletContextResourceLoader loader = new ServletContextResourceLoader(getServletContext());

            initBeanWrapper(bw);

            bw.setPropertyValues(pvs, true);
        } catch (final BeansException ex) {
            String msg = "Failed to set bean properties on servlet '" + getServletName() + "': " + ex.getMessage();
            logger.error(msg, ex);
            throw new NestedServletException(msg, ex);
        }

        initServletBean();

        if (logger.isDebugEnabled()) {
            logger.debug("Servlet '" + getServletName() + "' configured successfully");
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        initServletBean();
    }

    @Override
    public void service(final ServletRequest request, final ServletResponse response) throws ServletException, IOException {
        Servlet servletToUse = this.delegate;
        if (null == servletToUse) {
            synchronized (delegateMonitor) {
                if (null == this.delegate) {
                    final WebApplicationContext contextToUse = findWebApplicationContext();
                    if (null == contextToUse) {
                        throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
                    }
                    this.delegate = initDelegate(contextToUse);
                }
                servletToUse = this.delegate;
            }
        }

        // invoke delegate operation.
        invokeDelegate(servletToUse, request, response);
    }

    @Override
    public void destroy() {
        super.destroy();

        final Servlet servletToUse = this.delegate;
        if (null != servletToUse) {
            this.delegate = null;
            servletToUse.destroy();
        }
    }

    protected void initBeanWrapper(final BeanWrapper beanWrapper) {
    }

    protected void initServletBean() throws ServletException {
        synchronized (delegateMonitor) {
            if (null == delegate) {
                // if no target name specified, use servlet name.
                if (null == targetBeanName) {
                    targetBeanName = getServletName();
                }

                //
                final WebApplicationContext contextToUse = findWebApplicationContext();
                if (null != contextToUse) {
                    initDelegate(contextToUse);
                }
            }
        }
    }

    protected WebApplicationContext findWebApplicationContext() {
        if (null != this.webApplicationContext) {
            if (this.webApplicationContext instanceof ConfigurableApplicationContext) {
                if (!((ConfigurableApplicationContext) webApplicationContext).isActive()) {
                    // the context has not yet been refreshed -> do so before returning it
                    ((ConfigurableApplicationContext) webApplicationContext).refresh();
                }
            }
            return this.webApplicationContext;
        }

        final ServletContext context = getServletContext();
        final String attributeName = getContextAttribute();
        if (null != attributeName) {
            return WebApplicationContextUtils.getWebApplicationContext(context, attributeName);
        } else {
            return WebApplicationContextUtils.getWebApplicationContext(context);
        }
    }

    protected Servlet initDelegate(final WebApplicationContext wac) throws ServletException {
        final Servlet delegate = wac.getBean(getTargetBeanName(), Servlet.class);
        if (isTargetServletLifecycle()) {
            delegate.init(getServletConfig());
        }
        return delegate;
    }

    protected void invokeDelegate(final Servlet delegate, final ServletRequest request, final ServletResponse response)
            throws ServletException, IOException {
        delegate.service(request, response);
    }

    protected void destroyDelegate(final Servlet delegate) {
        if (isTargetServletLifecycle()) {
            delegate.destroy();
        }
    }

    public String getContextAttribute() {
        return contextAttribute;
    }

    public void setContextAttribute(String contextAttribute) {
        this.contextAttribute = contextAttribute;
    }

    public WebApplicationContext getWebApplicationContext() {
        return webApplicationContext;
    }

    public void setWebApplicationContext(WebApplicationContext webApplicationContext) {
        this.webApplicationContext = webApplicationContext;
    }

    public String getTargetBeanName() {
        return targetBeanName;
    }

    public void setTargetBeanName(String targetBeanName) {
        this.targetBeanName = targetBeanName;
    }

    public boolean isTargetServletLifecycle() {
        return targetServletLifecycle;
    }

    public void setTargetServletLifecycle(boolean targetServletLifecycle) {
        this.targetServletLifecycle = targetServletLifecycle;
    }

    /**
     * PropertyValues implementation created from FilterConfig init parameters.
     */
    @SuppressWarnings("serial")
    private static class ServletConfigPropertyValues extends MutablePropertyValues {

        /**
         * Create new FilterConfigPropertyValues.
         *
         * @param config             FilterConfig we'll use to take PropertyValues from
         * @param requiredProperties set of property names we need, where
         *                           we can't accept default values
         * @throws ServletException if any required properties are missing
         */
        public ServletConfigPropertyValues(ServletConfig config, Set<String> requiredProperties) throws ServletException {
            Set<String> missingProps = (requiredProperties != null && !requiredProperties.isEmpty())
                    ? new HashSet<String>(requiredProperties) : null;

            Enumeration<?> en = config.getInitParameterNames();
            while (en.hasMoreElements()) {
                String property = (String) en.nextElement();
                Object value = config.getInitParameter(property);
                addPropertyValue(new PropertyValue(property, value));
                if (missingProps != null) {
                    missingProps.remove(property);
                }
            }

            // Fail if we are still missing properties.
            if (missingProps != null && missingProps.size() > 0) {
                throw new ServletException("Initialization from FilterConfig for filter '" + config.getServletName() +
                        "' failed; the following required properties were missing: " +
                        StringUtils.collectionToDelimitedString(missingProps, ", "));
            }
        }
    }
}
