/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.config.mgt;

import org.ponly.config.Option;

import java.util.List;
import java.util.Properties;

/**
 * 配置管理器
 *
 * @author vacoor
 */
public interface ConfigManager {

    List<Option> getOptions();

    Option getOption(String optionKey);

    Option create(Option option);

    Option update(Option option);

    int setOption(String name, String value);

    int updateOptions(Properties properties);

    void saveOrUpdate(List<Option> options);

    Properties getAsProperties();

    void reload();

}