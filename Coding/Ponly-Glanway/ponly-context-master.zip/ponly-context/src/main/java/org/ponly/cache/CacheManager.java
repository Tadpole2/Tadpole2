/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.cache;

/**
 * @author vacoor
 */
public interface CacheManager {

    <K, V> Cache<K, V> getCache(String name) throws CacheException;

}
