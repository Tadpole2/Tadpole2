/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop.support;

import org.ponly.common.util.ThreadContext;
import org.ponly.common.util.ThreadState;
import org.ponly.logging.aop.LogContext;

import java.util.HashMap;
import java.util.Map;

/**
 * @author vacoor
 */
public class LogContextThreadState implements ThreadState {
    private Map<Object, Object> originalResources;
    private final LogContext logContext;

    public LogContextThreadState(LogContext context) {
        this.logContext = context;
    }

    public LogContext getLogContext() {
        return logContext;
    }

    @Override
    public void bind() {
        originalResources = ThreadContext.getResources();
        ThreadContext.remove();

        if (null != originalResources) {
            Map<Object, Object> clone = new HashMap<Object, Object>();
            clone.putAll(originalResources);
            ThreadContext.setResources(clone);
        }
        ThreadContext.put(LogContext.CONTEXT_THREAD_KEY, logContext);
    }

    @Override
    public void restore() {
        // ThreadContext.remove(LogContext.CONTEXT_THREAD_KEY);
        ThreadContext.remove();
        ThreadContext.setResources(originalResources);
    }

    @Override
    public void clear() {
        ThreadContext.remove();
    }
}
