package org.ponly.config.mgt.support;

import org.ponly.cache.Cache;
import org.ponly.cache.CacheManager;
import org.ponly.cache.CacheManagerAware;
import org.ponly.cache.MemoryConstrainedCacheManager;
import org.ponly.config.Option;
import org.ponly.config.mgt.ConfigManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Properties;

/**
 * 可缓存的配置管理器
 *
 * @author vacoor
 */
public abstract class CachingConfigManager implements ConfigManager, CacheManagerAware {
    private static final Logger LOG = LoggerFactory.getLogger(CachingConfigManager.class);

    public static final String DEFAULT_OPTIONS_CACHE_NAME = CachingConfigManager.class.getName() + ".cache";
    public static final String DEFAULT_OPTIONS_CACHE_KEY = CachingConfigManager.class.getName() + ".KEY";

    private boolean cachingEnabled = true;      // 是否启用缓存
    private CacheManager cacheManager;          // 缓存管理器
    private String optionsCacheName;            // 配置缓存名称
    private String optionsCacheKey;
    private Cache<Object, List<Option>> optionsCache; // 配置缓存

    public CachingConfigManager() {
        cacheManager = new MemoryConstrainedCacheManager();
        optionsCacheName = DEFAULT_OPTIONS_CACHE_NAME;
        optionsCacheKey = DEFAULT_OPTIONS_CACHE_KEY;
    }

    /**
     * 获取当前配置管理器所使用的 {@link CacheManager} 实例
     */
    public CacheManager getCacheManager() {
        return cacheManager;
    }

    /**
     * 设置当前配置管理器所使用的 {@link CacheManager}
     *
     * @param cacheManager 缓存管理器
     */
    @Override
    public void setCacheManager(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
        this.afterCacheManagerSet();
    }

    /**
     * 获取当前是否启用缓存
     */
    public boolean isCachingEnabled() {
        return cachingEnabled;
    }

    /**
     * 设置是否启缓存配置项
     *
     * @param cachingEnabled 是否缓存配置项
     */
    public void setCachingEnabled(boolean cachingEnabled) {
        this.cachingEnabled = cachingEnabled;
    }

    /**
     * 获取配置项缓存名称
     */
    public String getOptionsCacheName() {
        return optionsCacheName;
    }

    /**
     * 设置配置项缓存名称
     *
     * @param optionsCacheName 配置项缓存名称
     */
    public void setOptionsCacheName(String optionsCacheName) {
        this.optionsCacheName = optionsCacheName;
    }

    public Cache<Object, List<Option>> getOptionsCache() {
        return optionsCache;
    }

    public void setOptionsCache(Cache<Object, List<Option>> optionsCache) {
        this.optionsCache = optionsCache;
    }

    protected void afterCacheManagerSet() {
    }

    @Override
    public Option getOption(String optionKey) {
        Option option = null;
        List<Option> options = getCachedOptions(optionKey);

        if (null == options) {
            LOG.debug("Looked up Options [{}] from doGetOption");
            // option = doGetOption(optionKey);
            // cacheOptionsIfPossible(optionKey, option);
            options = getOptions();
            for (Option op : options) {
                if (op.getName().equals(optionKey)) {
                    option = op;
                    break;
                }
            }
        }
        return option;
    }

    // protected abstract Option doGetOption(String optionKey);

    private List<Option> getCachedOptions(String optionsCacheKey) {
        List<Option> options = null;

        Cache<Object, List<Option>> cache = getAvailableOptionsCache();
        if (null != cache) {
            LOG.trace("Attempting to retrieve the Option from cache.");
            options = cache.get(optionsCacheKey);
            if (null == options) {
                LOG.trace("No Option found in cache for key [{}]", optionsCacheKey);
            } else {
                LOG.trace("Found cached Option for key [{}]", optionsCacheKey);
            }
        }

        return options;
    }

    private void cacheOptionsIfPossible(String optionsCacheKey, List<Option> options) {
        if (!isCachingEnabled()) {
            LOG.debug("Option caching is disabled for optionsCacheKey [{}].  Options: [{}].", optionsCacheKey, options);
            //return quietly, caching is disabled for this token/info pair:
            return;
        }

        Cache<Object, List<Option>> cache = getAvailableOptionsCache();
        if (null != cache) {
            cache.put(optionsCacheKey, options);
            LOG.trace("Cached option.  key=[{}], value=[{}].", optionsCacheKey, options);
        }
    }

    protected void clearCachedOptions() {
        Cache<Object, List<Option>> cache = getAvailableOptionsCache();
        if (null != cache) {
            cache.remove(getOptionsCacheKey());
        }
    }
    /*
    protected void clearCachedOption(String optionKey) {
        if (null != optionKey) {
            Cache<Object, Option> cache = getAvailableLocaleCache();
            if (null != cache) {
                cache.remove(getOptionCacheKey(optionKey));
            }
        }
    }
    */

    public String getOptionsCacheKey() {
        return optionsCacheKey;
    }

    public void setOptionsCacheKey(String optionsCacheKey) {
        this.optionsCacheKey = optionsCacheKey;
    }

    protected Cache<Object, List<Option>> getAvailableOptionsCache() {
        Cache<Object, List<Option>> cache = getOptionsCache();
        boolean cachingEnabled = isCachingEnabled();
        if (null == cache && cachingEnabled) {
            cache = getOptionsCacheLazy();
        }
        return cache;
    }

    private Cache<Object, List<Option>> getOptionsCacheLazy() {
        if (this.optionsCache == null) {
            LOG.trace("No optionsCache instance set.  Checking for a cacheManager...");

            CacheManager cacheManager = getCacheManager();

            if (null != cacheManager) {
                String cacheName = getOptionsCacheName();
                LOG.debug("CacheManager [{}] configured.  Building options cache '{}'", cacheManager, cacheName);
                this.optionsCache = cacheManager.getCache(cacheName);
            }
        }

        return this.optionsCache;
    }

    @Override
    public List<Option> getOptions() {
        List<Option> options = null;

        String key = getOptionsCacheKey();
        Cache<Object, List<Option>> cache = getAvailableOptionsCache();

        if (null != cache) {
            options = cache.get(key);
        }

        if (null == options) {
            options = doGetOptions();
            cacheOptionsIfPossible(key, options);
        }

        /*
        Collections.sort(options, new Comparator<Option>() {
            @Override
            public int compare(Option o1, Option o2) {
                if (o1 == o2) return 0;
                if (null == o1) return 1;       // nulls last
                Integer order1 = o1.getPosition();
                Integer order2 = o2.getPosition();
                if (order1 == order2) return 0;
                if (null == order1) return 1;   // nulls last
                return order1.compareTo(order2);
            }
        });
        */

        return options;
    }

    /* ****************
     *
     * ****************/

    @Override
    public Option create(Option option) {
        Option opt = doCreateOption(option);

        if (null != option) {
            clearCachedOptions();
        }
        return opt;
    }

    @Override
    public Option update(Option option) {
        Option opt = doUpdateOption(option);

        if (null != option) {
            clearCachedOptions();
        }

        return opt;
    }

    @Override
    public int setOption(String name, String value) {
        Properties props = new Properties();
        props.setProperty(name, value);
        return updateOptions(props);
    }

    @Override
    public int updateOptions(Properties props) {
        int updated = doUpdateOptionValues(props);
        clearCachedOptions();
        return updated;
    }

    public void saveOrUpdate(List<Option> options) {
        doSaveOrUpdate(options);
        clearCachedOptions();
    }

    protected abstract List<Option> doGetOptions();

    protected abstract Option doCreateOption(Option option);

    protected abstract Option doUpdateOption(Option option);

    protected abstract int doUpdateOptionValues(Properties props);

    protected abstract void doSaveOrUpdate(List<Option> options);

    @Override
    public Properties getAsProperties() {
        Properties props = new Properties();
        List<Option> options = getOptions();
        for (Option option : options) {
            String key = option.getName();
            String value = option.getValue();
            if (null != key && null != value) {
                props.setProperty(option.getName(), option.getValue());
            }
        }
        return props;
    }

    @Override
    public void reload() {
        clearCachedOptions();
    }
}
