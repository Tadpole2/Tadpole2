package org.ponly.spring.inject;

import java.lang.annotation.*;

/**
 * 泛型注入注解
 */
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface GenericAutowired {
}
