package org.ponly.web.servlet;

import org.ponly.common.util.ThreadContext;
import org.ponly.config.SettingsUtils;
import org.ponly.config.mgt.ConfigManager;
import org.ponly.nls.NlsBundleManager;
import org.ponly.nls.NlsUtils;
import org.ponly.web.servlet.WebRequestContextFilter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * WebContext 预处理 Filter
 *
 * @author vacoor
 */
public class WebContextFilter extends WebRequestContextFilter {
    private static final String DEFAULT_CONFIG_REQUEST_ATTRIBUTE_NAME = "_cfg";     // 默认配置request属性名称

    private String configAttributeName = DEFAULT_CONFIG_REQUEST_ATTRIBUTE_NAME;     // 配置request属性名称
    private ConfigManager configManager;            // 配置管理器
    private NlsBundleManager nlsBundleManager;      // 国际化管理器


    @Override
    protected WebRequestContextThreadState createContextState(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
        return new WebContextThreadState(httpRequest, httpResponse, getConfigManager(), getNlsBundleManager());
    }

    private class WebContextThreadState extends WebRequestContextThreadState {
        private final ConfigManager configManager;
        private final NlsBundleManager nlsBundleManager;

        public WebContextThreadState(HttpServletRequest httpRequest, HttpServletResponse httpResponse, ConfigManager configManager, NlsBundleManager nlsBundleManager) {
            super(httpRequest, httpResponse);
            this.configManager = configManager;
            this.nlsBundleManager = nlsBundleManager;
        }

        @Override
        public void bind() {
            super.bind();
            ConfigManager configManager = this.configManager;
            NlsBundleManager nlsBundleManager = this.nlsBundleManager;

            if (null == configManager) {
                configManager = SettingsUtils.getConfigManager();
            }
            if (null == nlsBundleManager) {
                nlsBundleManager = NlsUtils.getNlsBundleManager();
            }

            if (null != configManager) {
                ThreadContext.put(SettingsUtils.THREAD_CONFIG_MANAGER_KEY, configManager);
                getHttpRequest().setAttribute(configAttributeName, SettingsUtils.getAsProperties());
            }
            if (null != nlsBundleManager) {
                ThreadContext.put(NlsUtils.THREAD_NBM_KEY, nlsBundleManager);
            }
        }

        @Override
        public void restore() {
            ThreadContext.remove(SettingsUtils.THREAD_CONFIG_MANAGER_KEY);
            ThreadContext.remove(NlsUtils.THREAD_NBM_KEY);
            getHttpRequest().removeAttribute(configAttributeName);
            super.restore();
        }
    }

    @Override
    public void destroy() {
        super.destroy();
        configManager = null;
        configAttributeName = DEFAULT_CONFIG_REQUEST_ATTRIBUTE_NAME;
    }

    public String getConfigAttributeName() {
        return configAttributeName;
    }

    public void setConfigAttributeName(String configAttributeName) {
        this.configAttributeName = configAttributeName;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public void setConfigManager(ConfigManager configManager) {
        this.configManager = configManager;
    }

    public NlsBundleManager getNlsBundleManager() {
        return nlsBundleManager;
    }

    public void setNlsBundleManager(NlsBundleManager nlsBundleManager) {
        this.nlsBundleManager = nlsBundleManager;
    }
}
