/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop;

import java.util.Map;
import java.util.concurrent.Callable;

/**
 * @author vacoor
 */
public interface LogContext extends Map<String, Object> {
    String CONTEXT_THREAD_KEY = LogContext.class.getName() + ".THREAD-CONTEXT";

    Object get(String key);

    Object put(String key, Object value);

    // 在当前上下文执行
    <V> V execute(Callable<V> callable);

    LogMetadata getMetadata();

    boolean isEnabled();

    String getMessage();

    String getTemplate();

    String resolve(String expression);

    <T> T resolve(String expression, Class<T> clazz);

}
