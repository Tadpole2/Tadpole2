package org.ponly.config.mgt.support;

import org.ponly.config.Option;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

/**
 * 基于 Properties 文件, 用于测试的只读配置管理器
 *
 * @author vacoor
 */
public class PropertiesReadOnlyConfigManager extends CachingConfigManager {
    private Properties properties;

    public PropertiesReadOnlyConfigManager() {
    }

    public PropertiesReadOnlyConfigManager(Properties properties) {
        this.properties = properties;
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
        clearCachedOptions();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected List<Option> doGetOptions() {
        List<Option> options = new ArrayList<Option>();
        Properties properties = null != this.properties ? this.properties : new Properties();
        Enumeration<String> enumeration = (Enumeration<String>) properties.propertyNames();
        long id = 1;
        while (enumeration.hasMoreElements()) {
            String key = enumeration.nextElement();
            String value = properties.getProperty(key);
            options.add(new Option(id++, key, null, null, null, value, null, null));
            // options.add(new Option(key, null, null, null, value, 0));
        }
        return options;
    }

    @Override
    protected Option doCreateOption(Option option) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected Option doUpdateOption(Option option) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected int doUpdateOptionValues(Properties props) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected void doSaveOrUpdate(List<Option> options) {
        throw new UnsupportedOperationException();
    }
}
