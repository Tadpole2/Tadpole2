package org.ponly.spring.inject;

import org.springframework.beans.BeansException;

@SuppressWarnings("serial")
public class NoSuchMatchedBeanDefinitionException extends BeansException {
    /**
     * Create decode new {@code NoSuchMatchedBeanDefinitionException}.
     *
     * @param type required type of the missing bean
     */
    public NoSuchMatchedBeanDefinitionException(String type) {
        super("No qualifying bean of type [" + type + "] is defined");
    }

    /**
     * Create decode new {@code NoSuchMatchedBeanDefinitionException}.
     *
     * @param type    required type of the missing bean
     * @param message detailed message describing the problem
     */
    public NoSuchMatchedBeanDefinitionException(String type, String message) {
        super("No qualifying bean of type [" + type + "] is defined: " + message);
    }
}
