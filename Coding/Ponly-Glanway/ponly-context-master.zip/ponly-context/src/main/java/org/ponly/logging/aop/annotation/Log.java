/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;

/**
 * 日志记录点
 *
 * @author vacoor
 */
@Target(value = {METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Log {

    String name() default "#default#";  // 日志点名称

    boolean enabled() default true;     // 是否启用

    int level() default 0;              // 日志等级

    String[] tags() default {};

    String value();                     // message
}
