/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop;

import java.util.Arrays;

/**
 * @author vacoor
 */
public interface LogAppender {
    LogAppender STD = new LogAppender() {
        @Override
        public void doAppend(LogContext context, String source, int level, long millis, String message, Throwable ex, String[] tags) {
            System.out.println(String.format("level: %s, message: \"%s\", exception: %s, tags: \"%s\", source: \"%s\"", level, message, null != ex, Arrays.toString(tags), source));
        }
    };
    LogAppender NULL = new LogAppender() {
        @Override
        public void doAppend(LogContext context, String source, int level, long millis, String message, Throwable ex, String[] tags) {
        }
    };


    void doAppend(LogContext context, String source, int level, long millis, String message, Throwable ex, String[] tags);

}
