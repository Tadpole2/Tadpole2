/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.spring.web;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.GenericApplicationListenerAdapter;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.filter.DelegatingFilterProxy;

import javax.servlet.Filter;
import javax.servlet.ServletException;
import java.lang.reflect.Field;

/**
 * DelegatingFilterProxy can't reload delegate on ContextRefreshedEvent
 * {@see https://jira.spring.io/browse/SPR-6228}
 */

public class RefreshableDelegatingFilterProxy extends DelegatingFilterProxy implements ApplicationListener<ContextRefreshedEvent> {
    @Override
    protected Filter initDelegate(WebApplicationContext wac) throws ServletException {
        Filter filter = super.initDelegate(wac);
        // Working but ugly:
        ((AbstractApplicationContext) wac).getApplicationListeners().add(new GenericApplicationListenerAdapter(this));
        // Not working: AbstractApplicationContext.refresh() creates a new ApplicationEventMulticaster, and this method adds
        // the listener to its own multicaster.
        //((ConfigurableWebApplicationContext)wac).addApplicationListener(new GenericApplicationListenerAdapter(this));
        return filter;
    }


    @Override
    public void destroy() {
        try {
            Field f = ReflectionUtils.findField(getClass(), "delegate");
            ReflectionUtils.makeAccessible(f);
            f.set(this, null);
        } catch (IllegalAccessException e) {
            // ignore
        }
        super.destroy();
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        // refresh
        destroy();
        try {
            init(getFilterConfig());
        } catch (ServletException e) {
        }
    }
}