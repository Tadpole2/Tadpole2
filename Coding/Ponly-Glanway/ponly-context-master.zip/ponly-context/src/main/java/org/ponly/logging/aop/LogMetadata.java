/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop;

/**
 * @author vacoor
 */
public class LogMetadata {
    private String name;        // 日志点名称
    private int level;          // 级别
    private String template;    // 模版
    private String[] tags;      // 标签
    private boolean enabled;    // 是否启用

    public LogMetadata(String name, int level, String template) {
        this(name, level, template, new String[0], true);
    }

    public LogMetadata(String name, int level, String template, String[] tags, boolean enabled) {
        this.name = name;
        this.level = level;
        this.template = template;
        this.tags = tags;
        this.enabled = enabled;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String[] getTags() {
        return tags;
    }

    public void setTags(String[] tags) {
        this.tags = tags;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
