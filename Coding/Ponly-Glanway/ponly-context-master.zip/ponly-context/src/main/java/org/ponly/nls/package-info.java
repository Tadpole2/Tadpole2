/**
 * 本地语言支持
 *
 * @author vacoor
 */
package org.ponly.nls;