/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.cache;

/**
 * @author vacoor
 */
public class CacheException extends RuntimeException {

    public CacheException() {
    }

    public CacheException(String s) {
        super(s);
    }

    public CacheException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public CacheException(Throwable throwable) {
        super(throwable);
    }
}
