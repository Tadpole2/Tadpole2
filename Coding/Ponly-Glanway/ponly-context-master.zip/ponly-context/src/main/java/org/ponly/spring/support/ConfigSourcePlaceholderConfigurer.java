/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.spring.support;

import org.ponly.config.mgt.ConfigManager;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.Properties;

/**
 * 配置管理器属性占位符配置器
 * 配置时注意
 * 1. 所有 PlaceholderConfigurer 应该配置在文件最前面
 * 2. 基于文件的 PropertyPlaceholderConfigurer 配置在该 PlaceholderConfigurer 之前
 * 3. 基于文件的 PropertyPlaceholderConfigurer 必须设置 ignore-unresolvable=true, 否则不会执行当前 ph 即报错
 * {@link #setConfigManager(ConfigManager)}
 *
 * @author vacoor
 */
public class ConfigSourcePlaceholderConfigurer extends PropertyPlaceholderConfigurer {
    protected ConfigManager configManager;
    protected Properties properties;

    public ConfigSourcePlaceholderConfigurer() {
        // 默认 PropertyResourceConfigurer 的执行 order 已经是最低的
        // 但是希望该 Configurer 在其他配置后执行, 只有配置其他 PropertyResourceConfigurer 的 order
        // 补充, 把其他 property-placeholder 定义在该类之前也是可以的 (order相等按照定于顺序)
        // setOrder(LOWEST_PRECEDENCE);
        setLocalOverride(true);
    }

    @Override
    protected String resolvePlaceholder(String placeholder, Properties props) {
        /*
        String resolved = super.resolvePlaceholder(placeholder, props);
        return null != resolved ? resolved : resolvePlaceholderFromDb(placeholder);
        */
        return super.resolvePlaceholder(placeholder, props);
    }

    @Override
    protected Properties mergeProperties() throws IOException {
        Properties result = super.mergeProperties();
        CollectionUtils.mergePropertiesIntoMap(loadProperties(), result);
        return result;
    }

    /**
     * 本来想复写 {@link org.springframework.core.io.support.PropertiesLoaderSupport#loadProperties(Properties)}
     */
    private Properties loadProperties() {
        if (null == properties && null != configManager) {
            properties = configManager.getAsProperties();
        }
        return properties;
    }

    /**
     * 直接注入进来会有问题:
     * 因为当前类依赖 ConfigManager, 因此当前类在初始化时会把 ConfigManager 也初始化,
     * 但 ConfigManager 可能是需要占位符处理的, 但此时 其他 PropertyResourceConfigurer 可能并没有初始化
     * ( ConfigManager 初始化是因为当前类造成的 ), 因此没有办法进行占位符替换
     * 注入时可借助 {@link org.springframework.aop.target.LazyInitTargetSource} 来实现 not-lazy bean 中 lazy bean 的 lazy-init
     */
    public void setConfigManager(ConfigManager configManager) {
        this.configManager = configManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }
}
