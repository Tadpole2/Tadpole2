package org.ponly.cache;

/**
 */
public interface CacheManagerAware {

    void setCacheManager(CacheManager cacheManager);

}
