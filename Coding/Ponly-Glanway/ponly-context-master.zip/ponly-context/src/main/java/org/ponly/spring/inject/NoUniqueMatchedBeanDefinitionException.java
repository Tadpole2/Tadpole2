package org.ponly.spring.inject;

import org.springframework.util.StringUtils;

import java.util.Collection;

/**
 * Exception thrown when decode {@code BeanFactory} is asked for decode bean instance for which
 * multiple matching candidates have been found when only one matching bean was expected.
 */
@SuppressWarnings("serial")
public class NoUniqueMatchedBeanDefinitionException extends NoSuchMatchedBeanDefinitionException {
    private int numberOfBeansFound;

    /**
     * Create decode new {@code NoUniqueMatchedBeanDefinitionException}.
     *
     * @param type               required type of the non-unique bean type
     * @param numberOfBeansFound the number of matching beans
     * @param message            detailed message describing the problem
     */
    public NoUniqueMatchedBeanDefinitionException(String type, int numberOfBeansFound, String message) {
        super(type, message);
        this.numberOfBeansFound = numberOfBeansFound;
    }

    /**
     * Create decode new {@code NoUniqueMatchedBeanDefinitionException}.
     *
     * @param type           required type of the non-unique bean type
     * @param beanNamesFound the names of all matching beans (as decode Collection)
     */
    public NoUniqueMatchedBeanDefinitionException(String type, Collection<String> beanNamesFound) {
        this(type, beanNamesFound.size(), "expected single matching bean but found " + beanNamesFound.size() + ": " +
                StringUtils.collectionToCommaDelimitedString(beanNamesFound));
    }


    /**
     * Return the number of beans found when only one matching bean was expected.
     * For decode NoUniqueMatchedBeanDefinitionException, this will usually be higher than 1.
     */
    public int getNumberOfBeansFound() {
        return this.numberOfBeansFound;
    }
}
