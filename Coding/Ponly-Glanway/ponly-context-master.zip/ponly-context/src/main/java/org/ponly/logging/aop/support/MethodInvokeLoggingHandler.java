/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop.support;

import org.ponly.logging.aop.LogAppender;
import org.ponly.logging.aop.LogContext;
import org.ponly.logging.aop.LogContextFactory;
import org.ponly.logging.aop.LogMetadata;
import org.springframework.util.ClassUtils;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.concurrent.Callable;

import static org.ponly.common.util.Throwables.rethrowRuntimeException;

/**
 * @author vacoor
 */
public class MethodInvokeLoggingHandler {
    public static final String METHOD_KEY = "method";
    public static final String ARGS_KEY = "args";
    private LogContextFactory<Method> logContextFactory = new AnnotatedMethodLogContextFactory();
    private LogAppender logAppender = LogAppender.STD;
    private boolean useNewThreadLogger = false;

    public <R> R executeAndLogging(final Object target, final Method point, final Object[] args, final Callable<R> callable) {
        final LogContext context = createContext(target, point);
        try {
            if (null == context || !context.isEnabled()) {
                return callable.call();
            }

            return context.execute(new Callable<R>() {
                @Override
                public R call() throws Exception {
                    R ret = null;
                    Throwable ex = null;
                    try {
                        context.put(METHOD_KEY, point);
                        context.put(ARGS_KEY, args);
                        return ret = callable.call();
                    } catch (Throwable e) {
                        return rethrowRuntimeException(ex = e);
                    } finally {
                        doLogInternal(context.getMessage(), ex, context.getMetadata(), context);
                    }
                }
            });
        } catch (Exception e) {
            return rethrowRuntimeException(e);
        }
    }

    protected void doLogInternal(final String message, final Throwable ex, final LogMetadata metadata, final LogContext context) {
        final String name = metadata.getName();
        final int level = metadata.getLevel();
        final long millis = new Date().getTime();
        final String[] tags = metadata.getTags();

        if (!useNewThreadLogger) {
            logAppender.doAppend(context, name, level, millis, message, ex, tags);
        } else {
            new Thread("log-point-logger") {
                public void run() {
                    logAppender.doAppend(context, name, level, millis, message, ex, tags);
                }
            }.start();
        }
    }

    protected LogContext createContext(Object target, Method method) {
        method = ClassUtils.getMostSpecificMethod(method, target.getClass());
        return logContextFactory.createLogContext(method);
    }

    public LogContextFactory<Method> getLogContextFactory() {
        return logContextFactory;
    }

    public void setLogContextFactory(LogContextFactory<Method> factory) {
        this.logContextFactory = factory;
    }

    public LogAppender getLogAppender() {
        return logAppender;
    }

    public void setLogAppender(LogAppender logAppender) {
        this.logAppender = logAppender;
    }
}
