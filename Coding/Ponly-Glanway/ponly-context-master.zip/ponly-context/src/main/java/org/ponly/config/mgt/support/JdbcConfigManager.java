package org.ponly.config.mgt.support;

import com.google.common.collect.Lists;
import org.ponly.common.util.JdbcUtils;
import org.ponly.config.Option;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import static org.ponly.common.util.Throwables.rethrowRuntimeException;

/**
 * 基于 JDBC 的配置管理器
 * <p/>
 * {@link org.ponly.config.mgt.support.spring.config.JdbcConfigManagerBeanDefinitionParser}
 *
 * @author vacoor
 */
public class JdbcConfigManager extends CachingConfigManager {
    protected static final String DEFAULT_OPTIONS_QUERY = "select ID, NAME, INTRO, NOTE, TYPE, VALUE, CATEGORY, POSITION from T_OPTION";
    protected static final String DEFAULT_OPTION_VALUE_UPDATE = "update T_OPTION SET VALUE = ? where NAME = ?";
    protected static final String DEFAULT_OPTION_INSERT = "insert into T_OPTION(NAME, INTRO, NOTE, TYPE, VALUE, CATEGORY, POSITION) VALUES(?, ?, ?, ?, ?, ?, ?)";

    protected DataSource dataSource;
    protected String optionsQuery = DEFAULT_OPTIONS_QUERY;
    protected String optionInsert = DEFAULT_OPTION_INSERT;
    protected String optionValueUpdate = DEFAULT_OPTION_VALUE_UPDATE;

    @Override
    protected List<Option> doGetOptions() {
        List<Option> result = Lists.newArrayList();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dataSource.getConnection();
            ps = conn.prepareStatement(optionsQuery);
            rs = ps.executeQuery();
            while (rs.next()) {
                long id = rs.getLong(1);
                String name = rs.getString(2);
                String intro = rs.getString(3);
                String note = rs.getString(4);
                String type = rs.getString(5);
                String value = rs.getString(6);
                String category = rs.getString(7);
                int position = rs.getInt(8);

                result.add(new Option(id, name, intro, note, type, value, category, position));
            }

            return result;
        } catch (SQLException e) {
            return rethrowRuntimeException(e);
        } finally {
            JdbcUtils.close(rs);
            JdbcUtils.close(ps);
            JdbcUtils.close(conn);
        }
    }

    @Override
    protected Option doCreateOption(Option option) {
        try {
            JdbcUtils.executeUpdate(
                    dataSource,
                    optionInsert,
                    option.getName(),
                    option.getIntro(),
                    option.getNote(),
                    option.getType(),
                    option.getValue(),
                    option.getCategory(),
                    option.getPosition()
            );
        } catch (SQLException e) {
            rethrowRuntimeException(e);
        }
        return option;
    }

    @Override
    protected Option doUpdateOption(Option option) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected int doUpdateOptionValues(Properties props) {
        Connection conn = null;
        PreparedStatement ps = null;
        int updated = 0;
        try {
            conn = dataSource.getConnection();
            boolean autoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            ps = conn.prepareStatement(optionValueUpdate);

            int i = 0;
            for (Enumeration<?> names = props.propertyNames(); names.hasMoreElements(); i++) {
                ps.clearParameters();
                if (0 != i && 0 == (i % 100)) {
                    updated = count(ps.executeBatch());
                }
                String name = (String) names.nextElement();
                String value = props.getProperty(name);
                JdbcUtils.setParameters(ps, value, name);
                ps.addBatch();
            }
            updated += count(ps.executeBatch());
            conn.commit();
            conn.setAutoCommit(autoCommit);
        } catch (SQLException e) {
            rethrowRuntimeException(e);
        } finally {
            JdbcUtils.close(ps);
            JdbcUtils.close(conn);
        }
        return updated;
    }

    private int count(int[] updated) {
        int i = 0;
        for (int u : updated) {
            i += u;
        }
        return i;
    }

    @Override
    protected void doSaveOrUpdate(List<Option> options) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = dataSource.getConnection();
            boolean autoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);

            ps = conn.prepareStatement(optionValueUpdate);
            for (Option option : options) {
                ps.clearParameters();
                ps.setString(1, option.getValue());
                ps.setString(2, option.getName());
                ps.addBatch();
            }
            int[] rets = ps.executeBatch();
            ps.close();

            ps = conn.prepareStatement(optionInsert);
            // 如果没有更新, 则不存在
            for (int i = 0; i < rets.length; i++) {
                if (1 > rets[i]) {
                    ps.clearParameters();
                    Option option = options.get(i);
                    JdbcUtils.setParameters(ps, option.getName(), option.getIntro(), option.getNote(), option.getType(), option.getValue(), option.getCategory(), option.getPosition());
                    ps.addBatch();
                }
            }
            ps.executeBatch();
            conn.commit();
            conn.setAutoCommit(autoCommit);
        } catch (SQLException e) {
            rethrowRuntimeException(e);
        } finally {
            JdbcUtils.close(ps);
            JdbcUtils.close(conn);
        }
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public String getOptionsQuery() {
        return optionsQuery;
    }

    public void setOptionsQuery(String optionsQuery) {
        this.optionsQuery = optionsQuery;
    }

    public String getOptionInsert() {
        return optionInsert;
    }

    public void setOptionInsert(String optionInsert) {
        this.optionInsert = optionInsert;
    }

    public String getOptionValueUpdate() {
        return optionValueUpdate;
    }

    public void setOptionValueUpdate(String optionValueUpdate) {
        this.optionValueUpdate = optionValueUpdate;
    }
}
