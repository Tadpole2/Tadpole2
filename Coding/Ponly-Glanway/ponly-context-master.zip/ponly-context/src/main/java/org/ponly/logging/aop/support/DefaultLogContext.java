/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop.support;

import org.ponly.common.util.ELEngine;
import org.ponly.common.util.MapContext;
import org.ponly.logging.aop.LogContext;
import org.ponly.logging.aop.LogMetadata;
import org.ponly.web.servlet.WebRequestContext;
import org.springframework.web.context.request.RequestContextHolder;

import javax.el.ELContext;
import javax.el.ELResolver;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.beans.FeatureDescriptor;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Callable;

import static org.ponly.common.util.Throwables.*;
import static org.ponly.web.servlet.WebRequestContext.ImplicitObjectELResolver;
import static org.ponly.web.servlet.WebRequestContext.ImplicitObjectsFactory;

/**
 * 默认的日志记录点上下文
 *
 * @author vacoor
 */
public class DefaultLogContext extends MapContext implements LogContext {
    private static final String REQUEST_KEY = "request";
    private static final boolean REQUEST_CONTEXT_PERSENT = isPresent("org.ponly.web.servlet.WebRequestContext");
    private static final boolean REQUEST_ATTRIBUTES_PRESENT = isPresent("org.springframework.web.context.request.RequestContextHolder");

    private final LogMetadata metadata;
    private final ELEngine elEngine;

    public DefaultLogContext(LogMetadata metadata) {
        this.metadata = metadata;
        this.elEngine = new LogContextEngine(this);

        if (REQUEST_CONTEXT_PERSENT) {
            WebRequestContext context = WebRequestContext.getContext();
            if (null != context) {
                this.put(REQUEST_KEY, context.getRequest());
            }
        } else if (REQUEST_ATTRIBUTES_PRESENT) {
            if (null != RequestContextHolder.currentRequestAttributes()) {
                this.put(REQUEST_KEY, RequestContextHolder.currentRequestAttributes().resolveReference(REQUEST_KEY));
            }
        }
    }

    @Override
    public Object get(String key) {
        return super.get(key);
    }

    @Override
    public Object put(String key, Object value) {
        return super.put(key, value);
    }

    @Override
    public <V> V execute(final Callable<V> callable) {
        Callable<V> proxy = associateWith(callable);
        V ret;
        try {
            ret = proxy.call();
        } catch (Exception e) {
            ret = rethrowRuntimeException(e);
        }
        return ret;
    }

    @Override
    public LogMetadata getMetadata() {
        return metadata;
    }

    @Override
    public boolean isEnabled() {
        return metadata.isEnabled();
    }

    @Override
    public String getMessage() {
        return resolveMessage(getTemplate());
    }

    @Override
    public String getTemplate() {
        return metadata.getTemplate();
    }

    @Override
    public String resolve(String expression) {
        return elEngine.resolve(expression);
    }

    @Override
    public <T> T resolve(String expression, Class<T> clazz) {
        return elEngine.resolve(expression, clazz);
    }


    protected <V> Callable<V> associateWith(Callable<V> callable) {
        return new LogContextCallable<V>(this, callable);
    }

    protected String resolveMessage(String message) {
        return elEngine.resolve(message);
    }



    /* ********************************
     *
     * ********************************/

    protected static class LogContextEngine extends ELEngine {
        LogContextEngine(LogContext context) {
            Class<LogContext> contextKey = LogContext.class;

            this.resolver.add(new ImplicitObjectELResolver<LogContext>(contextKey, new LogContextImplicitObjectFactory()));
            this.resolver.add(new ContextAttributeElResolver());
            this.context.putContext(contextKey, context);
        }
    }

    // 日志上下文属性内置对象解析器
    protected static class LogContextImplicitObjectFactory implements ImplicitObjectsFactory<LogContext> {

        @Override
        public ImplicitObjectELResolver.ImplicitObjects<LogContext> createImplicitObjects(LogContext context) {
            return new ImplicitObjectELResolver.ImplicitObjects<LogContext>(context) {
                @Override
                protected HttpServletRequest getRequest(LogContext context) {
                    WebRequestContext ctx = WebRequestContext.getContext();
                    return null != ctx ? ctx.getRequest() : null;
                }

                @Override
                protected ServletContext getServletContext(LogContext context) {
                    WebRequestContext ctx = WebRequestContext.getContext();
                    return null != ctx ? ctx.getServletContext() : null;
                }

                @Override
                protected Map<String, Object> createContextScopeMap(LogContext context) {
                    return context;
                }
            };
        }
    }

    // 上下文属性解析器
    protected static class ContextAttributeElResolver extends ELResolver {

        protected LogContext getContext(ELContext context) {
            LogContext ctx = (LogContext) context.getContext(LogContext.class);
            if (null == ctx) {
                throw new IllegalStateException("can't found context for: " + LogContext.class);
            }
            return ctx;
        }

        @Override
        public Object getValue(ELContext context, Object base, Object property) {
            if (null == context) {
                throw new NullPointerException();
            }
            if (null == base) {
                context.setPropertyResolved(true);
                if (property instanceof String) {
                    return getContext(context).get((String) property);
                }
            }
            return null;
        }

        public Class<Object> getType(ELContext context, Object base, Object property) {
            if (null == context) {
                throw new NullPointerException();
            }
            if (null == base) {
                context.setPropertyResolved(true);
                return Object.class;
            }
            return null;
        }

        public void setValue(ELContext context, Object base, Object property, Object val) {
            if (null == context) {
                throw new NullPointerException();
            }
            if (null == base) {
                context.setPropertyResolved(true);
                if (property instanceof String) {
                    String attr = (String) property;
                    getContext(context).put(attr, val);
                }
            }
        }

        @Override
        public boolean isReadOnly(ELContext context, Object base, Object property) {
            if (context == null) {
                throw new NullPointerException();
            }
            if (base == null) {
                context.setPropertyResolved(true);
            }
            return false;
        }

        @Override
        public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
            return null;
        }

        @Override
        public Class<?> getCommonPropertyType(ELContext context, Object base) {
            return null == base ? String.class : null;
        }
    }

    private static boolean isPresent(String className) {
        try {
            Class.forName(className);
            return true;
        } catch (Throwable ex) {
            // Class or one of its dependencies is not present...
            return false;
        }
    }
}
