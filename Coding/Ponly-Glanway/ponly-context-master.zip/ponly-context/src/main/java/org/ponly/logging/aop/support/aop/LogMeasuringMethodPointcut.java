/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop.support.aop;

import org.ponly.logging.aop.annotation.Log;
import org.springframework.aop.ClassFilter;
import org.springframework.aop.MethodMatcher;
import org.springframework.aop.Pointcut;
import org.springframework.aop.support.AopUtils;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ClassUtils;

import java.lang.reflect.Method;

/**
 * @author vacoor
 */
public class LogMeasuringMethodPointcut implements Pointcut {

    @Override
    public ClassFilter getClassFilter() {
        return ClassFilter.TRUE;
    }

    @Override
    public MethodMatcher getMethodMatcher() {
        return MonitoredMethodMatcher.INSTANCE;
    }

    private static class MonitoredMethodMatcher implements MethodMatcher {
        private static final MethodMatcher INSTANCE = new MonitoredMethodMatcher();

        @Override
        public boolean matches(Method method, Class<?> targetClass) {
            if (ClassUtils.isCglibProxyClass(targetClass)) {
                targetClass = ClassUtils.getUserClass(targetClass);
            }
            return !ClassUtils.isCglibProxyClass(targetClass) && isMonitoredAnnotationMethod(method, targetClass);
        }

        @Override
        public boolean isRuntime() {
            return false;
        }

        @Override
        public boolean matches(Method method, Class<?> targetClass, Object[] args) {
            throw new UnsupportedOperationException("This is not a runtime method matcher");
        }

        private boolean isMonitoredAnnotationMethod(Method method, Class targetClass) {
            return (AnnotationUtils.findAnnotation(AopUtils.getMostSpecificMethod(method, targetClass), Log.class) != null);
        }
    }
}
