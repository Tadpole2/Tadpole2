/**
 * 应用配置相关
 * @author vacoor
 */
package org.ponly.config;