/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop.support.aop;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.ponly.logging.aop.support.MethodInvokeLoggingHandler;

import java.lang.reflect.Method;
import java.util.concurrent.Callable;

import static org.ponly.common.util.Throwables.rethrowException;

/**
 * @author vacoor
 */
public class MethodInvokeLogInterceptor implements MethodInterceptor {
    private MethodInvokeLoggingHandler methodInvokeLoggingHandler = new MethodInvokeLoggingHandler();

    @Override
    public Object invoke(final MethodInvocation invocation) throws Throwable {
        Object target = invocation.getThis();
        final Method method = invocation.getMethod();
        final Object[] args = invocation.getArguments();

        return methodInvokeLoggingHandler.executeAndLogging(target, method, args, new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                try {
                    return invocation.proceed();
                } catch (Throwable ex) {
                    return rethrowException(ex);
                }
            }
        });
    }

    public MethodInvokeLoggingHandler getMethodInvokeLoggingHandler() {
        return methodInvokeLoggingHandler;
    }

    public void setMethodInvokeLoggingHandler(MethodInvokeLoggingHandler methodInvokeLoggingHandler) {
        this.methodInvokeLoggingHandler = methodInvokeLoggingHandler;
    }
}
