/**
 * 方法日志相关
 * <p />
 * 方法日志主要有三部分组成: 方法调用日志处理器, 日志上下文, 日志输出器
 * 方法处理器由 {@link org.ponly.mlog.invoke.support.MethodInvokeLoggingHandler} 定义
 * 日志上下文由 {@link org.ponly.mlog.invoke.LogContext} 定义
 * 日志输出器由 {@link org.ponly.mlog.invoke.LogAppender} 定义
 *
 * {@link org.ponly.mlog.invoke.support.aop.MethodInvokeLogInterceptor} 会对每一个拦截到的方法
 * 调用内部的 {@link org.ponly.mlog.invoke.support.MethodInvokeLoggingHandler} 实例进行处理
 * 执行步骤如下:
 * 1. {@link org.ponly.mlog.invoke.support.MethodInvokeLoggingHandler} 会使用内部维护的 {@link org.ponly.mlog.invoke.LogContextFactory}实例来为每个方法调用创建一个方法调用的日志上下文
 * 2. 在该上下文中执行该方法调用
 * 3. 方法调用结束后，获取方法调用的日志信息, 调用 {@link org.ponly.mlog.invoke.LogAppender} 进行写入
 *
 * 注: 日志上下文仅在方法调用开始和结束前中存在，一旦调用结束，该方法调用日志上下文将销毁
 *
 * @author vacoor
 */
package org.ponly.logging.aop;