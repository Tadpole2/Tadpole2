package org.ponly.nls.mgt;

import org.ponly.cache.Cache;
import org.ponly.cache.CacheManager;
import org.ponly.cache.CacheManagerAware;
import org.ponly.cache.MemoryConstrainedCacheManager;
import org.ponly.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Enumeration;
import java.util.Locale;
import java.util.Properties;

/**
 * 缓存的语言包管理器
 *
 * @author vacoor
 */
public abstract class CachingNlsBundleManager extends AbstractNlsBundleManager implements CacheManagerAware {
    private static final Logger LOG = LoggerFactory.getLogger(CachingNlsBundleManager.class);
    // 默认语言包缓存名称
    public static final String DEFAULT_NLS_BUNDLE_CACHE_NAME = CachingNlsBundleManager.class.getName() + ".NLS_BUNDLE";

    private boolean cachingEnabled = true;
    private CacheManager cacheManager;
    private String nlsBundleCacheName;
    private Cache<Object/*locale*/, Properties> nlsBundleCache;

    public CachingNlsBundleManager() {
        cacheManager = new MemoryConstrainedCacheManager();
        nlsBundleCacheName = DEFAULT_NLS_BUNDLE_CACHE_NAME;
    }

    /**
     * 获取当前使用的缓存管理器
     *
     * @return 当前使用的缓存管理器
     */
    public CacheManager getCacheManager() {
        return cacheManager;
    }

    /**
     * 设置缓存管理器
     *
     * @param cacheManager 缓存管理器
     */
    @Override
    public void setCacheManager(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
        this.afterCacheManagerSet();
    }

    /**
     * 当前管理器是否启用缓存
     *
     * @return 是否启用缓存
     */
    public boolean isCachingEnabled() {
        return cachingEnabled;
    }

    /**
     * 设置当前管理器是否启用缓存
     *
     * @param cachingEnabled 是否启用缓存
     */
    public void setCachingEnabled(boolean cachingEnabled) {
        this.cachingEnabled = cachingEnabled;
    }

    /**
     * 获取语言包缓存名称
     *
     * @return 语言包缓存名称
     */
    public String getNlsBundleCacheName() {
        return nlsBundleCacheName;
    }

    /**
     * 设置语言包缓存名称
     *
     * @param nlsBundleCacheName 语言包缓存名称
     */
    public void setNlsBundleCacheName(String nlsBundleCacheName) {
        this.nlsBundleCacheName = nlsBundleCacheName;
    }

    /**
     * 获取语言包缓存
     *
     * @return 语言包缓存
     */
    public Cache<Object, Properties> getNlsBundleCache() {
        return nlsBundleCache;
    }

    /**
     * 设置语言包缓存
     *
     * @param nlsBundleCache 语言包缓存
     */
    public void setNlsBundleCache(Cache<Object, Properties> nlsBundleCache) {
        this.nlsBundleCache = nlsBundleCache;
    }

    protected void afterCacheManagerSet() {
    }

    /**
     * 获取给定区域的语言包内容
     *
     * @param loc 目标区域
     * @return 语言包内容
     */
    protected Properties getStoredNlsProperties(Locale loc) {
        Properties props = getCachedNlsProperties(loc);
        if (null == props) {
            LOG.debug("Looked up NlsProperties [{}] from doGetStoredNlsProperties");
            props = doGetStoredNlsProperties(loc);
            cacheOptionsIfPossible(loc, props);
        }
        return props;
    }

    /**
     * 加载语言包内容
     *
     * @param loc 目标区域
     * @return 语言包内容
     */
    protected abstract Properties doGetStoredNlsProperties(Locale loc);

    /**
     * 获取给定区域缓存的语言包内容
     *
     * @param loc 目标区域
     * @return 语言包内容
     */
    private Properties getCachedNlsProperties(Locale loc) {
        Properties props = null;

        Cache<Object, Properties> cache = getAvailableLocaleCache();
        if (null != cache) {
            LOG.trace("Attempting to retrieve the NlsProperties from cache.");
            Object key = getLocaleCacheKey(loc);
            props = cache.get(key);
            if (null == props) {
                LOG.trace("No NlsProperties found in cache for key [{}]", key);
            } else {
                LOG.trace("Found cached NlsProperties for key [{}]", key);
            }
        }

        return props;
    }

    /**
     * 缓存目标区域的语言包内容
     *
     * @param loc   目标区域
     * @param props 语言包内容
     */
    private void cacheOptionsIfPossible(Locale loc, Properties props) {
        if (null == props) {
            return;
        }
        if (!isCachingEnabled()) {
            LOG.debug("NlsBundle caching is disabled for locale [{}].  NlsBundle: [{}].", loc, props);
            //return quietly, caching is disabled for this token/info pair:
            return;
        }

        Cache<Object, Properties> cache = getAvailableLocaleCache();
        if (null != cache) {
            Object key = getLocaleCacheKey(loc);
            cache.put(key, props);
            LOG.trace("Cached NlsBundle.  key=[{}], value=[{}].", key, props);
        }
    }

    /**
     * 清空语言包缓存
     */
    protected void clearCachedNlsBundles() {
        Cache<Object, Properties> cache = getAvailableLocaleCache();
        if (null != cache) {
            cache.clear();
        }
    }

    /**
     * 清除给定区域的语言包缓存
     *
     * @param loc 目标区域
     */
    protected void clearCachedNlsBundle(Locale loc) {
        if (null != loc) {
            Cache<Object, Properties> cache = getAvailableLocaleCache();
            if (null != cache) {
                cache.remove(getLocaleCacheKey(loc));
            }
        }
    }

    /**
     * 获取目标区域的缓存 Key
     *
     * @param loc 目标区域
     * @return 该区域的缓存 Key
     */
    private Object getLocaleCacheKey(Locale loc) {
        return null != loc ? loc.toString() : "";
    }

    /**
     * 获取有效的语言包缓存
     *
     * @return 语言包缓存
     */
    protected Cache<Object, Properties> getAvailableLocaleCache() {
        Cache<Object, Properties> cache = getNlsBundleCache();
        boolean cachingEnabled = isCachingEnabled();
        if (null == cache && cachingEnabled) {
            cache = getLocaleCacheLazy();
        }
        return cache;
    }

    private Cache<Object, Properties> getLocaleCacheLazy() {
        if (this.nlsBundleCache == null) {
            LOG.trace("No NlsBundleCache instance set.  Checking for a cacheManager...");

            CacheManager cacheManager = getCacheManager();

            if (null != cacheManager) {
                String cacheName = getNlsBundleCacheName();
                LOG.debug("CacheManager [{}] configured.  Building NlsBundle cache '{}'", cacheManager, cacheName);
                this.nlsBundleCache = cacheManager.getCache(cacheName);
            }
        }

        return this.nlsBundleCache;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String translate(String text, Locale loc, String def) {
        Properties props = getStoredNlsProperties(loc);
        props = null != props ? props : new Properties();
        String value = props.getProperty(text);
        if (!StringUtils.hasText(text)) {
            value = super.translate(text, loc, null);

            if (StringUtils.hasText(value)) {
                props.put(text, value);
                cacheOptionsIfPossible(loc, props);
            }
        }
        return null != value ? value : def;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @SuppressWarnings("unchecked")
    public Enumeration<String> getKeys(Locale loc) {
        Properties props = getStoredNlsProperties(loc);
        props = null != props ? props : new Properties();
        return (Enumeration<String>) props.propertyNames();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void store(Locale loc, Properties props) {
        cacheOptionsIfPossible(loc, props);
        doStoreNlsProperties(loc, props);
    }

    /**
     * 存储语言包
     *
     * @param loc   语言包区域
     * @param props 语言包内容
     */
    protected abstract void doStoreNlsProperties(Locale loc, Properties props);

}
