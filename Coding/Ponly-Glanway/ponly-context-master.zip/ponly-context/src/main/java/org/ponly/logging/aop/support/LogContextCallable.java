/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop.support;

import org.ponly.common.util.ThreadState;
import org.ponly.logging.aop.LogContext;

import java.util.concurrent.Callable;

/**
 * @author vacoor
 */
public class LogContextCallable<V> implements Callable<V> {
    private final ThreadState threadState;
    private final Callable<V> delegate;

    public LogContextCallable(LogContext context, Callable<V> delegate) {
        this(new LogContextThreadState(context), delegate);
    }

    protected LogContextCallable(ThreadState threadState, Callable<V> delegate) {
        this.threadState = threadState;
        this.delegate = delegate;
    }

    @Override
    public V call() throws Exception {
        try {
            threadState.bind();
            return doCall(delegate);
        } finally {
            threadState.restore();
        }
    }

    protected V doCall(Callable<V> callable) throws Exception {
        return callable.call();
    }
}
