package org.ponly.nls.mgt;

import org.ponly.nls.NlsBundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

import static org.ponly.common.util.Throwables.rethrowRuntimeException;

/**
 * 基于 Properties 文件存储的语言包管理器
 *
 * @author vacoor
 */
public class PropertyNlsBundleManager extends CachingNlsBundleManager {
    private static final Logger LOG = LoggerFactory.getLogger(PropertyNlsBundleManager.class);
    private static final Charset UTF_8 = Charset.forName("UTF-8");
    public static final String SUFFIX = "properties";
    public static final String DEFAULT_BASENAME = "nls.messages";   // 默认的语言包 basename
    private String basename = DEFAULT_BASENAME;

    public String getBasename() {
        return basename;
    }

    public void setBasename(String basename) {
        this.basename = basename;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NlsBundle getBundle(Locale loc) {
        return new DelegatingNlsBundle(this, loc);
    }

    @Override
    protected String doTranslateInternal(String text, Locale tLoc, String def) {
        return def;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Properties doGetStoredNlsProperties(Locale loc) {
        String bundleName = toBundleName(basename, loc);            //
        String resourceName = toResourceName(bundleName, SUFFIX);   //
        Properties props = null;

        try {
            InputStream is = getClass().getClassLoader().getResourceAsStream(resourceName);
            if (null != is) {
                props = new Properties();
                props.load(new InputStreamReader(is, UTF_8));
                is.close();
            }
        } catch (IOException e) {
            rethrowRuntimeException(e);
        }

        return props;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void doStoreNlsProperties(Locale loc, Properties props) {
        String bundleName = toBundleName(basename, loc);
        String resourceName = toResourceName(bundleName, SUFFIX);
        try {
            File f = new File(new File(getClass().getClassLoader().getResource(".").toURI()), resourceName);
            if (!f.getParentFile().exists()) {
                f.getParentFile().mkdirs();
            }

            OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(f), UTF_8);
            props.store(writer, "native language mgt bundle: " + loc);
            writer.flush();
            writer.close();
        } catch (Exception e) {
            rethrowRuntimeException(e);
        }
    }

    private static final ResourceBundle.Control BUNDLE_CONTROL = ResourceBundle.Control.getControl(ResourceBundle.Control.FORMAT_DEFAULT);

    /**
     * {@link ResourceBundle.Control#toBundleName(String, Locale)}
     */
    protected String toBundleName(String baseName, Locale loc) {
        return BUNDLE_CONTROL.toBundleName(baseName, loc);
    }

    protected String toResourceName(String bundleName, String suffix) {
        return BUNDLE_CONTROL.toResourceName(bundleName, suffix);
    }
}
