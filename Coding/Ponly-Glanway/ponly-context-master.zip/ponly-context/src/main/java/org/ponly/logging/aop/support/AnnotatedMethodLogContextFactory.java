/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.logging.aop.support;

import org.ponly.logging.aop.LogContext;
import org.ponly.logging.aop.LogContextFactory;
import org.ponly.logging.aop.LogMetadata;
import org.ponly.logging.aop.annotation.Log;
import org.springframework.core.annotation.AnnotationUtils;

import java.lang.reflect.Method;

/**
 * @author vacoor
 */
public class AnnotatedMethodLogContextFactory implements LogContextFactory<Method> {

    @Override
    public LogContext createLogContext(Method method) {
        Log point = AnnotationUtils.findAnnotation(method, Log.class);
        // millis
        if (null == point) {
            return null;
        }
        String name = point.name();
        int level = point.level();
        String template = point.value();
        String[] tags = point.tags();
        boolean enabled = point.enabled();

        name = "#default#".equals(name) ? method.toString() : name;

        return new DefaultLogContext(new LogMetadata(name, level, template, tags, enabled));
    }

}
