package org.ponly.spring.util;

import com.google.common.collect.Sets;
import org.springframework.beans.factory.BeanFactoryUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.handler.AbstractHandlerMethodMapping;
import org.springframework.web.servlet.handler.AbstractUrlHandlerMapping;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;

import java.util.Map;
import java.util.Set;

/**
 */
public abstract class SpringWebMvcUtils {

    @SuppressWarnings("unchecked")
    public static void getMethodMappingUrls(ApplicationContext context) {
        Map<String, AbstractHandlerMethodMapping> mappingMap = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, AbstractHandlerMethodMapping.class, true, false);
        for (Map.Entry<String, AbstractHandlerMethodMapping> entry : mappingMap.entrySet()) {
            AbstractHandlerMethodMapping methodMapping = entry.getValue();
            Map<RequestMappingInfo, HandlerMethod> handlerMethods = methodMapping.getHandlerMethods();
        }
    }

    /**
     * 获取所有 Spring Web MVC 映射的 URL
     *
     * @param context
     * @return
     */
    @SuppressWarnings("unchecked")
    public static Set<String> getMappedUrls(ApplicationContext context) {
        Set<String> urls = Sets.newHashSet();
        Map<String, HandlerMapping> mappingMap = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, HandlerMapping.class, true, false);

        for (Map.Entry<String, HandlerMapping> entry : mappingMap.entrySet()) {
            HandlerMapping mapping = entry.getValue();
            /**
             * <pre>
             * HandlerMapping
             *  |- AbstractHandlerMapping
             *      |- AbstractUrlHandlerMapping
             *          |- SimpleUrlHandlerMapping
             *          |- AbstractDetectingUrlHandlerMapping
             *              |- BeanNameUrlHandlerMapping
             *      |- AbstractHandlerMethodMapping
             *          |- RequestMappingInfoHandlerMapping
             *              |- RequestMappingHandlerMapping
             * </pre>
             */
            if (mapping instanceof AbstractUrlHandlerMapping) {
                AbstractUrlHandlerMapping urlHandlerMapping = (AbstractUrlHandlerMapping) mapping;
                Map<String, Object> handlerMap = urlHandlerMapping.getHandlerMap();
                for (String url : handlerMap.keySet()) {
                    urls.add(url);
                }
            } else if (mapping instanceof AbstractHandlerMethodMapping) {
                AbstractHandlerMethodMapping methodMapping = (AbstractHandlerMethodMapping) mapping;
                Map<RequestMappingInfo, HandlerMethod> handlerMethods = methodMapping.getHandlerMethods();
                for (Map.Entry<RequestMappingInfo, HandlerMethod> handlerEntry : handlerMethods.entrySet()) {
                    RequestMappingInfo key = handlerEntry.getKey();
                    HandlerMethod value = handlerEntry.getValue();
                    Set<String> patterns = key.getPatternsCondition().getPatterns();
                    for (String pattern : patterns) {
                        urls.add(pattern);
                    }
                }
            } else {
                System.err.println("忽略未知类型:" + mapping);
            }
        }
        return urls;
    }

    private SpringWebMvcUtils() {
    }
}
