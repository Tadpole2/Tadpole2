package org.ponly.nls;

import java.text.MessageFormat;
import java.util.ResourceBundle;

/**
 * 本地语言包 (Native language mgt bundle)
 * <p>
 * 该类继承 ResourceBundle 只是为了在某些地方可以直接使用
 *
 * @author vacoor
 */
public abstract class NlsBundle extends ResourceBundle {

    /**
     * 获取语言包中翻译后的内容
     *
     * @param key 翻译 key
     * @param arguments 翻译参数
     * @return 翻译后的内容, 如果不存在则返回 null
     */
    public String getMessage(String key, Object... arguments) {
        String text = getString(key);
        return null != text ? new MessageFormat(text, getLocale()).format(arguments) : null;
    }

}
