package org.ponly.nls.mgt;

import org.ponly.nls.NlsBundle;
import org.ponly.nls.NlsBundleManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;

/**
 * @author vacoor
 */
public abstract class AbstractNlsBundleManager implements NlsBundleManager {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractNlsBundleManager.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public NlsBundle getBundle(Locale loc) {
        return new DelegatingNlsBundle(this, loc);
    }

    @Override
    public String translate(String text, Locale loc) {
        return translate(text, loc, null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String translate(String text, Locale loc, String def) {
        if (null == text || text.length() < 1) {
            return "";
        }
        int p = 0;
        String pair;
        StringBuilder buff = new StringBuilder();

        // 处理参数占位符
        for (int s = -1, e = -1; -1 < (s = text.indexOf("{", e)) && -1 < (e = text.indexOf("}", s)); ) {
            int b = s;
            // 减去空白
            while (-1 < b && Character.isWhitespace(text.charAt(b - 1))) {
                b--;
            }

            pair = text.substring(p, b);    // 需要翻译的内容
            if (pair.length() > 0) {
                pair = doTranslateInternal(pair, loc, def);
            }

            p = e + 1;
            while (p < text.length() && Character.isWhitespace(text.charAt(p))) {
                p++;
            }

            buff.append(pair).append(text.substring(b, s)/*前空白*/).append(text.substring(s, e + 1)).append(text.substring(e + 1, p)/*后空白*/);
            s = b;
        }
        pair = text.substring(p, text.length());
        if (pair.length() > 0) {
            pair = doTranslateInternal(pair, loc, def);
        }
        buff.append(pair);

        return buff.toString();
    }

    /**
     * 执行内部翻译， 将 fLoc 语言的 text 内容翻译为 tLoc, 如果翻译失败返回默认值
     *
     * @param text 要翻译的内容
     * @param tLoc 目标语言
     * @param def  默认值
     * @return 翻译后的内容或默认值
     */
    protected abstract String doTranslateInternal(String text, Locale tLoc, String def);
}
