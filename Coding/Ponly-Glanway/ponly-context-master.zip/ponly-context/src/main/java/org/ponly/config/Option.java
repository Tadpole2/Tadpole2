/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.config;

import java.io.Serializable;

/**
 * 配置项
 *
 * @author vacoor
 */
public class Option implements Serializable {
    private Long id;
    /**
     * 配置项名称
     */
    private String name;
    /**
     * 配置项描述
     */
    private String intro;
    /**
     * 配置项备注
     */
    private String note;
    /**
     * 配置项类型, bool, string, bstring
     */
    private String type;    // bool -- radio, string -- textarea
    /**
     * 配置项值
     */
    private String value;
    /**
     * 配置项所属分组
     */
    private String category;
    /**
     * 配置项排序
     */
    private Integer position;

    public Option() {
    }

    public Option(Long id, String name, String intro, String note, String type, String value, String category, Integer position) {
        this.id = id;
        this.name = name;
        this.intro = intro;
        this.note = note;
        this.type = type;
        this.value = value;
        this.category = category;
        this.position = position;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (null == other || getClass() != other.getClass()) {
            return false;
        }
        Option that = (Option) other;
        return getId() == that.getId() || (null != getId() && getId().equals(that.getId())); //|| getName() == that.getName() || (null != getName() && getName().equals(that.getName()));
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : (name != null ? name.hashCode() : 0);
        // return name != null ? name.hashCode() : 0;
    }

    @Override
    public String toString() {
        return name + " = " + value;
    }
}
