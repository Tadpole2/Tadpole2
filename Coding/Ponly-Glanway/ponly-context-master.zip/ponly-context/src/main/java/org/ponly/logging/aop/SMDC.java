package org.ponly.logging.aop;

import org.ponly.common.util.ThreadContext;

/**
 * Simple MDC (Mapped Diagnostic Context)
 * 之所以加个 S 为了与其他日志系统区分
 *
 * @author vacoor
 */
public abstract class SMDC {
    public static void put(String key, Object val) throws IllegalArgumentException {
        if (key == null) {
            throw new IllegalArgumentException("key parameter cannot be null");
        }
        getRequiredContext().put(key, val);
    }

    public static Object get(String key) throws IllegalArgumentException {
        if (key == null) {
            throw new IllegalArgumentException("key parameter cannot be null");
        }

        return getRequiredContext().get(key);
    }

    public static void remove(String key) throws IllegalArgumentException {
        if (key == null) {
            throw new IllegalArgumentException("key parameter cannot be null");
        }

        getRequiredContext().remove(key);
    }

    public static void clear() {
        getRequiredContext().clear();
    }

    public static LogContext getRequiredContext() {
        LogContext context = getContext();
        if (context == null) {
            throw new IllegalStateException("No LogPointContext found");
        }
        return context;
    }

    private SMDC() {
    }

    public static LogContext getContext() {
        return (LogContext) ThreadContext.get(LogContext.CONTEXT_THREAD_KEY);
    }
}
