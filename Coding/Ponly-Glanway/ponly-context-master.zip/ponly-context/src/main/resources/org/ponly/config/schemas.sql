drop table if exists T_OPTION;

/*==============================================================*/
/* Table: T_OPTION                                              */
/*==============================================================*/
create table T_OPTION
(
   ID                   INTEGER not null auto_increment comment 'ID',
   NAME                 VARCHAR(255) not null comment '名称',
   INTRO                VARCHAR(255) not null comment '描述',
   NOTE                 VARCHAR(255) comment '备注',
   TYPE                 VARCHAR(255) comment '类型',
   VALUE                VARCHAR(500) comment '值',
   CATEGORY             VARCHAR(255) comment '分组',
   POSITION             INTEGER comment '排序',
   primary key (ID)
);

alter table T_OPTION comment '系统配置';
