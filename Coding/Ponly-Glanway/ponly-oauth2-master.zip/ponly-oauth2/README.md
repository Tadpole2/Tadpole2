# Ponly-Oauth2 第三方登录开发文档
## 一、准备工作
	1注册成为第三方互联平台的开发者
	具体注册步骤可查询第三方的开放平台，QQ，新浪微博等都有相应的官方新手指引文档。
	2准备一个可以访问的域名
	3创建网页应用，配置必要信息，其中包括域名及回调地址，其中域名需要验证，需确保对域名主机有足够的控制权限
	4获取应用appID 和appKey进行开发。
	5开发平台的登录授权采取oauth2.0机制，这也是目前几乎所有互联网开放平台所采取的方式。以QQ登录为例!

![Image](flow.png)



## 二、开发阶段
	ponly-oauth2-0.1-SNAPSHOT.jar包中提供了第三方登录相关过滤器及实现方式。目前支持：豆瓣、Github、QQ、人人、淘宝、微信、新浪微博。
### 1、maven 配置信息：
```
	<dependency>
        <groupId>org.ponly</groupId>
        <artifactId>ponly-oauth2</artifactId>
        <version>0.1-SNAPSHOT</version>
   </dependency>
```
### 2、web.xml配置过滤器
```
<filter>
        <filter-name>oauth2</filter-name>
	<filter-class>org.ponly.oauth2.support.PropertiesOauth2WebRealmFilter</filter-class>
        <init-param>
            <param-name>oauth.qq.appid</param-name>
            <param-value>101294503</param-value>
        </init-param>
        <init-param>
            <param-name>oauth.qq.appkey</param-name>
            <param-value>a6ea79630c2ecd8bf2034f18092894b9</param-value>         
        </init-param>
        <init-param>
            <param-name>prefix</param-name>
            <param-value>/oauth</param-value>
        </init-param>
    </filter>
    <filter-mapping>
        <filter-name>oauth2</filter-name>
        <!--
            认证地址: /oauth/{channel} or /oauth/{channel}/authorize
            授权回调: /oauth/{channel}/callback
        -->
        <url-pattern>/oauth/*</url-pattern>
    </filter-mapping>
```
说明：oauth.qq.appid和oauth.qq.appkey参数即第一步中在QQ开放互联平台申请获取的appid和appkey。

第三方平台与对应英文配置表

| 第三方平台名称 | 对应配置值 |
|--------|--------|
|豆瓣	|douban|
|GitHub|	github|
|QQ	|qq|
|人人	|renren|
|淘宝	|taobao|
|微信	|wechat|
|新浪微博|	weibo|

添加对应第三方支持只需要添加对应配置值的参数及相应值即可
例如：如果现在要增加支持新浪微博第三方登录则需要在过滤器中增加参数
```
		<init-param>
            <param-name>oauth.weibo.appid</param-name>
            <param-value>此处为第三方开发平台申请的appid</param-value>
        </init-param>
        <init-param>
            <param-name>oauth.weibo.appkey</param-name>
            <param-value>此处为第三方开发平台申请的appkey</param-value>
        </init-param>
```



### 3、Controller写法：
```
/**
 * 第三方登录
 */
@Controller
@RequestMapping("oauth")
public class Oauth2Controller {

	@Autowired
	private MemberService memberService;

	@Autowired
	private OauthBindService oauthBindService;

    @RequestMapping("{channel}/callback")
    public String callback(@PathVariable("channel") String channel, HttpServletRequest request,HttpSession session) {
        String openid = Oauth2Utils.getOpenid(request);
        String nickname = Oauth2Utils.getNickname(request);
        String avatarUrl = Oauth2Utils.getAvatarUrl(request);
        if (null == openid) {
            // 重新认证
            return "redirect:/oauth/" + channel;
        }else{
        	Member member = (Member)session.getAttribute("usersinfo");
        	if(null != member){
        		//判断当前用户是否已经绑定此openid      已绑定且是此用户跳转登录成功        绑定账号不是此用户，登录失败            未绑定Q直接绑定并返回成功
        		OauthBind oauth = oauthBindService.findOne("memberId", member.getId());
        		if(null==oauth){
        			//当前用户已经登录，但没有绑定到当前登录信息
        		}else{
        			if(oauth.getOpenid().equals(openid)){
            			//当前已登录用户就是已经绑定的本次登录用户     直接返回首页
            			return "redirect:/";
            		}else{
            			//当前已经登录的用户已经绑定第三方登录但不是正在登录的第三方信息
            		}
        		}
        	}else{
        		//注册默认用户  或跳转到绑定用户界面    现在直接做生成默认账户并绑定处理
        		Map<String,Object> params = new HashMap<String,Object>();
        		params.put("openid", openid);
        		OauthBind oauthB = oauthBindService.findOne(params);
        		if(null!=oauthB){  //已经授权登录过
        			Member memberInfo = new Member();
        			memberInfo.setId(oauthB.getMemberId());
        			memberInfo = memberService.selectById(memberInfo);
        			memberInfo.setLastLoginTime(new Date());
        			memberService.update(memberInfo);
        			session.setAttribute("usersinfo", memberInfo);
            		session.setAttribute("userType", memberInfo.getUserType());
        		}else{
        			//first 注册默认账户
            		Member defMember = new Member();
            		defMember.setNickName(nickname);
            		defMember.setHeadImage(avatarUrl);
            		defMember.setRegister(new Date());
            		defMember.setIsActive(true);
            		defMember.setDeleted(false);
            		defMember.setStatus(0);
            		defMember.setUserType("1");
            		defMember.setLastLoginTime(new Date());
            		memberService.insert(defMember);
            		//绑定认证
            		OauthBind oauthBind = new OauthBind();
            		oauthBind.setMemberId(defMember.getId());
            		oauthBind.setChannel(channel);
            		oauthBind.setOpenid(openid);
            		oauthBind.setCreatedDate(new Date());
            		oauthBindService.save(oauthBind);
            		session.setAttribute("usersinfo", defMember);
            		session.setAttribute("userType", defMember.getUserType());
        		}
        	}
        }
        return "redirect:/";
    }
}
```
Controller中的Callback回调用来接受第三方返回的用户信息。我们需要做的就是把第三方传过来的用户信息进行验证处理即可。
注：此程序中的{channel}即是用来支持多种第三方登录的。例：qq登录时，传进来的参数就是qq,新浪微博登录时参数就是weibo。

前台第三方登录入口访问路径：${ctx}/oauth/{channel}
例：qq: ${ctx}/oauth/qq
	weibo: ${ctx}/oauth/weibo
	豆瓣：${ctx}/oauth/douban
	......