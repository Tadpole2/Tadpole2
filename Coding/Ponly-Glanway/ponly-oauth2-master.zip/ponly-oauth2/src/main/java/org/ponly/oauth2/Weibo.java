package org.ponly.oauth2;

import java.io.IOException;
import java.util.Map;

/**
 * http://open.weibo.com/development
 * http://open.weibo.com/authentication
 */
public class Weibo extends Oauth2 {
    private static final String WB_AUTHORIZE_URL = "https://api.weibo.com/oauth2/authorize";
    private static final String WB_ACCESS_TOKEN_URL = "https://api.weibo.com/oauth2/access_token";
    private static final String WB_TOKEN_INFO_URL = "https://api.weibo.com/oauth2/get_token_info";
    private static final String WB_USER_INFO_URL = "https://api.weibo.com/2/users/show.json";

    /**
     * 根据给定的配置参数创建一个 OAuth 认证/授权对象
     *
     * @param clientId     OAuth 2 应用 appid
     * @param clientSecret OAuth 2 应用 appkey
     * @param redirectUri  OAuth 2 应用授权回调URL
     */
    public Weibo(String clientId, String clientSecret, String redirectUri) {
        super(WB_AUTHORIZE_URL, WB_ACCESS_TOKEN_URL, clientId, clientSecret, redirectUri);
    }

    @Override
    protected AccessTokenInfo doParseJsonAccessToken(Map<String, Object> ret) {
        /**
         * access_token:
         * expires_in:
         * uid:
         */
        AccessTokenInfo info = super.doParseJsonAccessToken(ret);
        String uid = String.valueOf(ret.get("uid"));
        return new AccessTokenInfo(info.accessToken, info.tokenType, info.expiresIn, info.refreshToken, info.scope, uid);
    }

    @Override
    public Map<String, Object> getOpenInfo(AccessTokenInfo accessToken) throws IOException {
        Map<String, String> params = createParams();
        params.put("access_token", accessToken.accessToken);
        params.put("uid", accessToken.openid);      // 需要查询的用户ID

        String json = doHttpGet(WB_USER_INFO_URL, params);
        Map<String, Object> ret = asJsonMap(json);
        Object uid = ret.get("id");
        Object idstr = ret.get("idstr");
        Object screen_name = ret.get("screen_name");    // 昵称
        Object name = ret.get("name");  // 友好显示昵称
        Object gender = ret.get("gender");  // F/M/N
        String avatarUrl = null;
        String[] avatarKeys = {
                "avatar_hd",            // 头像地址 HD
                "avatar_large",         // 头像地址 180x180
                "profile_image_url"     // 头像地址 50x50
        };
        for (String avatarKey : avatarKeys) {
            Object url = ret.get(avatarKey);
            if (url instanceof String && 0 < ((String) url).length()) {
                avatarUrl = (String) url;
                break;
            }
        }

        ret.put(OPENID_KEY, idstr);
        ret.put(NICKNAME_KEY, screen_name);
        ret.put(AVATAR_URL_KEY, avatarUrl);
        return ret;
    }

    public static void main(String[] args) {
        Weibo weibo = new Weibo("1912701706", "70ed5fa02d65cfafd3c7c818acdc75fd", "http://g.ngrok.cc/oauth/weibo");
        String authorizeUrl = weibo.getAuthorizeUrl("");
        System.out.println(authorizeUrl);
    }
}
