package org.ponly.oauth2;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * 人人网
 * http://dev.renren.com/website
 * http://open.renren.com/wiki/OAutj jh2.0
 */
public class Renren extends Oauth2 {
    private static final String RR_AUTHORIZE_URL = "https://graph.renren.com/oauth/authorize";
    private static final String RR_ACCESS_TOKEN_URL = "https://graph.renren.com/oauth/token";

    /**
     * 根据给定的配置参数创建一个 OAuth 认证/授权对象
     *
     * @param apiKey       OAuth 2 应用 appid
     * @param apiSecret   OAuth 2 应用 appkey
     * @param redirectUri    OAuth 2 应用授权回调URL
     */
    public Renren(String apiKey, String apiSecret, String redirectUri) {
        super(RR_AUTHORIZE_URL, RR_ACCESS_TOKEN_URL, apiKey, apiSecret, redirectUri);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected AccessTokenInfo doParseJsonAccessToken(Map<String, Object> ret) {
        String access_token = (String) ret.get("access_token");
        String tokenType = (String) ret.get("token_type");  // bearer
        // String expires_in = (String) ret.get("expires_in");
        String refresh_token = (String) ret.get("refresh_token");
        Object id = ((Map<String, Object>) ret.get("user")).get("id");
        String openid = null != id ? String.valueOf(id) : null;
        return new AccessTokenInfo(access_token, tokenType, 0, refresh_token, null, openid, ret);
    }

    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> getOpenInfo(AccessTokenInfo accessToken) throws IOException {
        Map<String, Object> user = (Map<String, Object>) accessToken.rawData.get("user");
        String avatarUrl = null;

        List<Map<String, Object>> avatars = (List<Map<String, Object>>) user.get("avatar");
        if (null != avatars) {
            for (Map<String, Object> avatar : avatars) {
                if(!"large".equals(avatar.get("type"))) {  // type: avatar, tiny, main, large
                    continue;
                }

                Object url = avatar.get("url");
                if (null != url && !"".equals(url)) {
                    avatarUrl = String.valueOf(url);
                    break;
                }
            }
        }
        user.put(OPENID_KEY, accessToken.openid);
        user.put(NICKNAME_KEY, user.get("name"));
        user.put(AVATAR_URL_KEY, avatarUrl);
        return user;
    }
}
