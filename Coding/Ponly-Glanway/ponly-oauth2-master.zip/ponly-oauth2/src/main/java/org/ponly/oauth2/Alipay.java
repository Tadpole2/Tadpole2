package org.ponly.oauth2;

import org.ponly.common.util.HttpUtils;

import java.io.IOException;
import java.util.Map;

/**
 * Created by vacoor on 2/26/16.
 * https://doc.open.alipay.com/doc2/detail?treeId=65&articleId=103570&docType=1
 */
public class Alipay extends Oauth2 {
    private static final String GATEWAY_URL = "https://mapi.alipay.com/gateway.do";

    private final String pid;

    public Alipay(String authorizeUrl, String accessTokenUrl, String appKey, String appSecret, String redirectUri, String pid) {
        super(authorizeUrl, accessTokenUrl, appKey, appSecret, redirectUri);
        this.pid = pid;
    }

    @Override
    public String getAuthorizeUrl(String sessionState) {
        Map<String, String> params = createParams();
        params.put("_input_charset", "utf-8");
        params.put("service", "alipay.auth.authorize");
        params.put("target_service", "user.auth.quick.login");
        params.put("partner", "alipay.auth.authorize");
        params.put("return_url", "http://g.ngrok.cc/oauth/alipay/callback");
        params.put("anti_phishing_key", sessionState);  // 防钓鱼时间戳
        params.put("exter_invoke_ip", "");

        return GATEWAY_URL + "?" + HttpUtils.buildQuery(params, "utf-8");
    }

    @Override
    public Map<String, Object> getOpenInfo(AccessTokenInfo accessToken) throws IOException {
        return null;
    }

    public static void main(String[] args) {
        Alipay alipay = new Alipay(null, null, null, null, null, "2088121001015522");
        System.out.println(alipay.getAuthorizeUrl(""));
    }
}
