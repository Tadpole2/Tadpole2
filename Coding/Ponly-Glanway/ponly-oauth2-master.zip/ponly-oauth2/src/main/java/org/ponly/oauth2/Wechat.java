package org.ponly.oauth2;

import com.google.common.collect.Maps;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.Map;
import org.ponly.common.util.HttpUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 微信 Oauth2 授权
 * 微信授权分为两种: (认证地址和使用场景是不同的)
 * 1. 开放平台 (http://open.weixin.qq.com)
 *   使用场景:
 *      1. PC 站点中点击微信认证, 跳转到微信扫码页面
 *      2. 扫码后跳转会用户网站
 *   申请: 微信开放平台 - 管理中心 - 移动应应用(已审核通过) - 微信登录，进入微信登录功能申请页面，根据页面提示进行申请即可。
 * 2. 公众账号/微信支付 (http://mp.weixin.qq.com)
 *   使用场景:
 *      1. 微信中打开网页(通过公众号/扫码等)
 *      2. 跳转到微信授权地址
 *         如果授权作用域为 snapi_base, 则无感知, 但是只能获取 openid
 *         如果授权作用域为 snapi_userinfo, 如果用户关注了公众号, 则无感知, 否则询问授权
 *      3. 返回用户网站
 *   申请: 进入公众号 (http://mp.weixin.qq.com) - 微信支付 - 开发配置 - 支付授权目录
 *
 * 开放平台授权: https://open.weixin.qq.com/cgi-bin/showdocument?action=dir_list&t=resource/res_list&verify=1&id=open1419316505&token=&lang=zh_CN
 * 微信浏览器授权: http://mp.weixin.qq.com/wiki/17/c0f37d5704f0b64713d5d2c37b468d75.html
 */
public class Wechat extends Oauth2 {
    private static final Logger LOGGER = LoggerFactory.getLogger(Wechat.class);
    public static final String WECHAT_OPEN_AUTHORIZE_URL = "https://open.weixin.qq.com/connect/qrconnect";
    public static final String WECHAT_NATIVE_AUTHORIZE_URL = "https://open.weixin.qq.com/connect/oauth2/authorize";
    public static final String WECHAT_ACCESS_TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token";
    public static final String WECHAT_USER_INFO_URL = "https://api.weixin.qq.com/sns/userinfo";
    public static String SCOPE_SNSAPI_LOGIN = "snsapi_login";
    public static String SCOPE_SNSAPI_BASE = "snsapi_base";
    public static String SCOPE_SNSAPI_USERINFO = "snsapi_userinfo";
    public static final String WECHAT_UNIONID_KEY = Wechat.class.getName() + ".unionid";

    protected String scope;

    /**
     * 根据给定的配置参数创建一个 OAuth 认证/授权对象
     *
     * @param appKey      OAuth 2 应用 appid
     * @param appSecret   OAuth 2 应用 appkey
     * @param redirectUri OAuth 2 应用授权回调URL
     */
    public Wechat(String scope, String appKey, String appSecret, String redirectUri) {
        super(checkAndGetAuthorizeUrl(scope), WECHAT_ACCESS_TOKEN_URL, appKey, appSecret, redirectUri);
        this.scope = scope;
    }

    protected static String checkAndGetAuthorizeUrl(String scope) {
        // 开放平台
        if (SCOPE_SNSAPI_LOGIN.equals(scope)) {
            return WECHAT_OPEN_AUTHORIZE_URL;
        }
        if (SCOPE_SNSAPI_BASE.equals(scope) || SCOPE_SNSAPI_USERINFO.equals(scope)) {
            return WECHAT_NATIVE_AUTHORIZE_URL;
        }
        throw new IllegalArgumentException("ILLEGAL_AUTHORIZE_SCOPE:" + scope);
    }

    public String getAuthorizeUrl(String sessionState) {
        /*
        Map<String, String> params = Maps.newHashMap();
        params.put("response_type", "code");         // 授权类型, 此处固定值 code
        // params.put("client_id", clientId);            // 被授权的 appid
        params.put("appid", clientId);               // 被授权的 appid
        params.put("redirect_uri", redirectUri);    // 授权回调 URL
        params.put("scope", scope);                   // snapi_login 对于支付平台为 snsapi_userinfo/snsapi_base(只能获取openid)
        // WARN: state 放在 scope 前面会提示错误, 真是奇葩
        params.put("state", sessionState);            // oauth 2.0 建议的状态参数, 防止 CSRF

        return authorizeUrl + "?" + HttpUtils.buildQuery(params, "utf-8") + "#wechat_redirect";
        */
        return authorizeUrl + "?appid=" + clientId + "&redirect_uri=" + encode(redirectUri, "UTF-8") + "&response_type=code&scope=" + scope + "&state=" + sessionState + "#wechat_redirect";
    }

    /**
     * 获取 OAuth 2.0 的访问Token
     *
     * @param authorizationCode 用户完成授权后, 授权服务器通过回调返回的授权码
     * @return 根据 authorization code 获取的 access token
     * @throws IOException
     */
    public AccessTokenInfo getAccessToken(String authorizationCode) throws IOException {
        // Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
        final String finalUrl = accessTokenUrl + "?appid=" + clientId + "&secret=" + clientSecret + "&code=" + authorizationCode + "&grant_type=authorization_code";
        final HttpURLConnection conn = HttpUtils.getConnection(finalUrl, "GET", "application/x-www-form-urlencoded");
        final String ctype = conn.getHeaderField("Content-Type");
        final String responseBody = HttpUtils.getResponseAsString(conn);

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("getAccessToken(): authorizationCode: {}, ctype: {}, responseBody: {}", authorizationCode, ctype, responseBody);
        }

        /*
        // HttpURLConnection conn = HttpUtils.getConnection(accessTokenUrl, "POST", "application/x-www-form-urlencoded");
        Map<String, String> params = Maps.newHashMap();
        params.put("grant_type", "authorization_code");
        params.put("code", authorizationCode);
//        params.put("client_id", clientId);
//        params.put("client_secret", clientSecret);
        params.put("appid", clientId);
        params.put("secret", clientSecret);
        // params.put("redirect_uri", redirectUri);

//         对于 Github 等默认返回的是 application/x-www-form-urlencoded:
//         access_token=e72e16c7e42f292c6912e7710c838347ae178b4a&scope=user%2Cgist&token_type=bearer
//         如果需要返回 json 需要指定 Accept: application/json
        // conn.setRequestProperty("Accept", "application/json");
        PrintWriter writer = new PrintWriter(conn.getOutputStream());
        writer.write(HttpUtils.buildRawQuery(params));
        writer.flush();

        int responseCode = conn.getResponseCode();
        String ctype = conn.getHeaderField("Content-Type");
        String responseBody = IOUtils.toString(conn.getInputStream(), Charset.forName("utf-8"), true);
        */

        AccessTokenInfo token = parseAccessToken(ctype, responseBody);
        if (null == token || null == token.openid) {
            token = doParseJsonAccessToken(asJsonMap(responseBody));
        }

        return token;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected AccessTokenInfo doParseJsonAccessToken(Map<String, Object> ret) {
        AccessTokenInfo info = super.doParseJsonAccessToken(ret);
        return new AccessTokenInfo(info.accessToken, info.tokenType, info.expiresIn, info.refreshToken, info.scope, (String) ret.get("openid"), ret);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, Object> getOpenInfo(AccessTokenInfo accessToken) throws IOException {
        Map<String, String> params = new HashMap<String, String>();
        params.put("access_token", accessToken.accessToken);
        params.put("openid", accessToken.openid);
        // params.put("lang", "zh_CN");

        Map<String, Object> info = Maps.newHashMap();

        // 如果是 snsapi_base 则无法获取用户信息, 只能获取openid.
        if (SCOPE_SNSAPI_BASE.equalsIgnoreCase(this.scope)) {
            info.put(OPENID_KEY, accessToken.openid);
        } else {
            final String body = doHttpGet(WECHAT_USER_INFO_URL, params);
            info = asJsonMap(body);

            /*-
             * update 2017.07.05 增加 unionid.
             */
            // 只有在用户将公众号绑定到微信开放平台帐号后，才会出现该字段
            final Object unionid = info.get("unionid");
            final Object newOpenid = info.get("openid");
            // final Object finalOpenid = null != unionid ? unionid : (null != newOpenid ? newOpenid : accessToken.openid);

            info.put(OPENID_KEY, newOpenid);
            info.put(NICKNAME_KEY, info.get("nickname"));
            info.put(AVATAR_URL_KEY, info.get("headimgurl"));
            info.put(WECHAT_UNIONID_KEY, unionid);
        }
        return info;
    }
}
