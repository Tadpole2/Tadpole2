package org.ponly.oauth2;

import java.io.IOException;
import java.util.Map;

/**
 * Github OAuth 2.0
 *
 * https://github.com/settings/profile --> OAuth applications
 *
 * @author vacoor
 */
public class Github extends Oauth2 {
    private static final String GITHUB_AUTHORIZE_URL = "https://github.com/login/oauth/authorize";
    private static final String GITHUB_ACCESS_TOKEN_URL = "https://github.com/login/oauth/access_token";
    private static final String GITHUB_USER_API_URL = "https://api.github.com/user";

    public Github(String appKey, String appSecret, String callbackUrl) {
        super(GITHUB_AUTHORIZE_URL, GITHUB_ACCESS_TOKEN_URL, appKey, appSecret, callbackUrl);
    }

    @Override
    public Map<String, Object> getOpenInfo(AccessTokenInfo accessToken) throws IOException {
        Map<String, String> params = createParams();
        params.put("access_token", accessToken.accessToken);
        String json = doHttpGet(GITHUB_USER_API_URL, params);

        Map<String, Object> user = asJsonMap(json);
        user.put(OPENID_KEY, String.valueOf(user.get("id")));
        user.put(NICKNAME_KEY, user.get("login"));
        user.put(AVATAR_URL_KEY, user.get("avatar_url"));
        return user;
    }
}
