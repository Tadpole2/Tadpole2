package org.ponly.oauth2;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Maps;
import org.ponly.common.json.Jacksons;
import org.ponly.common.util.HttpUtils;
import org.ponly.common.util.IOUtils;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

/**
 * 提供一个 <a href="http://tools.ietf.org/html/rfc6749#page-43">OAuth 2.0</a> 的基本实现
 * <p/>
 * OAuth 2.0 基本流程
 * 1. 客户端(含Web应用)需要用户授权, 发送一个资源授权请求(authorization request)到授权服务器的授权地址 (authorize url)
 * 2. 用户在授权地址完成授权, 授权服务器返回授权码(authorization code)到客户端
 * 3. 客户端通过授权码(authorization code)到授权服务器获取用户资源访问令牌 (access token)
 * 4. 客户端通过资源访问令牌 (access token) 获取用户信息 (这里一般做第三方登录, 因此一般是获取 OPENID)
 * <p/>
 * <code>
 * // 1. 获取授权重定向 URL (authorize url)
 * Oauth2 oauth2 = new Oauth2(authorizeUrl, accessTokenUrl, appId, appKey, redirectUri);
 * String authorizeUrl = oauth2.getAuthorizeUrl(state);
 * // 重定向到 authorize url
 * ...
 * // 2. 获取访问 token (access token) 和 用户信息(user info)
 * HttpServletRequest request = ...;
 * // 这里需要判断是否正确相应
 * String authorizationCode = request.getParameter("code");
 * Oauth2 oauth2 = new Oauth2(authorizeUrl, accessTokenUrl, appId, appKey, redirectUri);
 * Map&lt;String, Object&gt; info = oauth2.getAccessToken(authorizationCode);
 * String openid = (String) info.get(OPENID_KEY);
 * String nickname = (String) info.get(NICKNAME_KEY);
 * String avatarUrl = (String) info.get(AVATAR_URL_KEY);
 * </code>
 *
 * @author vacoor
 */
public abstract class Oauth2 {
    /**
     * 用户信息 openid key
     */
    public static final String OPENID_KEY = Oauth2.class.getName() + ".oauth_openid";
    /**
     * 用户信息 nickname key
     */
    public static final String NICKNAME_KEY = Oauth2.class.getName() + ".oauth_nickname";
    /**
     * 用户信息 avatar url key
     */
    public static final String AVATAR_URL_KEY = Oauth2.class.getName() + ".oauth_avatar_url";

    public static class AccessTokenInfo {
        public final String accessToken;
        public final String tokenType;
        public final long expiresIn;
        public final String refreshToken;
        public final String scope;
        public final String openid;         // weibo, renren, taobao
        protected final Map<String, Object> rawData;

        protected AccessTokenInfo(String accessToken, String tokenType, long expiresIn, String refreshToken, String scope) {
            this(accessToken, tokenType, expiresIn, refreshToken, scope, null);
        }

        protected AccessTokenInfo(String accessToken, String tokenType, long expiresIn, String refreshToken, String scope, String openid) {
            this(accessToken, tokenType, expiresIn, refreshToken, scope, openid, null);
        }

        protected AccessTokenInfo(String accessToken, String tokenType, long expiresIn, String refreshToken, String scope, String openid, Map<String, Object> rawData) {
            this.accessToken = accessToken;
            this.tokenType = tokenType;
            this.expiresIn = expiresIn;
            this.refreshToken = refreshToken;
            this.scope = scope;
            this.openid = openid;
            this.rawData = rawData;
        }
    }

    /* ******************************************************
     *
     * ******************************************************/

    protected final String authorizeUrl;    // 服务器授权 URL
    protected final String accessTokenUrl;  // 服务器访问 Token 换取URL
    protected final String clientId;        // OAuth 2 应用 appid
    protected final String clientSecret;    // OAuth 2 应用 appkey
    protected final String redirectUri;     // OAuth 2 授权回调地址

    /**
     * 根据给定的配置参数创建一个 OAuth 认证/授权对象
     *
     * @param authorizeUrl   服务器授权URL
     * @param accessTokenUrl 服务器访问Token换取URL
     * @param appKey         OAuth 2 应用 appid
     * @param appSecret      OAuth 2 应用 appkey
     * @param redirectUri    OAuth 2 应用授权回调URL
     */
    public Oauth2(String authorizeUrl, String accessTokenUrl, String appKey, String appSecret, String redirectUri) {
        this.authorizeUrl = authorizeUrl;
        this.accessTokenUrl = accessTokenUrl;
        this.clientId = appKey;
        this.clientSecret = appSecret;
        this.redirectUri = redirectUri;
    }

    /**
     * 获取 OAuth 2.0 请求授权的URL, 跳转到该 URL 进行授权
     *
     * @param sessionState 客户端的当前状态, 授权服务器会原封不动地返回这个值, 主要用于防止 CRSF
     * @return 用于给当前应用授权的 URL
     */
    public String getAuthorizeUrl(String sessionState) {
        Map<String, String> params = Maps.newHashMap();
        params.put("response_type", "code");        // 授权类型, 此处固定值 code
        params.put("client_id", clientId);          // 被授权的 appid
        params.put("redirect_uri", redirectUri);    // 授权回调 URL
        // params.put("scope", "");
        params.put("state", sessionState);                 // oauth 2.0 建议的状态参数

        return authorizeUrl + "?" + HttpUtils.buildQuery(params, "utf-8");
    }

    /**
     * 获取 OAuth 2.0 的访问Token
     *
     * @param authorizationCode 用户完成授权后, 授权服务器通过回调返回的授权码
     * @return 根据 authorization code 获取的 access token
     * @throws IOException
     */
    public AccessTokenInfo getAccessToken(String authorizationCode) throws IOException {
        // Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
        HttpURLConnection conn = HttpUtils.getConnection(accessTokenUrl, "POST", "application/x-www-form-urlencoded");

        Map<String, String> params = Maps.newHashMap();
        params.put("grant_type", "authorization_code");
        params.put("code", authorizationCode);
        params.put("client_id", clientId);
        params.put("client_secret", clientSecret);
        params.put("redirect_uri", redirectUri);

        /*-
         * 对于 Github 等默认返回的是 application/x-www-form-urlencoded:
         * access_token=e72e16c7e42f292c6912e7710c838347ae178b4a&scope=user%2Cgist&token_type=bearer
         * 如果需要返回 json 需要指定 Accept: application/json
         */
        // conn.setRequestProperty("Accept", "application/json");
        PrintWriter writer = new PrintWriter(conn.getOutputStream());
        writer.write(HttpUtils.buildRawQuery(params));
        writer.flush();

        int responseCode = conn.getResponseCode();
        String ctype = conn.getHeaderField("Content-Type");
        String responseBody = IOUtils.toString(conn.getInputStream(), Charset.forName("utf-8"), true);

        return parseAccessToken(ctype, responseBody);
    }

    protected AccessTokenInfo parseAccessToken(String ctype, String responseBody) {
        int index = null != ctype ? ctype.indexOf(";") : -1;
        ctype = -1 < index ? ctype.substring(0, index) : ctype;
        ctype = null != ctype ? ctype.toLowerCase() : "";
        responseBody = null != responseBody ? responseBody : "";

        /*-
         * 对于 Github 等默认返回的是 application/x-www-form-urlencoded:
         * access_token=e72e16c7e42f292c6912e7710c838347ae178b4a&scope=user%2Cgist&token_type=bearer
         * 如果需要返回 json 需要指定 Accept: application/json
         */
        if ("application/x-www-form-urlencoded".equals(ctype)) {
            return doParseTextAccessToken(responseBody);
        } else if ("application/json".equals(ctype)) {
            return doParseJsonAccessToken(asJsonMap(responseBody));
        } else if (2 < responseBody.length() && '{' == responseBody.charAt(0) && '}' == responseBody.charAt(responseBody.length() - 1)){
            // 有可能是 text/plain 但是结果是json (sina)
            return doParseJsonAccessToken(asJsonMap(responseBody));
        } else {
            return doParseTextAccessToken(responseBody);
        }
    }

    protected AccessTokenInfo doParseJsonAccessToken(Map<String, Object> ret) {
        String accessToken = (String) ret.get("access_token");
        String tokenType = (String) ret.get("token_type");
        String refreshToken = (String) ret.get("refresh_token");
        String scope = (String) ret.get("scope");
        Object expires = ret.get("expires_in");
        long expiresIn = -1;
        if (expires instanceof Number) {
            expiresIn = ((Number) expires).longValue();
        } else if (expires instanceof String) {
            expiresIn = Long.valueOf((String) expires);
        }

        return new AccessTokenInfo(accessToken, tokenType, expiresIn, refreshToken, scope);
    }

    protected AccessTokenInfo doParseTextAccessToken(String responseBody) {
        if (!responseBody.matches("^[-_%0-9a-zA-Z]+=.*")) {
            throw new IllegalStateException("invalid token text:" + responseBody);
        }

        Map<String, String> ret = HttpUtils.splitUrlQuery(responseBody);
        String expires_in = ret.get("expires_in");
        String refresh_token = ret.get("refresh_token");
        String access_token = ret.get("access_token");
        return new AccessTokenInfo(access_token, null, 0, refresh_token, null);
    }

    /**
     * 使用给定的 access token 信息获取用户基本信息
     *
     * @param accessToken 资源访问token信息
     * @return 用户的基本信息
     * @throws IOException
     */
    public abstract Map<String, Object> getOpenInfo(AccessTokenInfo accessToken) throws IOException;

    protected Map<String, Object> asJsonMap(String json) {
        return Jacksons.deserialize(json, new TypeReference<Map<String, Object>>() {
        });
    }

    protected Map<String, String> createParams() {
        return new HashMap<String, String>();
    }

    protected String doHttpGet(String url, Map<String, String> params) throws IOException {
        return HttpUtils.get(url, params);
    }

    protected String doHttpPost(String url, Map<String, String> params) throws IOException {
        return HttpUtils.post(url, params, 3 * 1000, 3 * 1000);
    }

    protected String encode(String text, String charset) {
        return HttpUtils.encode(text, charset);
    }
}
