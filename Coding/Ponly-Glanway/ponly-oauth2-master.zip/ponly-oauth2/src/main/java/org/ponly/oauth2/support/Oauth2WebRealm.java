package org.ponly.oauth2.support;

import org.ponly.common.util.Identifier;
import org.ponly.oauth2.Oauth2;
import org.ponly.web.servlet.Cookie;
import org.ponly.web.servlet.SimpleCookie;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * OAuth 2.0 Realm
 * <p/>
 * 处理
 * 1. 重定向到认证网站 {@link #doAuthorize(String, String, HttpServletRequest, HttpServletResponse)}
 * 2. 处理认证回调 {@link #doCallback(String, String, HttpServletRequest, HttpServletResponse)}
 *
 * @author vacoor
 */
public abstract class Oauth2WebRealm {
    private static final Logger LOGGER = LoggerFactory.getLogger(Oauth2WebRealm.class);
    private static final String DEFAULT_OAUTH_STATE_COOKIE_NAME = "_ocss";
    private String oauthStateCookieName = DEFAULT_OAUTH_STATE_COOKIE_NAME;

    /**
     * 跳转到 第三方登录 oauth 2.0 认证地址
     *
     * @param channel 第三方登录平台类型
     * @return 是否需要继续执行过滤器链
     */
    public boolean doAuthorize(String channel, String redirectUri, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Cookie oauthStateCookie = new SimpleCookie(oauthStateCookieName);
        try {
            String state = Identifier.get();
            String authorizeUrl = getRequiredOauthClient(channel, redirectUri).getAuthorizeUrl(state);

            // save session state to cookie and redirect to authorize url
            oauthStateCookie.setValue(state);
            oauthStateCookie.saveTo(request, response);
            response.sendRedirect(authorizeUrl);
            return false;
        } catch (Exception ex) {
            oauthStateCookie.removeFrom(request, response);
            if (ex instanceof ServletException) {
                throw (ServletException) ex;
            }
            if (ex instanceof IOException) {
                throw (IOException) ex;
            }
            if (ex instanceof RuntimeException) {
                throw (RuntimeException) ex;
            }
            throw new ServletException(ex);
        }
    }

    /**
     * oauth 2.0 认证回调
     * 处理登录和绑定操作
     *
     * @param channel 第三方登录渠道/平台
     * @return 是否需要继续执行过滤器链
     * @throws IOException
     */
    public boolean doCallback(String channel, String redirectUri, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        final Cookie oauthStateCookie = new SimpleCookie(oauthStateCookieName);
        final String sessionState = oauthStateCookie.readValue(request, response);
        final String state = request.getParameter("state");
        final String code = request.getParameter("code");

        // 每次都清理, 不允许重用
        oauthStateCookie.removeFrom(request, response);

        LOGGER.debug("do callback state: {}, code: {}, csrf state: {}");

        Oauth2 oauth = getRequiredOauthClient(channel, redirectUri);

        // 没有授权码或状态不正确
        if (null == code || 1 > code.length() || (null != sessionState && !sessionState.equals(state))) {
            LOGGER.warn("not found authorization code(" + code + ") or csrf state ("+ state + ")invalid, redirect to authorization url.");
            doAuthorize(channel, redirectUri, request, response);
            return false;
        }

        // 获取 access token 和 openinfo
        Oauth2.AccessTokenInfo accessToken = oauth.getAccessToken(code);
        Map<String, Object> info = oauth.getOpenInfo(accessToken);
        String openid = (String) info.get(Oauth2.OPENID_KEY);
        String nickname = (String) info.get(Oauth2.NICKNAME_KEY);
        String avatarUrl = (String) info.get(Oauth2.AVATAR_URL_KEY);

        LOGGER.debug("found openid: {}, nickname: {}, avatarUrl: {}, info: {}", openid, nickname, avatarUrl, info);

        // 没有 openid
        if (null == openid) {
            LOGGER.warn("not found openid");
            // throw new IllegalStateException("INVALID_OAUTH_BIND_REQUEST:OPENID_IS_BLANK");
            doAuthorize(channel, redirectUri, request, response);
            return false;
        }

        return onAuthorized(request, response, channel, openid, nickname, avatarUrl, info);
    }

    /**
     * 认证成功后调用该方法执行后续处理
     *
     * @param request   当前请求
     * @param response  当前响应对象
     * @param channel   oauth 认证渠道/平台
     * @param openid    oauth 用户 openid
     * @param nickname  oauth 用户昵称
     * @param avatarUrl oauth 用户头像Url
     * @param info      oauth 原始用户信息
     * @return 是否需要继续执行过滤器链
     * @throws IOException
     * @throws ServletException
     */
    protected abstract boolean onAuthorized(HttpServletRequest request, HttpServletResponse response, String channel,
                                            String openid, String nickname, String avatarUrl, Map<String, Object> info) throws IOException, ServletException;

    /**
     * 获取与给定 type 匹配的必须的 Oauth2 实例, 如果无法创建 Oauth2 实例则抛出 {@link IllegalStateException}
     *
     * @param channel oauth2 渠道
     * @return Oauth2 实例
     */
    private Oauth2 getRequiredOauthClient(String channel, String redirectUri) throws IllegalStateException {
        Oauth2 oauth = doCreateOauthClient(channel, redirectUri);
        if (null == oauth) {
            throw new IllegalStateException("ILLEGAL_OAUTH_CHANNEL:" + channel);
        }
        return oauth;
    }

    /**
     * 创建一个给定渠道的 Oauth2 实例, 如果无法创建则返回 null
     *
     * @param channel     Oauth2 渠道
     * @param redirectUri 认证成功回调 URL
     * @return Oauth2 实例或null
     */
    protected abstract Oauth2 doCreateOauthClient(String channel, String redirectUri);

}
