package org.ponly.oauth2;

import java.io.IOException;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * QQ OAuth 2.0: Connect.QQ (http://wiki.connect.qq.com)
 *
 * @author vacoor
 */
public class QQ extends Oauth2 {
    private static final String QQ_AUTHORIZE_URL = "https://graph.qq.com/oauth2.0/authorize";
    private static final String QQ_ACCESS_TOKEN_URL = "https://graph.qq.com/oauth2.0/token";
    private static final String QQ_OPENID_PC_URL = "https://graph.qq.com/oauth2.0/me";
    private static final String QQ_USER_INFO_URL = "https://graph.qq.com/user/get_user_info";

    public QQ(String appId, String appKey, String redirectUri) {
        super(QQ_AUTHORIZE_URL, QQ_ACCESS_TOKEN_URL, appId, appKey, redirectUri);
    }

    @Override
    public Map<String, Object> getOpenInfo(AccessTokenInfo accessToken) throws IOException {
        Map<String, String> params = createParams();
        params.put("access_token", accessToken.accessToken);

        // callback( {"client_id":"YOUR_APPID","openid":"YOUR_OPENID"} );
        String result = doHttpGet(QQ_OPENID_PC_URL, params);

        Matcher matcher = Pattern.compile("\"openid\":\"([-_a-zA-Z0-9]*)\"").matcher(result);
        String openid = matcher.find() ? matcher.group(1) : null;

        // 访问和修改用户信息
        params.clear();
        params.put("access_token", accessToken.accessToken);
        params.put("oauth_consumer_key", clientId);
        params.put("openid", openid);

        String userJson = doHttpGet(QQ_USER_INFO_URL, params);
        Map<String, Object> response = asJsonMap(userJson);

        Object ret = response.get("ret");
        response.put(OPENID_KEY, openid);
        response.put(NICKNAME_KEY, response.get("nickname"));

        String[] avatarKeys = {"figureurl_qq_2", "figureurl_qq_1", "figureurl2", "figureurl_1", "figureurl"};
        for (String avatarKey : avatarKeys) {
            Object value = response.get(avatarKey);
            if (null != value && value instanceof String && 0 < ((String) value).length()) {
                response.put(AVATAR_URL_KEY, value);
                break;
            }
        }
        return response;
    }

    public static void main(String[] args) {
        QQ qq = new QQ("101270722", "da76c7ecf547de2a1d087905685a2c59", "http://g.ngrok.cc/oauth/qq/callback");
        String authorizeUrl = qq.getAuthorizeUrl("");
        System.out.println(authorizeUrl);
    }
}
