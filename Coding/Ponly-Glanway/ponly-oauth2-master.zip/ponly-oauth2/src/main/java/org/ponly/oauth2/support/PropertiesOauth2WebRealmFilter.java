package org.ponly.oauth2.support;

import org.ponly.common.util.StringUtils;
import org.ponly.oauth2.*;

import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author vacoor
 */
public class PropertiesOauth2WebRealmFilter extends Oauth2WebRealmFilter {
    private static final Logger LOGGER = LoggerFactory.getLogger(PropertiesOauth2WebRealmFilter.class);
    private FilterConfig filterConfig;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.filterConfig = filterConfig;
        super.init(filterConfig);
    }

    @Override
    protected Oauth2 doCreateOauthClient(final String channel, final String redirectUri) {
        final String appid = getRequiredProperty("oauth." + channel + ".appid");
        final String appkey = getRequiredProperty("oauth." + channel + ".appkey");
        String finalRedirectUri = getRequiredProperty("oauth." + channel + ".redirect_uri");
        finalRedirectUri = StringUtils.hasText(finalRedirectUri) ? finalRedirectUri : redirectUri;


        Oauth2 oauth = null;
        if ("wechat".equals(channel)) {
            String scope = getProperty("oauth.wechat.scope");
            scope = null != scope ? scope : Wechat.SCOPE_SNSAPI_LOGIN;
            oauth = new Wechat(scope, appid, appkey, finalRedirectUri);
        } else if ("qq".equals(channel)) {
            oauth = new QQ(appid, appkey, finalRedirectUri);
        } else if ("taobao".equals(channel)) {
            oauth = new Taobao(appid, appkey, finalRedirectUri);
        } else if ("weibo".equals(channel)) {
            oauth = new Weibo(appid, appkey, finalRedirectUri);
        } else if ("renren".equals(channel)) {
            oauth = new Renren(appid, appkey, finalRedirectUri);
        } else if ("douban".equals(channel)) {
            oauth = new Douban(appid, appkey, finalRedirectUri);
        } else if ("github".equals(channel)) {
            oauth = new Github(appid, appkey, finalRedirectUri);
        }
        return oauth;
    }

    protected String getRequiredProperty(String prop) {
        String value = getProperty(prop);
        if (null == value || 1 > value.length()) {
            LOGGER.error("INVALID_OAUTH_CONFIG: {} at {}", prop, getClass());
            // throw new IllegalStateException("\"" + prop + "\" property is not set");
            throw new IllegalStateException("INVALID_OAUTH_CONFIG:" + prop);
        }
        return value;
    }

    protected String getProperty(String prop) {
        String value = filterConfig.getInitParameter(prop);
        return null != value ? value : System.getProperty(prop);
    }
}
