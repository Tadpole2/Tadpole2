package org.ponly.oauth2.support;

import java.io.IOException;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.ponly.common.util.StringUtils;
import org.ponly.oauth2.Oauth2;
import org.ponly.oauth2.Oauth2Utils;
import org.ponly.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Oauth 2.0 认证 Filter
 * <p/>
 * 执行 oauth2 认证和回调操作:
 * 认证操作地址为: /{prefix}/{type} or /{prefix}/{type}/authorize,
 * 回调操作地址为: /{prefix}/{type}/callback
 * 在回调成功后, 该类会将相关信息存入 request 后,
 * 如果设置了 forward url 则 forward 到 {@link #setAuthorizedForwardPath(String)} 设置的路径, 否则继续执行过滤器链
 * (可以通过 init-param: authorizedForwardPath 设置
 *
 * @author vacoor
 */
public abstract class Oauth2WebRealmFilter extends Oauth2WebRealm implements Filter {
    private static final Logger LOG = LoggerFactory.getLogger(Oauth2WebRealmFilter.class);
    private static final String ALREADY_FILTERED_SUFFIX = ".FILTERED";
    private static final String AUTHORIZE_ACTION = "authorize";
    private static final String CALLBACK_ACTION = "callback";

    /**
     * 登录渠道 key
     */
    public static final String CHANNEL_KEY = Oauth2.class.getName() + ".oauth_channel";

    /**
     * 原始 认证信息 key
     */
    public static final String OPEN_INFO_KEY = Oauth2.class.getName() + ".oauth.open_info";
    /**
     * 用户信息 openid key
     */
    public static final String OPENID_KEY = Oauth2.OPENID_KEY;
    /**
     * 用户信息 nickname key
     */
    public static final String NICKNAME_KEY = Oauth2.NICKNAME_KEY;
    /**
     * 用户信息 avatar url key
     */
    public static final String AVATAR_URL_KEY = Oauth2.AVATAR_URL_KEY;

    public static final String DEFAULT_PREFIX = "/oauth";


    private String prefix = DEFAULT_PREFIX;
    private String authorizedForwardPath;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        String prefix = filterConfig.getInitParameter("prefix");
        String authorizedPath = filterConfig.getInitParameter("authorizedForwardPath");

        if (null != prefix) {
            setPrefix(prefix);
        }
        if (null != authorizedPath) {
            setAuthorizedForwardPath(authorizedPath);
        }
    }

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        String alreadyFilteredAttributeName = getClass().getName() + ALREADY_FILTERED_SUFFIX;

        if (null != request.getAttribute(alreadyFilteredAttributeName)) {
            LOG.trace("Filter \'{}\' already executed.  Proceeding without invoking this filter.");
            filterChain.doFilter(request, response);
        } else if (!(request instanceof HttpServletRequest) || !(response instanceof HttpServletResponse)) {
            LOG.debug("Filter \'{}\' is unsupported not HTTP request or response.");
            filterChain.doFilter(request, response);
        } else {
            LOG.trace("Filter \'{}\' not yet executed.  Executing now.");
            request.setAttribute(alreadyFilteredAttributeName, Boolean.TRUE);

            try {
                this.doFilterInternal((HttpServletRequest) request, (HttpServletResponse) response, filterChain);
            } finally {
                request.removeAttribute(alreadyFilteredAttributeName);
            }
        }
    }

    /**
     * 执行 oauth2 认证和回调操作
     * <p/>
     * 认证操作地址为: /{prefix}/{type}/authorize,
     * 回调操作地址为: /{prefix}/{type}/callback
     *
     * @param request     请求
     * @param response    响应
     * @param filterChain 过滤器链
     * @throws IOException
     * @throws ServletException
     */
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        String path = WebUtils.getPathWithinApplication(request);
        String prefix = getPrefix();

        if (null != Oauth2Utils.getOpenid(request)) {
            LOG.info("found openid skip.");
            filterChain.doFilter(request, response);
            return;
        }

        LOG.info("not found openid continue, path: {}, prefix: {}", path, prefix);

        // 如果是以给定前缀开头则处理
        if (null == prefix || path.startsWith(prefix)) {
            // 去除前缀, /{prefix}/{type}/{action} --> {type}/{action}
            path = null != prefix ? path.substring(prefix.length()) : path;
            path = path.startsWith("/") ? path.substring(1) : path;

            // 获取 oauth2 渠道和操作, /{prefix}/{type}/{action}
            int slash = path.indexOf("/");
            String channel = null;
            String action = null;
            if (-1 < slash && slash != path.length() - 1) {
                action = path.substring(slash + 1);
                channel = path.substring(0, slash);
            }

            // 兼容 /{prefix}/{type}
            if (0 > slash && !"".equals(path)) {
                channel = path;
                action = AUTHORIZE_ACTION;
            }

            String redirectPath = null != prefix ? prefix : "/";
            redirectPath = !redirectPath.endsWith("/") ? redirectPath + "/" : redirectPath;
            redirectPath += channel + "/" + CALLBACK_ACTION;
            String redirectUri = WebUtils.getUrlWithoutApplication(request, redirectPath);
            if (AUTHORIZE_ACTION.equals(action)) {
                // 执行认证操作后, 不需要继续执行其他操作
                if (!doAuthorize(channel, redirectUri, request, response)) {
                    return;
                }
            } else if (CALLBACK_ACTION.equals(action)) {
                // 执行了回调操作后, 不需要继续执行其他操作
                if (!doCallback(channel, redirectUri, request, response)) {
                    return;
                }
            }
        }

        filterChain.doFilter(request, response);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean onAuthorized(HttpServletRequest request, HttpServletResponse response, String channel,
                                   String openid, String nickname, String avatarUrl, Map<String, Object> info) throws IOException, ServletException {
        // 设置认证信息到 request
        request.setAttribute(CHANNEL_KEY, channel);
        request.setAttribute(OPENID_KEY, openid);
        request.setAttribute(NICKNAME_KEY, nickname);
        request.setAttribute(AVATAR_URL_KEY, avatarUrl);
        request.setAttribute(OPEN_INFO_KEY, info);

        // 这里放入 session 以便后续其他功能使用
        request.getSession().setAttribute("oauth2.authorized." + channel + ".openid", openid);

        RequestDispatcher dispatcher = null;
        String authorizedPath = getAuthorizedForwardPath();

        if (StringUtils.hasText(authorizedPath)) {
            dispatcher = request.getRequestDispatcher(authorizedPath);
        }

        // forward 到处理地址
        if (null != dispatcher) {
            dispatcher.forward(request, response);
            return false;
        } else {
            /*
            String from = request.getParameter("from");
            if (null != from) {
                response.sendRedirect(from);
                return false;
            }
            */
            return true;
        }
    }


    /* *****************************************************
     *               getter / setter
     * ******************************************************/

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getAuthorizedForwardPath() {
        return authorizedForwardPath;
    }

    public void setAuthorizedForwardPath(String authorizedForwardPath) {
        this.authorizedForwardPath = authorizedForwardPath;
    }
}
