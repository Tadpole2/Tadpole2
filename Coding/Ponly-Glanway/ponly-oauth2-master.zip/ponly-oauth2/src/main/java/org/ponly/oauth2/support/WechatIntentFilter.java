package org.ponly.oauth2.support;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.ponly.common.util.StringUtils;
import org.ponly.oauth2.Oauth2;
import org.ponly.oauth2.Oauth2Utils;
import org.ponly.oauth2.Wechat;
import org.ponly.web.servlet.Cookie;
import org.ponly.web.servlet.SimpleCookie;
import org.ponly.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 微信自动登录
 * /m/*
 * /m/wxcallback
 *
 * @author Administrator
 * @date 2017-07-04
 */
public class WechatIntentFilter extends PropertiesOauth2WebRealmFilter {
    private static final Logger LOGGER = LoggerFactory.getLogger(WechatIntentFilter.class);
    private static final String WECHAT_FILTERED_KEY = WechatIntentFilter.class.getName() + ".filtered";

    @Override
    protected void doFilterInternal(HttpServletRequest httpRequest, HttpServletResponse httpResponse, FilterChain filterChain) throws IOException, ServletException {
        LOGGER.info("wechat intent authorizetion");

        final Cookie fromCookie = new SimpleCookie("from");
        fromCookie.setValue(encode(WebUtils.getRequestUri(httpRequest)));

        if (null != Oauth2Utils.getOpenid(httpRequest)) {
            LOGGER.warn("WechatIntentFilter found openid skip");
            fromCookie.saveTo(httpRequest, httpResponse);
            filterChain.doFilter(httpRequest, httpResponse);
            return;
        }

        final HttpSession httpSession = httpRequest.getSession();
        final Object requestFiltered = httpRequest.getAttribute(WECHAT_FILTERED_KEY);
        final Object sessionFiltered = httpSession.getAttribute(WECHAT_FILTERED_KEY);
        final String ua = httpRequest.getHeader("User-Agent");
        final boolean isWechat = ua.toLowerCase().contains("micromessenger");

        if (!isWechat || null != requestFiltered || null != sessionFiltered) {
            filterChain.doFilter(httpRequest, httpResponse);
            return;
        }

        final String prefix = getPrefix();
        String path = WebUtils.getPathWithinApplication(httpRequest);

        String redirectPath = null != prefix ? prefix : "/";
        redirectPath = !redirectPath.endsWith("/") ? redirectPath + "/" : redirectPath;
        redirectPath += "wxcallback";
        final String redirectUri = WebUtils.getUrlWithoutApplication(httpRequest, redirectPath);

        LOGGER.info("execute native authorization in wechat, path: {}, prefix: {}", path, prefix);

        // 如果是以给定前缀开头则处理
        if (null == prefix || path.startsWith(prefix)) {
            // 去除前缀, /{prefix}/wxcallback --> wxcallback
            path = null != prefix ? path.substring(prefix.length()) : path;
            path = path.startsWith("/") ? path.substring(1) : path;

            LOGGER.info("wxcallback path: {}", path);

            if ("wxcallback".equals(path)) {
                 httpRequest.setAttribute(WECHAT_FILTERED_KEY, true);
                 httpSession.setAttribute(WECHAT_FILTERED_KEY, true);

                // 执行了回调操作后, 不需要继续执行其他操作
                if (!doCallback(null, redirectUri, httpRequest, httpResponse)) {
                    return;
                }
            } else {
                if (null == fromCookie.readValue(httpRequest, httpResponse)) {
                    fromCookie.saveTo(httpRequest, httpResponse);
                }
                // 执行认证操作后, 不需要继续执行其他操作
                if (!doAuthorize(null, redirectUri, httpRequest, httpResponse)) {
                    return;
                }
            }
        } else {
            if (null == fromCookie.readValue(httpRequest, httpResponse)) {
                fromCookie.saveTo(httpRequest, httpResponse);
            }
            // 执行认证操作后, 不需要继续执行其他操作
            if (!doAuthorize(null, redirectUri, httpRequest, httpResponse)) {
                return;
            }
        }
        LOGGER.info("wechat intent do next filter");
        filterChain.doFilter(httpRequest, httpResponse);
    }

    @Override
    public void destroy() {
    }

    @Override
    protected Oauth2 doCreateOauthClient(String channel, String redirectUri) {
        final String appid = getRequiredProperty("oauth.wechat.appid");
        final String appkey = getRequiredProperty("oauth.wechat.appkey");
        final String scope = getRequiredProperty("oauth.wechat.scope");
        String finalRedirectUri = getRequiredProperty("oauth.wechat.redirect_uri");
        finalRedirectUri = StringUtils.hasText(finalRedirectUri) ? finalRedirectUri : redirectUri;

        if (!Wechat.SCOPE_SNSAPI_BASE.equals(scope) && !Wechat.SCOPE_SNSAPI_USERINFO.equals(scope)) {
            throw new IllegalStateException("WechatIntentFilter scope must be at [Wechat.SCOPE_SNSAPI_BASE, Wechat.SCOPE_SNSAPI_USERINFO]");
        }

        return new Wechat(scope, appid, appkey, finalRedirectUri);
    }

    private String encode(final String text) {
        try {
            return URLEncoder.encode(text, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return text;
        }
    }
}
