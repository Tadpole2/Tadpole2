package org.ponly.oauth2;

import java.io.IOException;
import java.util.Map;

/**
 * Taobao OAuth 2.0
 * http://open.taobao.com/doc2/detail?spm=0.0.0.0.VrTIAA&docType=1&articleId=102635&treeId=1
 *
 * @author vacoor
 */
public class Taobao extends Oauth2 {
    private static final String TB_AUTHORIZE_URL = "https://oauth.taobao.com/authorize";
    private static final String TB_ACCESS_TOKEN_URL = "https://oauth.taobao.com/token";

    public static Taobao create(String redirectUri) {
        return new Taobao("23261798", "bd01ab0ffd5372f50767633b6e2b098a", redirectUri);
    }

    public Taobao(String clientId, String clientSecret, String redirectUri) {
        super(TB_AUTHORIZE_URL, TB_ACCESS_TOKEN_URL, clientId, clientSecret, redirectUri);
    }

    @Override
    public String getAuthorizeUrl(String sessionState) {
        return super.getAuthorizeUrl(sessionState);// + "&view=tmall"; // view: tmall, web, wap
    }

    @Override
    protected AccessTokenInfo doParseJsonAccessToken(Map<String, Object> ret) {
        AccessTokenInfo info = super.doParseJsonAccessToken(ret);
        return new AccessTokenInfo(info.accessToken, info.tokenType, info.expiresIn, info.refreshToken, info.scope, (String) ret.get("taobao_user_id"), ret);
    }

    @Override
    public Map<String, Object> getOpenInfo(AccessTokenInfo accessToken) throws IOException {
        Map<String, Object> data = accessToken.rawData;
        data.put(OPENID_KEY, data.get("taobao_user_id"));
        data.put(NICKNAME_KEY, data.get("taobao_user_nick"));
        return data;
    }
}
