package org.ponly.oauth2;

import org.ponly.oauth2.support.Oauth2WebRealmFilter;

import javax.servlet.ServletRequest;
import java.util.Map;

/**
 * @author vacoor
 */
public abstract class Oauth2Utils {

    public static String getOpenid(Map<String, Object> openInfo) {
        return null != openInfo ? (String) openInfo.get(Oauth2.OPENID_KEY) : null;
    }

    public static String getNickname(Map<String, Object> openInfo) {
        return null != openInfo ? (String) openInfo.get(Oauth2.NICKNAME_KEY) : null;
    }

    public static String getAvatarUrl(Map<String, Object> openInfo) {
        return null != openInfo ? (String) openInfo.get(Oauth2.AVATAR_URL_KEY) : null;
    }

    public static boolean isOauth2CallbackRequest(ServletRequest request) {
        return null != getChannel(request) && null != getOpenid(request);
    }

    public static String getChannel(ServletRequest request) {
        return (String) request.getAttribute(Oauth2WebRealmFilter.CHANNEL_KEY);
    }

    public static String getWechatUnionid(ServletRequest request) {
        final Map<String, String> info = getOpenInfo(request);
        return null != info ? info.get("unionid") : null;
    }

    public static String getOpenid(ServletRequest request) {
        return (String) request.getAttribute(Oauth2WebRealmFilter.OPENID_KEY);
    }

    public static String getNickname(ServletRequest request) {
        return (String) request.getAttribute(Oauth2WebRealmFilter.NICKNAME_KEY);
    }

    public static String getAvatarUrl(ServletRequest request) {
        return (String) request.getAttribute(Oauth2WebRealmFilter.AVATAR_URL_KEY);
    }

    @SuppressWarnings("unchecked")
    public static Map<String, String> getOpenInfo(ServletRequest request) {
        final Map<String, String> info = (Map<String, String>) request.getAttribute(Oauth2WebRealmFilter.OPEN_INFO_KEY);
        return null != info && !info.isEmpty() ? info : null;
    }

    private Oauth2Utils() {
    }
}
