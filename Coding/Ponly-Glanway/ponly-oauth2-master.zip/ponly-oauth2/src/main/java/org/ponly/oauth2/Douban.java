package org.ponly.oauth2;

import java.io.IOException;
import java.util.Map;

/**
 * <a href="http://www.douban.com/">豆瓣</a> OAuth v2.0 认证
 * <p>
 * http://developers.douban.com/apikey/
 * http://developers.douban.com/wiki/?title=oauth2#server_side_flow
 *
 * @see http://developers.douban.com/wiki/?title=connect
 * @see http://developers.douban.com/wiki/?title=user_v2
 */
public class Douban extends Oauth2 {
    private static final String DB_AUTHORIZE_URL = "https://www.douban.com/service/auth2/auth";
    private static final String DB_ACCESS_TOKEN_URL = "https://www.douban.com/service/auth2/token";
    private static final String DB_USER_INFO_URL = "https://api.douban.com/v2/user/~me";

    /**
     * 根据给定的配置参数创建一个 OAuth 认证/授权对象
     *
     * @param clientId     OAuth 2 应用 appid
     * @param clientSecret OAuth 2 应用 appkey
     * @param redirectUri  OAuth 2 应用授权回调URL
     */
    public Douban(String clientId, String clientSecret, String redirectUri) {
        super(DB_AUTHORIZE_URL, DB_ACCESS_TOKEN_URL, clientId, clientSecret, redirectUri);
    }

    @Override
    protected AccessTokenInfo doParseJsonAccessToken(Map<String, Object> ret) {
        AccessTokenInfo info = super.doParseJsonAccessToken(ret);
        String uid = (String) ret.get("douban_user_id");
        return new AccessTokenInfo(info.accessToken, info.tokenType, info.expiresIn, info.refreshToken, info.scope, uid);
    }

    @Override
    public Map<String, Object> getOpenInfo(AccessTokenInfo accessToken) throws IOException {
        /*- 两种都可以
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Bearer " + accessToken);
        */
        Map<String, String> params = createParams();
        params.put("access_token", accessToken.accessToken);

        String json = doHttpGet(DB_USER_INFO_URL, params);
        Map<String, Object> ret = asJsonMap(json);
        Object id = ret.get("id");
        String uid = String.valueOf(ret.get("uid"));

        ret.put(OPENID_KEY, uid);
        ret.put(NICKNAME_KEY, ret.get("name"));
        ret.put(AVATAR_URL_KEY, ret.get("avatar"));
        return ret;
    }
}
