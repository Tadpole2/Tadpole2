/**
 * 文件系统
 * <p/>
 * 该包主要提供了对常见文件系统提供一个统一的操作 API.
 */
package org.ponly.fs;