package org.ponly.dataformat.spreadsheet;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

/**
 */
public class SpreadsheetTest {

    @Test
    public void doBiff5Test() throws SpreadsheetException {
        final InputStream biff5In = Thread.currentThread().getContextClassLoader().getResourceAsStream("biff5.xls");
        Assert.assertNotNull(biff5In);

        final SpreadsheetParser parser = new LegacySpreadsheetParser(biff5In);
        doConsume(parser, new DefaultSpreadsheetConsumer());
        parser.close();
    }

    @Test
    public void doBiff8Test1() throws SpreadsheetException {
        final InputStream biff8In = Thread.currentThread().getContextClassLoader().getResourceAsStream("biff8.xls");
        Assert.assertNotNull(biff8In);

        final SpreadsheetParser parser = new LegacySpreadsheetParser(biff8In);
        doConsume(parser, new DefaultSpreadsheetConsumer());
        parser.close();
    }

    @Test
    public void doBiff8Test2() throws SpreadsheetException {
        final InputStream biff8In = Thread.currentThread().getContextClassLoader().getResourceAsStream("biff8.xls");
        Assert.assertNotNull(biff8In);

        final SpreadsheetParser parser = new LegacySpreadsheetParser2(biff8In);
        doConsume(parser, new DefaultSpreadsheetConsumer());
        parser.close();
    }

    @Test
    public void doSMLTest() throws SpreadsheetException {
        final InputStream smlIn = Thread.currentThread().getContextClassLoader().getResourceAsStream("sml.xlsx");
        Assert.assertNotNull(smlIn);

        final SpreadsheetParser parser = new OpenXMLSpreadsheetParser(smlIn);
        doConsume(parser, new DefaultSpreadsheetConsumer());
    }

    @Test
    public void doTest() throws IOException, SpreadsheetException {
        final InputStream biff5In = Thread.currentThread().getContextClassLoader().getResourceAsStream("biff5.xls");
        // final InputStream biff8In = Thread.currentThread().getContextClassLoader().getResourceAsStream("biff8.xls");
//        final InputStream smlIn = Thread.currentThread().getContextClassLoader().getResourceAsStream("sml.xlsx");

//        final InputStream badIn = Thread.currentThread().getContextClassLoader().getResourceAsStream("bad.xlsx");

        final SpreadsheetFactory factory = SpreadsheetFactory.newFactory(SpreadsheetFactory.Feature.BIFF5);

        SpreadsheetParser parser = factory.newParser(biff5In);
        doConsume(parser, new DefaultSpreadsheetConsumer());
        parser.close();

        /*
        parser = factory.newParser(biff8In);
        doConsume(parser, new DefaultSpreadsheetConsumer());
        parser.close();

        parser = factory.newParser(smlIn);
        doConsume(parser, new DefaultSpreadsheetConsumer());
        parser.close();
        */

        // factory.newParser(badIn);
    }

    @Test
    public void testNextRow() throws IOException, SpreadsheetException {
        final InputStream sml = Thread.currentThread().getContextClassLoader().getResourceAsStream("template.xlsx");
        final SpreadsheetParser parser = SpreadsheetFactory.newFactory(SpreadsheetFactory.Feature.OPEN_XML).newParser(sml);
        int rows = 0;
        for (; parser.hasNext(); ) {
            final Object[] row = parser.nextRow(true);
            if (null != row) {
                rows++;

                System.out.println(Arrays.toString(row));
            }
        }
        Assert.assertTrue(1 == rows);
    }

    static void doConsume(final SpreadsheetParser parser, final SpreadsheetConsumer consumer) throws SpreadsheetException {
        int eventType;
        do {
            eventType = parser.getEventType();
            if (SpreadsheetParser.START_WORKBOOK == eventType) {
                System.out.println("开始解析 WORKBOOK, 发现 Worksheet: " + parser.getNumberOfWorksheets());
            } else if (SpreadsheetParser.START_WORKSHEET == eventType) {
                System.out.println("开始解析 Worksheet: " + parser.getWorksheetIndex() + ", " + parser.getWorksheetName());
            } else if (SpreadsheetParser.START_RECORD == eventType) {
                // System.out.println("开始解析行:" + parser.getRow());
                System.out.println("----------------------------------------");
                System.out.print("|  " + parser.getRow());
            } else if (SpreadsheetParser.START_CELL == eventType) {
                // System.out.println("开始解析单元格:" + parser.getRow() + "," + parser.getCol() + ":" + parser.getValue());
                System.out.print("  |  " + parser.getValue());
            } else if (SpreadsheetParser.END_CELL == eventType) {
                System.out.print("");
            } else if (SpreadsheetParser.END_RECORD == eventType) {
                System.out.println("  |  ");
            } else if (SpreadsheetParser.END_WORKSHEET == eventType) {
                System.out.println("----------------------------------------");
                System.out.println("Worksheet解析完毕:" + parser.getWorksheetIndex() + "," + parser.getWorksheetName());
            } else if (SpreadsheetParser.END_WORKBOOK == eventType) {
                System.out.println("Workbook解析完毕");
            }
        } while (parser.hasNext() && SpreadsheetParser.EOF != (eventType = parser.next()));

        parser.close();
    }

    static interface SpreadsheetConsumer {

        void onPreWorkbook(final int worksheets);

        void onPreWorksheet(final int worksheetIndex, final String worksheetName);

        void onPreRow(final int worksheetIndex, final String worksheetName, final int row);

        void onPreCell(final int row, final int column, final Object value);

        void onPostCell(final int row, final int column, final Object value);

        void onPostRow(final int worksheetIndex, final String worksheetName, final int row);

        void onPostWorksheet(final int worksheetIndex, final String worksheetName);

        void onPostWorkbook(final int worksheets);

    }

    static class DefaultSpreadsheetConsumer implements SpreadsheetConsumer {

        @Override
        public void onPreWorkbook(int worksheets) {
        }

        @Override
        public void onPreWorksheet(int worksheetIndex, String worksheetName) {
        }

        @Override
        public void onPreRow(int worksheetIndex, String worksheetName, int row) {
        }

        @Override
        public void onPreCell(int row, int column, Object value) {
        }

        @Override
        public void onPostCell(int row, int column, Object value) {
        }

        @Override
        public void onPostRow(int worksheetIndex, String worksheetName, int row) {
        }

        @Override
        public void onPostWorksheet(int worksheetIndex, String worksheetName) {
        }

        @Override
        public void onPostWorkbook(int worksheets) {
        }
    }
}
