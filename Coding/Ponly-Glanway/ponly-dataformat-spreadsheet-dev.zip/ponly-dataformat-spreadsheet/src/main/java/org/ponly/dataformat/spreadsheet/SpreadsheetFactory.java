package org.ponly.dataformat.spreadsheet;

import java.io.*;
import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 */
public class SpreadsheetFactory {
    public static final String VERSION = "1.0-beta";

    private static final Logger LOGGER = LoggerFactory.getLogger(SpreadsheetFactory.class);
    private static final boolean JXL_PRESENT = isPresent("jxl.Workbook");
    private static final boolean POI_HSSF_PRESENT = isPresent("org.apache.poi.hssf.record.RecordFactoryInputStream");
    private static final boolean POI_OOXML_PRESENT = isPresent("org.apache.poi.xssf.streaming.SXSSFWorkbook") && isPresent("org.openxmlformats.schemas.spreadsheetml.x2006.main.CTWorkbook");

    private static final short FEATURE_BIFF5 = 1 << 1;
    private static final short FEATURE_BIFF8 = 1 << 2;
    private static final short FEATURE_OPEN_XML = 1 << 3;

    public enum Feature {
        BIFF5("Microsoft Excel 5.0/95(*.xls)", new byte[]{(byte) 0xD0, (byte) 0xCF, 0x11, (byte) 0xE0}),
        BIFF8("Excel 97-2003(*.xls)", new byte[]{(byte) 0xD0, (byte) 0xCF, 0x11, (byte) 0xE0}),
        OPEN_XML("Excel 2007+(*.xlsx)", new byte[]{0x50, 0x4b, 0x03, 0x04});

        private final String name;
        private final byte[] header;

        Feature(final String name, final byte[] header) {
            this.name = name;
            this.header = header;
        }
    }

    private short features = 0;

    private SpreadsheetFactory(final Feature... features) {
        for (final Feature feature : features) {
            enable(feature);
        }
    }

    public SpreadsheetParser newParser(final InputStream in) throws IOException, SpreadsheetException {
        if (null == in) {
            throw new NullPointerException("stream should non-null");
        }
        final byte[] headerBytes = new byte[4];
        final PushbackInputStream pin = new PushbackInputStream(in, headerBytes.length);
        if (headerBytes.length > pin.read(headerBytes)) {
            throw new IllegalArgumentException("Can not detect stream type");
        }

        pin.unread(headerBytes);
        if (Arrays.equals(Feature.OPEN_XML.header, headerBytes)) {
            assertFeature(Feature.OPEN_XML);
            return new OpenXMLSpreadsheetParser(pin);
        }

        if (Arrays.equals(Feature.BIFF8.header, headerBytes)) {
            try {
                assertFeature(Feature.BIFF5);
            } catch (final IllegalStateException ignore) {
                assertFeature(Feature.BIFF8);
            }
            return (JXL_PRESENT) ? new LegacySpreadsheetParser(pin) : new LegacySpreadsheetParser2(pin);
        }

        if (Arrays.equals(Feature.BIFF5.header, headerBytes)) {
            assertFeature(Feature.BIFF5);
            return new LegacySpreadsheetParser(pin);
        }

        throw new IllegalArgumentException("Stream is not support");
    }

    public SpreadsheetWriter newWriter(final OutputStream out) throws IOException, SpreadsheetException {
        return newWriter(out, null);
    }

    public SpreadsheetWriter newWriter(final OutputStream out, final InputStream template) throws IOException, SpreadsheetException {
        if (isEnabled(Feature.OPEN_XML)) {
            return new OpenXMLSpreadsheetWriter(out, template);
        }
        if (isEnabled(Feature.BIFF8)) {
            return JXL_PRESENT ? new LegacySpreadsheetWriter(out, template) : new LegacySpreadsheetWriter2(out, template);
        }
        if (isEnabled(Feature.BIFF5)) {
            return new LegacySpreadsheetWriter(out, template);
        }
        throw new IllegalStateException("No invalid feature configure");
    }

    private void assertFeature(final Feature feature) {
        if (!isEnabled(feature)) {
            final String featureName = Feature.OPEN_XML.equals(feature)
                    ? "SpreadsheetML(OpenXML)"
                    : (Feature.BIFF8.equals(feature) ? "Microsoft Excel 97-2003(BIFF-8)" : "Microsoft Excel 5.0/95(BIFF-5)");

            throw new IllegalStateException("Feature: " + featureName + " is disabled, can not parsing stream");
        }
    }

    public boolean isEnabled(final Feature feature) {
        if (Feature.OPEN_XML.equals(feature)) {
            return FEATURE_OPEN_XML == (FEATURE_OPEN_XML & this.features);
        }
        if (Feature.BIFF8.equals(feature)) {
            return FEATURE_BIFF8 == (FEATURE_BIFF8 & this.features);
        }
        return Feature.BIFF5.equals(feature) && FEATURE_BIFF5 == (FEATURE_BIFF5 & this.features);
    }

    public SpreadsheetFactory enable(Feature feature) {
        if (Feature.BIFF5.equals(feature)) {
            if (!JXL_PRESENT) {
                throw new IllegalStateException("jxl.Workbook is not found in classpath, can't enable BIFF5 feature");
            }
            features |= FEATURE_BIFF5;
        } else if (Feature.BIFF8.equals(feature)) {
            if (!JXL_PRESENT && !POI_HSSF_PRESENT) {
                throw new IllegalStateException("jxl.Workbook and org.apache.poi.hssf.record.RecordFactoryInputStream is not found in classpath, can't enable BIFF8 feature");
            }
            features |= FEATURE_BIFF8;
        } else if (Feature.OPEN_XML.equals(feature)) {
            if (!POI_OOXML_PRESENT) {
                throw new IllegalStateException("org.apache.poi.xssf.streaming.SXSSFWorkbook is not found in claspath, can't enable OPEN_XML feature");
            }
            features |= FEATURE_OPEN_XML;
        } else {
            throw new IllegalArgumentException();
        }
        return this;
    }

    public static SpreadsheetFactory newFactory(final Feature... features) {
        return new SpreadsheetFactory(features);
    }

    private static boolean isPresent(final String className) {
        try {
            Class.forName(className);
            return true;
        } catch (final ClassNotFoundException e) {
            return false;
        }
    }
}
