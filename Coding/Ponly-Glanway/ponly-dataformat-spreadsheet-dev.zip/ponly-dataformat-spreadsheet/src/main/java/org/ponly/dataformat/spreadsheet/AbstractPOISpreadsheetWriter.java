package org.ponly.dataformat.spreadsheet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.poi.ss.usermodel.*;

/**
 */
abstract class AbstractPOISpreadsheetWriter extends AbstractSpreadsheetWriter {
    private InputStream template;
    private OutputStream out;
    private Map<String, CellStyle> fmtStyles = new HashMap<String, CellStyle>();
    private Workbook workbook;
    private Sheet worksheet;
    private int worksheetIndex = -1;

    public AbstractPOISpreadsheetWriter(final OutputStream out, final InputStream template) {
        this.out = out;
        this.template = template;
    }

    @Override
    public AbstractPOISpreadsheetWriter start(final String worksheetName) throws SpreadsheetException {
        try {
            if (null == workbook) {
                workbook = createWorkbook(this.template);
            }

            Sheet sheet = workbook.getSheet(worksheetName);
            if (null == sheet) {
                sheet = workbook.createSheet(worksheetName);
            }

            this.row = 0;
            this.col = 0;
            this.worksheet = sheet;
            this.worksheetIndex = workbook.getSheetIndex(sheet);
        } catch (final IOException e) {
            throw new SpreadsheetException(e);
        }
        return this;
    }


    @Override
    public AbstractPOISpreadsheetWriter write(final Boolean bool) throws SpreadsheetException {
        if (null != bool) {
            getCell(col++, row).setCellValue(bool);
        } else {
            writeNull(col++, row);
        }
        return this;
    }

    @Override
    public AbstractPOISpreadsheetWriter write(final Number number) throws SpreadsheetException {
        if (null != number) {
            getCell(col++, row).setCellValue(number.doubleValue());
        } else {
            writeNull(col++, row);
        }
        return this;
    }

    @Override
    public AbstractPOISpreadsheetWriter write(final Date date) throws SpreadsheetException {
        return write(date, "yyyy-MM-dd");
    }

    @Override
    public AbstractPOISpreadsheetWriter write(final Date date, final String fmt) throws SpreadsheetException {
        if (null != date) {
            final Cell cell = getCell(col++, row);
            cell.setCellValue(date);
            cell.setCellStyle(getDateStyle(fmt));
        } else {
            writeNull(col++, row);
        }
        return this;
    }

    @Override
    public AbstractPOISpreadsheetWriter write(final String text) throws SpreadsheetException {
        getCell(col++, row).setCellValue(null != text ? text : "");
        return this;
    }

    public AbstractPOISpreadsheetWriter writeNull(final int col, final int row) throws SpreadsheetException {
        getCell(col, row).setCellValue("");
        return this;
    }

    @Override
    public AbstractPOISpreadsheetWriter next() {
        row++;
        col = 0;
        return this;
    }

    @Override
    public void close() {
        try {
            if (null != workbook && null != out) {
                workbook.write(out);
                System.gc();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected Cell getCell(final int col, final int row) {
        if (null == worksheet) {
            throw new IllegalStateException("no writable worksheet at current state, already call start(worksheetName) method?");
        }
        Row r = worksheet.getRow(row);
        if (null == r) {
            r = worksheet.createRow(row);
        }
        Cell c = r.getCell(col);
        if (null == c) {
            c = r.createCell(col);
        }
        return c;
    }

    protected CellStyle getDateStyle(final String format) {
        if (null == worksheet) {
            throw new IllegalStateException("no writable worksheet at current state, already call start(worksheetName) method?");
        }

        CellStyle cellStyle = fmtStyles.get(format);
        if (null == cellStyle) {
            final Workbook workbook = worksheet.getWorkbook();
            cellStyle = workbook.createCellStyle();
            cellStyle.setDataFormat(workbook.createDataFormat().getFormat(format));
            fmtStyles.put(format, cellStyle);
        }
        return cellStyle;
    }

    protected abstract Workbook createWorkbook(final InputStream template) throws IOException;
}
