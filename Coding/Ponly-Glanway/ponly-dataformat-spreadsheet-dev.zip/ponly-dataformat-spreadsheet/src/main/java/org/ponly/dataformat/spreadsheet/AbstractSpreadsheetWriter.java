package org.ponly.dataformat.spreadsheet;

import java.lang.reflect.Array;
import java.util.Calendar;
import java.util.Date;

/**
 */
abstract class AbstractSpreadsheetWriter implements SpreadsheetWriter {
    protected int row;
    protected int col;

    @Override
    public <E> SpreadsheetWriter write(final E... cells) throws SpreadsheetException {
        return write((Object) cells);
    }

    @Override
    public SpreadsheetWriter write(final Object obj) throws SpreadsheetException {
        if (null == obj) {
            this.write("");
            return  this;
        }

        if (obj.getClass().isArray()) {
            final int length = Array.getLength(obj);

            for (int i = 0; i < length; i++) {
                write(Array.get(obj, i));
            }
            return this;
        }

        if (obj instanceof Boolean) {
            write((Boolean) obj);
        } else if (obj instanceof Number) {
            write((Number) obj);
        } else if (obj instanceof Date) {
            write((Date) obj);
        } else if (obj instanceof Calendar) {
            write(((Calendar) obj).getTime());
        } else {
            write(String.valueOf(obj));
        }
        return this;
    }

    @Override
    public AbstractSpreadsheetWriter next() throws SpreadsheetException {
        this.row++;
        this.col = 0;
        return this;
    }
}
