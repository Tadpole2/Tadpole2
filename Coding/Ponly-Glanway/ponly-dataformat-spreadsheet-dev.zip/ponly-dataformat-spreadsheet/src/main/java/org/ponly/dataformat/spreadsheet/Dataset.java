package org.ponly.dataformat.spreadsheet;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.ponly.common.util.Castor;

/**
 */
public class Dataset {
    private final List<?> data;

    public static Dataset from(final Object[] data) {
        return new Dataset(data);
    }

    public static Dataset from(final List<?> data) {
        return new Dataset(null != data ? data : null);
    }

    public Dataset(final Object[] data) {
        this(null != data ? Arrays.asList(data) : null);
    }

    public Dataset(final List<?> data) {
        this.data = data;
    }

    public boolean isNull() {
        return null == data;
    }

    public int size() {
        return !isNull() ? data.size() : 0;
    }

    public Object getValue(int index) {
        return index < size() ? data.get(index) : null;
    }

    public Object getValue(String name) {
        return getValue(nameToColumn(name));
    }

    public Boolean getBoolean(int index) {
        return index < size() ? Castor.asBoolean(data.get(index)) : null;
    }

    public Boolean getBoolean(String name) {
        return getBoolean(nameToColumn(name));
    }

    public Number getNumber(int index) {
        return index < size() ? Castor.asNumber(data.get(index), Number.class) : null;
    }

    public Number getNumber(String name) {
        return getNumber(nameToColumn(name));
    }

    public String getString(int index) {
        return index < size() ? Castor.asString(data.get(index)) : null;
    }

    public String getString(String name) {
        return getString(nameToColumn(name));
    }

    public Date getDate(int index) {
        return index < size() ? Castor.asDate(data.get(index)) : null;
    }

    public Date getDate(String name) {
        return getDate(nameToColumn(name));
    }

    int nameToColumn(String name) {
        int column = -1;
        for (int i = 0; i < name.length(); ++i) {
            int c = name.charAt(i);
            column = (column + 1) * 26 + c - 'A';
        }
        return column;
    }
}
