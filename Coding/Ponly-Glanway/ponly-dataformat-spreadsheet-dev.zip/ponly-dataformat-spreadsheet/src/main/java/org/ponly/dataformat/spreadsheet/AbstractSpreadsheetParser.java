package org.ponly.dataformat.spreadsheet;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

/**
 */
public abstract class AbstractSpreadsheetParser implements SpreadsheetParser {
    protected int eventType;

    /**
     * Current worksheet index.
     */
    protected int worksheetIndex = -1;

    /**
     * Current worksheet name.
     */
    protected String worksheetName;

    /**
     * {@inheritDoc}
     */
    public int getEventType() {
        return this.eventType;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getWorksheetIndex() {
        final int st = this.eventType;
        if (START_WORKBOOK == st || END_WORKBOOK == st) {
            throw new IllegalStateException("getWorksheetIndex() called in illegal state");
        }
        return this.worksheetIndex;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getWorksheetName() {
        final int st = this.eventType;
        if (START_WORKBOOK == st || END_WORKBOOK == st) {
            throw new IllegalStateException("getWorksheetName() called in illegal state");
        }
        return this.worksheetName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasNext() {
        // returns -1 when it detects a broken stream
        return EOF != this.eventType && END_WORKBOOK != this.eventType;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int next() throws SpreadsheetException {
        final int t = this.eventType;
        if (!hasNext()) {
            if (EOF != t) {
                throw new NoSuchElementException("END_WORKBOOK reached: no more elements on the stream.");
            } else {
                throw new IllegalStateException("Error processing input source. The input stream is not complete.");
            }
        }
        return this.eventType = doNext();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object[] nextRow(final boolean ignoreEmptyRow) throws SpreadsheetException {
        final SpreadsheetParser parser = this;

        List<Object> values = null;
        boolean missing = true;
        while (parser.hasNext()) {
            final int event = parser.next();
            if (SpreadsheetParser.END_CELL == event) {
                final int col = parser.getCol();
                final Object value = parser.getValue();

                if (null != values && col < values.size() - 1) {
                    throw new IllegalStateException("invalid col: " + col);
                }

                if (null != value) {
                    missing = false;
                    if (null == values) {
                        values = new ArrayList<Object>();
                    }
                    for (int len = values.size(); len < col; len++) {
                        values.add(null);
                    }
                    values.add(value);
                }
            } else if (SpreadsheetParser.END_RECORD == event) {
                if (!ignoreEmptyRow || (null != values && 0 < values.size())) {
                    break;
                }
                values = null;
            }
        }

        return missing ? null : (null != values ? values.toArray(new Object[values.size()]) : new Object[0]);
    }

    protected abstract int doNext() throws SpreadsheetException;
}
