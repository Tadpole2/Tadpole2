package org.ponly.dataformat.spreadsheet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;

/**
 */
class LegacySpreadsheetWriter2 extends AbstractPOISpreadsheetWriter {

    public LegacySpreadsheetWriter2(final OutputStream out, final InputStream template) {
        super(out, template);
    }

    @Override
    protected Workbook createWorkbook(final InputStream template) throws IOException {
        return null != template ? new HSSFWorkbook(template) : new HSSFWorkbook();
    }
}
