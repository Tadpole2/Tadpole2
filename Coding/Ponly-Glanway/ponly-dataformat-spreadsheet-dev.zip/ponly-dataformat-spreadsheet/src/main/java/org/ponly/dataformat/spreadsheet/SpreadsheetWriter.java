package org.ponly.dataformat.spreadsheet;

import java.util.Date;

/**
 */
public interface SpreadsheetWriter {

    SpreadsheetWriter start(final String worksheetName) throws SpreadsheetException;

    SpreadsheetWriter write(final Boolean bool) throws SpreadsheetException;

    SpreadsheetWriter write(final Number number) throws SpreadsheetException;

    SpreadsheetWriter write(final Date date) throws SpreadsheetException;

    SpreadsheetWriter write(final Date date, final String fmt) throws SpreadsheetException;

    SpreadsheetWriter write(final String text) throws SpreadsheetException;

    SpreadsheetWriter write(final Object obj) throws SpreadsheetException;

    <E> SpreadsheetWriter write(E... cells) throws SpreadsheetException;

    SpreadsheetWriter next() throws SpreadsheetException;

    void close() throws SpreadsheetException;

}
