package org.ponly.dataformat.spreadsheet;

/**
 * Created by Vacoor on 2017-06-27.
 */
public class SpreadsheetException extends Exception {
    public SpreadsheetException() {
    }

    public SpreadsheetException(String message) {
        super(message);
    }

    public SpreadsheetException(String message, Throwable cause) {
        super(message, cause);
    }

    public SpreadsheetException(Throwable cause) {
        super(cause);
    }

}
