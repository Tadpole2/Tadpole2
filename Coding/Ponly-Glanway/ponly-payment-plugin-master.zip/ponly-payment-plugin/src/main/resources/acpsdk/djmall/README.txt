#merchantId=826130050210002
merchantId=826130050210001
acpsdk.signCert.pwd=331723
##\u7b7e\u540d\u8bc1\u4e66\u7c7b\u578b\uff0c\u56fa\u5b9a\u4e0d\u9700\u8981\u4fee\u6539
acpsdk.signCert.type=PKCS12