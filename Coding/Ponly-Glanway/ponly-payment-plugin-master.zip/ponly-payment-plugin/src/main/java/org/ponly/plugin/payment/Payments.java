package org.ponly.plugin.payment;

import org.ponly.common.util.StringUtils;
import org.ponly.plugin.payment.impl.Alipay;
import org.ponly.plugin.payment.impl.QuickMoney;
import org.ponly.plugin.payment.impl.UnionPay;
import org.ponly.plugin.payment.impl.Wxpay;

import java.util.Properties;

/**
 * 支付工具类
 *
 * @author vacoor
 */
public abstract class Payments {

    /**
     * 获取给定支付通道的实例, 如果不存在返回 null
     *
     * @param channel 支付通道名称
     * @param props   支付通道配置
     * @return 支付通道实例或null
     */
    public static Payment getPayment(String channel, Properties props) {
        if ("alipay".equals(channel)) {
            String seller = props.getProperty("alipay.seller");
            String pid = props.getProperty("alipay.pid");
            String key = props.getProperty("alipay.key");
            return new Alipay(seller, pid, key);
        }
        if ("quick_money".equals(channel)) {
            String env = props.getProperty("quick_money.env");
            String mid = props.getProperty("quick_money.mid");

            String privateKey = props.getProperty("quick_money.private_key");
            String publicKey = props.getProperty("quick_money.private_key");

            /*-
             * update 0.2
             */
            String keyStorePath = props.getProperty("quick_money.keystore_path");
            String keyStorePass = props.getProperty("quick_money.keystore_password");
            String privateKeyAlias = props.getProperty("quick_money.private_key_alias");
            String privateKeyPass = props.getProperty("quick_money.private_key_password");
            String certificatePath = props.getProperty("quick_money.certificate_path");

            if (StringUtils.hasText(privateKey) || StringUtils.hasText(publicKey)) {
                return null == env
                        ? new QuickMoney(mid, privateKey, publicKey)
                        : new QuickMoney(env, mid, privateKey, publicKey);
            } else {
                if (null == env) {
                    return new QuickMoney(mid, keyStorePath, keyStorePass, privateKeyAlias, privateKeyPass, certificatePath);
                }
                return new QuickMoney(env, mid, keyStorePath, keyStorePass, privateKeyAlias, privateKeyPass, certificatePath);
            }
        }
        if ("unionpay".equals(channel)) {
            String mid = props.getProperty("unionpay.mid");
            return new UnionPay(mid, "", "");
        }
        if ("wxpay".equals(channel)) {
            String appid = props.getProperty("wxpay.appid");
            String appSecret = props.getProperty("wxpay.appSecret");
            String partnerId = props.getProperty("wxpay.partnerId");
            String partnerKey = props.getProperty("wxpay.partnerKey");
            return new Wxpay(appid, appSecret, partnerId, partnerKey);
        }
        return null;
    }

    /*
    public static void main(String[] args) throws IOException {
        Properties props = new Properties();
        // alipay
        props.setProperty("alipay.seller", "admin@021yhc.com");
        props.setProperty("alipay.pid", "2088511711104104");
        props.setProperty("alipay.key", "mvy7b85ttcd6egdzt3ddvuz36zi8fscv");

//        props.setProperty("alipay.seller", "dingjianmall@163.com");
//        props.setProperty("alipay.pid", "2088121001015522");
//        props.setProperty("alipay.key", "oh8ua3bwn2j2iybqpdfp1llc42fofu3i");

//        props.setProperty("alipay.seller", "wayne@noahsgroup.com");
//        props.setProperty("alipay.pid", "2088611187488178");
//        props.setProperty("alipay.key", "h77o3icynnnucmwp3q83dqv5nzdu1c3h");

        // quick money
        props.setProperty("quick_money.mid", "1002408886501");
        props.setProperty("quick_money.mid", "1001213884201");
        props.setProperty("quick_money.private_key", "");
        props.setProperty("quick_money.public_key", "");
        // china union pay
        props.setProperty("unionpay.mid", "777290058123292");

        // wxpay
        props.setProperty("wxpay.appid", "wx2d1f6ee115ba1b85");
        props.setProperty("wxpay.appSecret", "d0d72d9047d986c86222dd60af25cfed");
        props.setProperty("wxpay.partnerId", "1276984801");
        props.setProperty("wxpay.partnerKey", "b4bacc7fb83b3f4b08ef5910b7b7feec");
    }
    */
}
