package org.ponly.plugin.payment;


import org.ponly.plugin.Lifecycle;
import org.ponly.plugin.PluginProvider;

/**
 * @author vacoor
 */
public abstract class PaymentSpi implements PluginProvider<Payment>, Lifecycle {

    @Override
    public void init() {
        System.out.println("init - " + getName());
    }

    @Override
    public void destroy() {
        System.out.println("destroy - " + getName());
    }
}
