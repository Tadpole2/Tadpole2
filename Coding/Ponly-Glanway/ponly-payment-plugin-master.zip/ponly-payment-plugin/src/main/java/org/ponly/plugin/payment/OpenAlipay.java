package org.ponly.plugin.payment;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.ponly.common.util.HttpUtils;
import org.ponly.plugin.payment.impl.Utils;

/**
 * Created by Vacoor on 2017-05-23.
 */
public class OpenAlipay {
    public static void main(String[] args) throws IOException {
        final String OPEN_GATEWAY = "https://openapi.alipay.com/gateway.do";

        final Map<String, String> params = new HashMap<>();

        // 公共请求参数.
        params.put("app_id", "2017051207217247");
        params.put("method", "alipay.trade.create");
        params.put("format", "json");
        params.put("charset", "utf-8");
        params.put("sign_type", "RSA2");
        // params.put("sign", "");
        params.put("timestamp", "2017-05-23 10:33:08");//new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        params.put("version", "1.0");
        params.put("notify_url", "http://www.thesodaily.com/alipay_notify.html");
        params.put("app_auth_token", "");  // FIXME
        params.put("biz_content", "");

        //
        params.put("out_trade_no", "20150320010101001");
        params.put("seller_id", "2088621193692706");
        params.put("total_amount", "0.01");
        // ...
        params.put("subject", "Test");
        params.put("body", "iPhone 7 紫金版");

        final String nv = Utils.toSortedNVString(params);
        System.out.println(nv);
        params.put("sign", "O+min7UQMH9vs7VTJp7Vrx8lMU1qHBtqotV23ZfT6xKCr1/EBNXnUMPliw2a4vFm8CxeHsh175bDnQYM/tfA/VcM4AIDzgcmgvU/e3Pn7Tp+HtkGSnC1YDy5L33KlNg9ZlQBVp3m7tcId+s3VdtyQxqd2UAj52wImXAIRxrqNH4ZlkNlC5/uniix3rOFn7X4xsCcUgcWUqmG8wSbf7H/cZMd8tdIrxuh9Fq1lbOamZpbVR1AcQnkQ9PDVFMjAF4B/xGt+WFOOvykhLwR9ohNP+z47r/272QP+Ke/h+9AWKGgMNNmVCCPfOXFBqai9pFYtc4beW7oo+ytJd/HWIZivw==");

        final String response = HttpUtils.post(OPEN_GATEWAY, params, 1000, 1000);
        System.out.println(response);
    }
}
