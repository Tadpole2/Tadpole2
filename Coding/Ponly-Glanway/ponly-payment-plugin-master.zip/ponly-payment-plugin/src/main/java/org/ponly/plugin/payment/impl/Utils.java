package org.ponly.plugin.payment.impl;

import org.ponly.common.codec.Base64;
import org.ponly.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

/**
 * 工具类
 */
public class Utils {
    private static final Logger LOG = LoggerFactory.getLogger(Utils.class);

    public static final String KS_TYPE_JKS = "JKS";             // JKS 类型 KeyStore
    public static final String KS_TYPE_PKCS12 = "PKCS12";       // PKCS12 类型 KeyStore
    public static final String BC_PROV_ALGORITHM_SHA1RSA = "SHA1withRSA";
    public static final Pattern APPLE_MOBILE_PATTERN = Pattern.compile(" Mobile\\/");
    public static final Pattern OTHER_MOBILE_PATTERN = Pattern.compile("NokiaN[^\\/]*|Android \\d\\.\\d|webOS\\/\\d\\.\\d");

    public static boolean isMobileRequest(HttpServletRequest request) {
        String ua = request.getHeader("User-Agent");
        return APPLE_MOBILE_PATTERN.matcher(ua).find() || OTHER_MOBILE_PATTERN.matcher(ua).find();
    }

    public static boolean isWechatRequest(HttpServletRequest request) {
        String ua = request.getHeader("User-Agent").toLowerCase();
        return ua.contains("micromessenger/");
    }

    public static boolean isAlipayRequest(HttpServletRequest request) {
        String ua = request.getHeader("User-Agent").toLowerCase();
        return ua.contains("alipayclient/");
    }

    /**
     * 构建一个提交到支付网关的 html 页面
     *
     * @param action 提交到的网关地址
     * @param params 表单数据
     * @return html
     */
    public static String buildRequestHtml(String action, Map<String, String> params) {
        return buildRequestHtml(action, "POST", params);
    }

    public static String buildRequestHtml(String action, String method, Map<String, String> params) {
        StringBuilder html = new StringBuilder();
        html.append("<html><head><meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/></head>")
                .append("<body>")
                .append("<form id=\"payment\" name=\"payment\" action=\"").append(action).append("\" method=\"").append(method).append("\">");

        for (Map.Entry<String, String> entry : params.entrySet()) {
            String name = entry.getKey();
            String value = entry.getValue();
            html.append("<input type=\"hidden\" name=\"").append(name).append("\" value=\"").append(value).append("\"/>");
        }

        html.append("</form>");
        html.append("<script>document.forms['payment'].submit();</script>");
        html.append("</body></html>");
        return html.toString();
    }

    public static Map<String, String> toUniqueMap(Map<String, String[]> data) {
        Map<String, String> uniqueMap = new HashMap<String, String>();
        if (null == data) {
            return uniqueMap;
        }
        for (Map.Entry<String, String[]> entry : data.entrySet()) {
            String key = entry.getKey();
            String[] values = entry.getValue();
            for (String value : values) {
                uniqueMap.put(key, value);
            }
        }
        return uniqueMap;
    }

    /**
     * 参数名按照字典顺序排列后的 k=v&k=v 字符串
     */
    public static String toSortedNVString(Map<String, String> params, String... ignoreKeys) {
        List<String> ignores = Arrays.asList(ignoreKeys);
        List<String> keys = new ArrayList<String>(params.keySet());
        Collections.sort(keys);
        StringBuilder buff = new StringBuilder();

        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);
            String value = params.get(key);

            if (null == value || value.length() < 1 || ignores.contains(key)) {
                continue;
            }

            buff.append(key).append("=").append(value);
            buff.append('&');
        }
        buff.deleteCharAt(buff.length() - 1);
        return buff.toString();
    }

    public static String toNVString(Map<String, String> params, String... keys) {
        if (null == params || null == keys) {
            return "";
        }

        if (keys.length < 1) {
            keys = params.keySet().toArray(new String[params.size()]);
        }
        StringBuilder buff = new StringBuilder();
        for (String key : keys) {
            String value = params.get(key);
            if (null != value && value.length() > 0) {
                if (buff.length() > 0) {
                    buff.append('&');
                }
                buff.append(key).append('=').append(value);
            }
        }
        return buff.toString();
    }

    /**
     * 使用给定签名算法和私钥签名数据, 返回签名的 Base64 形式
     *
     * @param algorithm  签名算法
     * @param privateKey 私钥
     * @param bytes      待签名数据
     * @return 签名的 Base64 形式
     */
    public static String signAsBase64(String algorithm, PrivateKey privateKey, byte[] bytes) {
        return Base64.encodeToString(sign(algorithm, null, privateKey, bytes));
    }

    /**
     * 使用给定签名算法,提供者,私钥签名数据, 返回签名的 Base64 形式
     *
     * @param algorithm  签名算法
     * @param provider   算法提供者
     * @param privateKey 私钥
     * @param bytes      待签名数据
     * @return 签名的 Base64 形式
     */
    public static byte[] sign(String algorithm, String provider, PrivateKey privateKey, byte[] bytes) {
        try {
            Signature signature = null != provider ? Signature.getInstance(algorithm, provider) : Signature.getInstance(algorithm);
            signature.initSign(privateKey);
            signature.update(bytes);
            return signature.sign();
        } catch (Exception e) {
            throw new IllegalStateException("signature fail: ", e);
        }
    }

    public static boolean verifySign(String algorithm, PublicKey publicKey, byte[] rawBytes, byte[] signBytes) {
        return verifySign(algorithm, null, publicKey, rawBytes, signBytes);
    }

    public static boolean verifySign(String algorithm, String provider, PublicKey publicKey, byte[] rawBytes, byte[] signBytes) {
        try {
            Signature signature = null != provider ? Signature.getInstance(algorithm, provider) : Signature.getInstance(algorithm);
            signature.initVerify(publicKey);
            signature.update(rawBytes);
            return signature.verify(signBytes);
        } catch (Exception e) {
            throw new IllegalStateException("signature fail: ", e);
        }
    }

    /**
     * 获取 KeyStore 中的第一个 Key
     *
     * @param ks      KeyStore
     * @param keyPass Key密码
     * @param <K>     Key类型
     * @return 第一个 Key 或 null
     */
    public static <K extends Key> K getFirstKey(KeyStore ks, String keyPass) {
        return getKey(ks, getFirstAlias(ks), keyPass);
    }

    public static <C extends Certificate> C getFirstCertificate(KeyStore ks) {
        return getCertificate(ks, getFirstAlias(ks));
    }

    public static String getFirstAlias(KeyStore ks) {
        if (null != ks) {
            try {
                Enumeration<String> aliases = ks.aliases();
                if (aliases.hasMoreElements()) {
                    return aliases.nextElement();
                }
            } catch (KeyStoreException e) {
                throw new IllegalStateException(e);
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public static <K extends Key> K getKey(KeyStore ks, String keyAlias, String keyPass) {
        if (null == ks) {
            return null;
        }
        try {
            return (K) ks.getKey(keyAlias, null != keyPass ? keyPass.toCharArray() : null);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    @SuppressWarnings("unchecked")
    public static <C extends Certificate> C getCertificate(KeyStore ks, String alias) {
        try {
            return (C) (null != ks ? ks.getCertificate(alias) : null);
        } catch (KeyStoreException e) {
            throw new IllegalStateException(e);
        }
    }

    public static X509Certificate getX509Certificate(Class<?> clazz, String cert) {
        InputStream input = clazz.getResourceAsStream(cert);
        input = null != input ? input : clazz.getClassLoader().getResourceAsStream(cert);

        if (null == input) {
            return null;
        }
        try {
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            return (X509Certificate) certFactory.generateCertificate(input);
        } catch (CertificateException e) {
            throw new IllegalStateException(e);
        }
    }

    public static KeyStore loadKeyStore(Class<?> clazz, String pfx, String ksType, String ksPassword) {
        InputStream input = clazz.getResourceAsStream(pfx);
        input = null != input ? input : clazz.getClassLoader().getResourceAsStream(pfx);

        if (null == input) {
            return null;
        }

        KeyStore ks = null;
        try {
            if (KS_TYPE_JKS.equals(ksType)) {
                ks = KeyStore.getInstance(ksType);
            } else if (KS_TYPE_PKCS12.equals(ksType)) {
                String jdkVendor = System.getProperty("java.vm.vendor");
                String javaVersion = System.getProperty("java.version");
                LOG.info("java.vm.vendor=[{}], java.version=[{}]", jdkVendor, javaVersion);

                // FIXME
                // Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
                if (null != jdkVendor && jdkVendor.startsWith("IBM")) {
                    // FIXME
                    // 如果使用IBMJDK,则强制设置BouncyCastleProvider的指定位置,解决使用IBMJDK时兼容性问题
                    // Security.insertProviderAt(new org.bouncycastle.jce.provider.BouncyCastleProvider(), 1);
                } else {
                    // Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
                }
                ks = KeyStore.getInstance(ksType);
            }

            LOG.debug("Load RSA CertPath=[" + pfx + "],Pwd=[" + ksPassword + "]");
            char[] passChars = !StringUtils.hasText(ksPassword) ? null : ksPassword.toCharArray();
            if (null != ks) {
                ks.load(input, passChars);
            }
            return ks;
        } catch (Exception e) {
            if (null == Security.getProvider("BC")) {
                LOG.warn("BC Provider not installed");
            }
            LOG.error("read KeyStore failed", e);
            if ((e instanceof KeyStoreException) && "PKCS12".equals(ksType)) {
                Security.removeProvider("BC");
            }
            return null;
        } finally {
            try {
                input.close();
            } catch (IOException ignore) {
            }
        }
    }

    static PrivateKey toPrivateKey(String base64EncodedPrivateKey) throws InvalidKeySpecException, NoSuchAlgorithmException {
        return toPrivateKey(Base64.decode(base64EncodedPrivateKey));
    }

    static PublicKey toPublicKey(String base64EncodedX509PublicKey) throws InvalidKeySpecException, NoSuchAlgorithmException {
        return toPublicKey(Base64.decode(base64EncodedX509PublicKey));
    }

    static PrivateKey toPrivateKey(byte[] encodedKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
        return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(encodedKey));
    }


    static PublicKey toPublicKey(byte[] x509EncodedKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
        return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(x509EncodedKey));
    }

    public static String getCurrentDate() {
        return getCurrentDate("yyyyMMddHHmmss");
    }

    public static String getCurrentDate(String format) {
        return formatDate(new Date(), format);
    }

    public static String formatDate(Date date, String format) {
        return new SimpleDateFormat(format).format(date);
    }

    public static Date parseDate(String date, String format) {
        try {
            return (null != date && !"".equals(date)) ? new SimpleDateFormat(format).parse(date) : null;
        } catch (ParseException e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static String toYuan(int fen) {
        BigDecimal factor = BigDecimal.valueOf(100);
        BigDecimal yuan = BigDecimal.valueOf(fen).divide(
                factor, 3, BigDecimal.ROUND_HALF_UP
        );
        return new DecimalFormat("0.00").format(yuan);
    }

    public static int toFen(BigDecimal yuan) {
        BigDecimal factor = BigDecimal.valueOf(100);
        BigDecimal fen = yuan.multiply(factor);
        return fen.intValue();
    }

    public static int toFen(String yuan) {
        return toFen(new BigDecimal(yuan));
    }
}
