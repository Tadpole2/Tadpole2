package org.ponly.plugin.payment.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.ponly.common.crypto.digest.Hash;
import org.ponly.common.util.*;
import org.ponly.common.xml.JAXP;
import org.ponly.plugin.payment.Payment;
import org.ponly.web.servlet.Cookie;
import org.ponly.web.servlet.SimpleCookie;
import org.ponly.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


import static org.ponly.common.util.HttpUtils.encode;
import static org.ponly.plugin.payment.impl.Utils.formatDate;
import static org.ponly.plugin.payment.impl.Utils.isWechatRequest;

/**
 * 微信支付
 * https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=6_3
 * 微信 Debugger 工具: http://mp.weixin.qq.com/wiki/10/e5f772f4521da17fa0d7304f68b97d7e.html
 * 注意:
 * https://mp.weixin.qq.com
 * 1. 微信支付 - 开发配置 - 支付授权目录(需要配置在支付URL的上级目录)
 * 2. 开发 - 网页账号 - 网页授权获取用户基本信息 修改域名 (Oauth2 授权目录)
 * 以上两个地址必须匹配
 *
 * @author vacoor
 */
public class Wxpay implements Payment {
    private static final Logger LOG = LoggerFactory.getLogger(Wxpay.class);
    private static final Pattern DEEP_LINK_PATTERN = Pattern.compile("(?<=\")weixin://wap/pay\\?[^\"]+(?=\")");
    // 统一下单 URL
    private static final String UNIFIED_ORDER_URL = "https://api.mch.weixin.qq.com/pay/unifiedorder";
    private static final String RET_SUCCESS = "SUCCESS";    // SUCCESS / FAIL

    public static final String TRADE_NATIVE = "NATIVE";    // 原生扫码支付
    public static final String TRADE_JSAPI = "JSAPI";      // 公众号支付 (微信浏览器)

    /**
     * 过时, 2017 微信已经开放H5支付.
     * H5支付需要另外申请, 且微信配置域名白名单.
     *
     * @see #TRADE_MWEB
     * @deprecated
     */
    @Deprecated
    public static final String TRADE_WAP = "WAP";          // HTML5
    public static final String TRADE_MWEB = "MWEB";        // HTML5
    private static final String JSAPI_RETURN_TRADE_NO_PARAM = "tradeNo";

    private final String appId;
    private final String appSecret;
    private final String partnerId;
    private final String partnerKey;
    private String notifyUrl;
    private String returnUrl;       // 只有 JSAPI 支持

    public Wxpay(String appId, String appSecret, String partnerId, String partnerKey) {
        this.appId = appId;
        this.appSecret = appSecret;
        this.partnerId = partnerId;
        this.partnerKey = partnerKey;
    }

    @Override
    public void setNotifyUrl(String url) {
        notifyUrl = url;
    }

    @Override
    public void setReturnUrl(String url) {
        this.returnUrl = url;
    }

    @Override
    public void postTransaction(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee, Date expire, String subject, String body) throws IOException {
        postTransaction(request, response, tradeNo, fee, expire, subject, body, null);
    }

    @Override
    public void postTransaction(final HttpServletRequest request, final HttpServletResponse response,
                                final String tradeNo, final int fee, final Date expire,
                                final String subject, final String body,
                                final Map<String, String> udfParams) throws IOException {
        final boolean isWx = isWechatRequest(request);
        String openid = null;

        // 如果是微信内置浏览器但没有认证, 则去认证
        if (isWx && null == (openid = getOpenid(request, response))) {
            issueRedirectToAuthorize(request, response);
            return;
        }

        final String ip = WebUtils.getRemoteAddr(request);
        if (!isWx) { // H5 pay.
            /*-
             * H5 pay.
             * 实际是包装了 deepLink.
             */
            try {
                final String mwebUrl = getMwebUrl(tradeNo, fee, expire, subject, body, udfParams, ip);
                final String finalUrl = StringUtils.hasText(returnUrl) ? (mwebUrl + "&redirect_url=" + returnUrl) : mwebUrl;
                response.sendRedirect(finalUrl);
                return;
            } catch (Exception ignore) {
                LOG.warn("获取 mweb_url 失败", ignore);
            }
        }

        String html = doPostTransaction(openid, tradeNo, fee, expire, subject, body, udfParams, ip);
        if (null == html) {
            response.reset();
            response.sendError(500, "ILLEGAL_EXTERFACE");
        } else {
            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().write(html);
        }
    }

    protected String doPostTransaction(String openid, String tradeNo, int fee, Date expire, String subject, String body, Map<String, String> udfParams, final String remoteIp) throws IOException {
        Map<String, String> jsApiPayParams = null;
        if (null != openid) {
            jsApiPayParams = getJsApiPayParams(openid, tradeNo, fee, expire, subject, body, udfParams, remoteIp);
        }

        String wapDeepLink = null;
        try {
            wapDeepLink = getWapPayDeepLink(tradeNo, fee, expire, subject, body, udfParams, remoteIp);
        } catch (Exception ignore) {
            // 可能没有额外开通 WAP支付权限
            LOG.warn("获取 WAP 支付失败", ignore);
        }

        /*
        String mwebUrl = null;
        try {
            mwebUrl = getMwebUrl(tradeNo, fee, expire, subject, body, udfParams);
        } catch (Exception ignore) {
            LOG.warn("获取 mweb_url 失败", ignore);
        }
        */

        /*
        // 两种方式都无法支持
        if (null == wapPayUrl && null == jsApiPayParams) {
            return null;
        }
        */

        InputStream in = Wxpay.class.getResourceAsStream("wxpay-jsapi.html");
        String html = IOUtils.toString(in, Charset.forName("UTF-8"), true);

        final Map<String, String> payParams = jsApiPayParams;
        // 设置 JSAPI 回调
        if (null != jsApiPayParams) {
            String callbackUrl = returnUrl;
            if (StringUtils.hasText(callbackUrl)) {
                callbackUrl += callbackUrl.contains("?") ? "&" : "?";
                callbackUrl += JSAPI_RETURN_TRADE_NO_PARAM + "=" + tradeNo;
            }
            payParams.put("returnUrl", callbackUrl);
            payParams.put("pkgData", payParams.get("package"));
        }
        LOG.debug("html: {}", html);
        // 替换 html 中变量
        return new TokenParser("${", "}") {
            @Override
            protected String handleToken(String key) {
                String value = null != payParams ? payParams.get(key) : "";
                return null != value ? value : "";
            }
        }.doParse(html);
    }

    @Override
    public String getQRCodeUrl(String tradeNo, int fee, Date expire, String subject, String body, int width) throws IOException {
        return getNativePayCodeUrl(tradeNo, fee, expire, subject, body);
    }

    /**
     * 获取 Native 支付 模式2 的 code_url, 使用该 code_url 生成二维码扫描支付即可
     * 实际也可以使用微信打开 code_url 来支付(替代 js api)
     * <p/>
     * 模式2: https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=6_5
     * 参数: https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_1
     *
     * @return code_url
     * @throws IOException
     */
    public String getNativePayCodeUrl(String tradeNo, int fee, Date expire, String subject, String body) throws IOException {
        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put("trade_type", TRADE_NATIVE);              // 交易类型
        paramsMap.put("spbill_create_ip", "127.0.0.1");         // 本机的Ip
        paramsMap.put("product_id", tradeNo);                   // 商户根据自己业务传递的参数 必填, 长度32
        paramsMap.put("body", subject);                         // 支付简要描述
        paramsMap.put("detail", body);                          // 详细描述
        paramsMap.put("attach", "");                            // 附加数据
        paramsMap.put("out_trade_no", tradeNo);                 // 商户 后台的贸易单号
        paramsMap.put("total_fee", Integer.toString(fee));      // 金额必须为整数  单位为分
        paramsMap.put("notify_url", notifyUrl);                 // 支付成功后，回调地址
        paramsMap.put("appid", appId);                          // appid
        paramsMap.put("mch_id", partnerId);                     // 商户号
        paramsMap.put("nonce_str", createNonce());              // 随机数

        if (null != expire) {
            paramsMap.put("time_expire", formatDate(expire, "yyyyMMddHHmmss"));             // 订单失效时间
        }

        paramsMap.put("sign", sign(paramsMap, partnerKey));

        String xml = toXml(paramsMap);
        String ret = HttpUtils.post(UNIFIED_ORDER_URL, "text/xml", xml.getBytes("UTF-8"), 0, 0);

        Element doc = JAXP.parse(ret).getDocumentElement();
        if (!RET_SUCCESS.equals(text(one(doc, "return_code")))) {
            String error = text(one(doc, "return_msg"));
            throw new IllegalStateException(error);
        }
        if (!RET_SUCCESS.equals(text(one(doc, "result_code")))) {
            String code = text(one(doc, "err_code"));
            String error = text(one(doc, "err_code_des"));
            throw new IllegalStateException(error);
        }
        return text(one(doc, "code_url"));
    }

    /* **************************************************************
     * 微信支付: JsBridge
     * https://pay.weixin.qq.com/wiki/doc/api/jsapi.php?chapter=7_7&index=6
     * **************************************************************/

    /**
     * 构建 JS Api Bridge 支付参数
     * <p/>
     * 1. 调用统一下单接口获取 prepayId
     * 2. 根据 prepayId 生成 JsBridge 支付参数
     * 3. 将 JsBridge 支付参数转换为 json 调用 JsBridge 支付
     * 请注意该接口只能在你配置的支付目录下调用，同时需确保支付目录在JS接口安全域名下
     */
    public Map<String, String> getJsApiPayParams(String openid, String tradeNo, int fee, Date expire, String subject, String body, Map<String, String> udfParams, final String remoteIp) throws IOException {
        String prepayId = getPrepayIdOrMwebUrl(appId, partnerId, partnerKey, notifyUrl, TRADE_JSAPI, openid, tradeNo, fee, expire, subject, body, udfParams, remoteIp);

        Map<String, String> bridgePayParams = new TreeMap<>();
        bridgePayParams.put("appId", appId);
        bridgePayParams.put("timeStamp", new Date().getTime() / 1000 + "");
        bridgePayParams.put("nonceStr", createNonce());
        bridgePayParams.put("package", "prepay_id=" + prepayId);
        bridgePayParams.put("signType", "MD5");
        bridgePayParams.put("paySign", sign(bridgePayParams, partnerKey));

        if (null != udfParams) {
            bridgePayParams.putAll(udfParams);
        }

        return bridgePayParams;
    }

    /* **************************************************************
     * 微信支付: H5
     * https://pay.weixin.qq.com/wiki/doc/api/H5.php?chapter=15_1
     * **************************************************************/

    private String getMwebUrl(String tradeNo, int fee, Date expire, String subject, String body, final Map<String, String> udfParams, final String remoteIp) throws IOException {
        return getPrepayIdOrMwebUrl(appId, partnerId, partnerKey, notifyUrl, TRADE_MWEB, null, tradeNo, fee, expire, subject, body, udfParams, remoteIp);
    }

    private String getDeepLink(String tradeNo, int fee, Date expire, String subject, String body, final Map<String, String> udfParams, final String refererUrl, final String remoteIp) throws IOException {
        String deepLink = null;
        try {
            deepLink = getWapPayDeepLink(tradeNo, fee, expire, subject, body, udfParams, remoteIp);
        } catch (final Exception e) {
            LOG.info("直接获取WAP Pay deep link error");
        }
        if (!StringUtils.hasText(deepLink)) {
            final String mwebUrl = getMwebUrl(tradeNo, fee, expire, subject, body, udfParams, remoteIp);
            deepLink = tryGetDeepLinkFromMwebUrl(mwebUrl, refererUrl);
        }
        return deepLink;
    }

    private static String tryGetDeepLinkFromMwebUrl(final String mwebUrl, final String refererUrl) {
        String deepLink = null;
        try {
            final HttpURLConnection httpUrlConnection = (HttpURLConnection) new URL(mwebUrl).openConnection();
            httpUrlConnection.setRequestMethod("GET");

            if (StringUtils.hasText(refererUrl)) { // TODO should must.
                httpUrlConnection.setRequestProperty("Referer", refererUrl);
            }

            httpUrlConnection.setDoInput(true);
            httpUrlConnection.setDoOutput(false);

            final int responseCode = httpUrlConnection.getResponseCode();
            if (HttpURLConnection.HTTP_OK == responseCode) {
                final InputStream in = httpUrlConnection.getInputStream();
                final String responseBody = IOUtils.toString(in, Charset.forName("UTF-8"), true);


                final Matcher matcher = DEEP_LINK_PATTERN.matcher(responseBody);
                if (matcher.find()) {
                    deepLink = matcher.group();
                } else {
                    LOG.warn("can't get deep link from mweb_url, response body: {}", responseBody);
                }
            } else {
                LOG.warn("can't get deep link from mweb_url, response code: {}", responseCode);
            }
            httpUrlConnection.disconnect();
        } catch (final IOException ex) {
            // ignore.
            deepLink = null;
        }
        return deepLink;
    }

    /* **************************************************************
     * 微信支付: WAP
     * demo: http://wxpay.weixin.qq.com/pub_v2/pay/wap.v2.php
     * https://pay.weixin.qq.com/wiki/doc/api/wap.php?chapter=15_3
     * https://pay.weixin.qq.com/wiki/doc/api/wap.php?chapter=15_4
     * **************************************************************/
    @Deprecated
    private String getWapPayDeepLink(String tradeNo, int fee, Date expire, String subject, String body, final Map<String, String> udfParams, final String remoteIp) throws IOException {
        // 可能抛出异常: 您没有WAP支付权限
        String prepayId = getPrepayIdOrMwebUrl(appId, partnerId, partnerKey, notifyUrl, TRADE_WAP, null, tradeNo, fee, expire, subject, body, udfParams, remoteIp);

        StringBuilder buff = new StringBuilder();
        buff.append("appid=").append(encode(appId))
                .append("&noncestr=").append(encode(createNonce()))
                .append("&package=WAP") // 固定值
                .append("&prepayid=").append(encode(prepayId))
                .append("&timestamp=").append(encode(new Date().getTime() / 1000 + ""));

        // weixin://wap/pay?prepayid%3Dwx2017070413231393d8d71a290899165496&package=1990917440&noncestr=1499145796&sign=f7497f0b09486326759000178b19eb63
        // 上面已经是排序的, 直接签名
        String sign = sign(buff.toString(), partnerKey);
        buff.append("&sign=").append(encode(sign));

        // deeplink
        return "weixin://wap/pay?" + encode(buff.toString());
    }

    /**
     * 获取 prepay_id or mweb_url.
     * 参数参考: https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_1
     *
     * @param appId      appId
     * @param partnerId  partnerId
     * @param partnerKey partnerKey
     * @param notifyUrl  异步通知 URL
     * @param tradeType  交易类型
     * @param openid     OPENID
     * @param tradeNo    订单号
     * @param fee        订单金额
     * @param expire     过期时间
     * @param subject    订单主题
     * @param body       订单明细
     * @return 微信预支付订单id
     */
    private static String getPrepayIdOrMwebUrl(final String appId, final String partnerId, final String partnerKey,
                                               final String notifyUrl, final String tradeType, final String openid,
                                               final String tradeNo, final int fee, final Date expire,
                                               final String subject, final String body, final Map<String, String> udfParams,
                                               final String remoteIp) throws IOException {
        Map<String, String> paramsMap = new HashMap<String, String>();
        paramsMap.put("appid", appId);
        paramsMap.put("mch_id", partnerId);
        paramsMap.put("nonce_str", createNonce());
        paramsMap.put("body", subject);                             // 支付简要描述
        paramsMap.put("detail", body);                              // 详细描述
        paramsMap.put("attach", "");                                // 附加数据
        paramsMap.put("out_trade_no", tradeNo);
        paramsMap.put("total_fee", Integer.toString(fee));
        /*-
         * H5 支付必须, 给到的IP必须和用户跳转到支付地址的IP一致, 才能通过安全校验.
         */
        paramsMap.put("spbill_create_ip", null != remoteIp ? remoteIp : "");
        if (null != expire) {
            paramsMap.put("time_expire", formatDate(expire, "yyyyMMddHHmmss"));             // 订单失效时间
        }
        paramsMap.put("trade_type", tradeType);
        paramsMap.put("notify_url", notifyUrl);

        if (TRADE_JSAPI.equals(tradeType)) {
            // trade_type=JSAPI，此参数必传，用户在商户appid下的唯一标识
            paramsMap.put("openid", openid);
        }

        if (null != udfParams) {
            paramsMap.putAll(udfParams);
        }

        paramsMap.put("sign", sign(paramsMap, partnerKey));

        final String xml = toXml(paramsMap);
        final String ret = HttpUtils.post(UNIFIED_ORDER_URL, "text/xml", xml.getBytes("UTF-8"), 0, 0);

        // 解析 xml 结果
        final Element doc = JAXP.parse(ret).getDocumentElement();
        final String returnTradeType = text(one(doc, "trade_type"));
        final String returnCode = text(one(doc, "return_code"));
        final String returnPrepayId = text(one(doc, "prepay_id"));
        // update 2017.07.04 增加 H5 处理.
        final String mwebUrl = text(one(doc, "mweb_url"));
        if (StringUtils.hasText(returnTradeType) && null != returnTradeType && !returnTradeType.equalsIgnoreCase(tradeType)) {
            throw new IllegalStateException("request tradeType[%s] and response tradeType[%s] are inconsistent");
        }

        if (!RET_SUCCESS.equals(returnCode)) {
            String error = text(one(doc, "return_msg"));
            throw new IllegalStateException(error);
        }

        if (TRADE_MWEB.equalsIgnoreCase(returnTradeType)) {
            if (!StringUtils.hasText(mwebUrl)) {
                throw new IllegalStateException("wxpay server response mweb_url is blank");
            }
            return mwebUrl;
        } else if (!StringUtils.hasText(returnPrepayId)) {
            throw new IllegalStateException("wxpay server response prepay_id is blank");
        }
        return returnPrepayId;
    }

    @Override
    public boolean verifyTransaction(HttpServletRequest request, TransactionCallback callback) {
        boolean executed = false;
        Exception exception = null;
        String xml = null;
        boolean isQueryResult = false;
        try {
            String method = request.getMethod();
            String ctype = request.getHeader("Content-Type");
            int index = null != ctype ? ctype.toLowerCase().indexOf("charset=") : -1;

            String charset = "UTF-8";
            if (-1 < index) {
                charset = ctype.substring(index + "charset=".length());
            }
            if ("POST".equals(method)) {
                InputStream in = request.getInputStream();
                xml = IOUtils.toString(in, Charset.forName(charset), false);
            } else if ("GET".equals(method)) {
                /*-
                 * 如果是GET请求,且传递了订单号
                 * 则为自定义的 JSPAPI 同步 GET 回调
                 * 需要去查询订单支付状态
                 */
                String tradeNo = request.getParameter(JSAPI_RETURN_TRADE_NO_PARAM);
                if (null != tradeNo) {
                    xml = queryTrade(tradeNo);
                    isQueryResult = true;
                }
            }

            if (null != xml) {
                executed = doVerifyPayResult(xml, isQueryResult, callback);
            }
        } catch (IOException e) {
            executed = false;
            exception = e;
        } finally {
            if (!executed) {
                Map<String, String> params = null != xml ? toUniqueMap(xml) : Collections.<String, String>emptyMap();
                callback.onError(null, null, exception, params);
            }
        }
        return executed;
    }

    @Override
    public boolean verifyTransaction(HttpServletRequest request, HttpServletResponse response, TransactionCallback callback) throws Exception {
        boolean executed = false;
        // https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_7
        if (verifyTransaction(request, callback)) {
            //返回给银联服务器http 200  状态码
            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/xml");
            response.getWriter().print("<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>");
            executed = true;
        } else {
            response.sendError(400);
            // response.getWriter().print("<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[PROCESS_FAIL]]></return_msg></xml>");
        }
        return executed;
    }

    /**
     * 验证支付响应
     *
     * @param xml           支付异步通知 xml
     * @param isQueryResult 是否是查询订单的结果
     * @param callback      支付处理回调
     * @return 是否成功执行回调
     */
    protected boolean doVerifyPayResult(String xml, boolean isQueryResult, TransactionCallback callback) {
        Map<String, String> ret = toUniqueMap(xml);

        boolean executed = false;
        if (doVerifyPayResult(xml, isQueryResult)) {
            String outTradeNo = ret.get("out_trade_no");
            String transactionId = ret.get("transaction_id");
            int fee = Integer.parseInt(ret.get("total_fee"));
            String paidTimeStr = ret.get("time_end");
            Date paidTime = Utils.parseDate(paidTimeStr, "yyyyMMddHHmmss");

            callback.onFinished(outTradeNo, fee, paidTime, transactionId, ret);
            executed = true;
        }
        return executed;
    }


    /**
     * 验证支付结果
     * <p/>
     * 支付结果通过两种情况获取:
     * 1. 被动获取： notify_url
     * 2. 主动获取：订单状态查询
     * 两者不同之处在于 trade_state
     * https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_2
     * https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_7
     */
    protected boolean doVerifyPayResult(String xml, boolean isQueryResult) {
        Element doc = JAXP.parse(xml).getDocumentElement(); // 解析 xml 结果
        String code = text(one(doc, "return_code"));

        if (!RET_SUCCESS.equals(code)) {
            String error = text(one(doc, "return_msg"));
            return false;
        }
        String _appid = text(one(doc, "appid"));
        String _mch_id = text(one(doc, "mch_id"));
        String _nonceStr = text(one(doc, "nonce_str"));
        String _sign = text(one(doc, "sign"));
        String _resultCode = text(one(doc, "result_code")); // 业务结果

        if (!appId.equals(_appid) || !partnerId.equals(_mch_id)) {
            // invalid params
            return false;
        }

        // 签名是所有参数
        // final String realSign = sign("appid=" + _appid + "&mch_id=" + _mch_id + "&nonce_str=" + _nonceStr, partnerKey);
        final String realSign = sign(toUniqueMap(xml), partnerKey);
        if (!realSign.equals(_sign)) {  // invalid sign
            return false;
        }

        // 业务错误
        if (!"SUCCESS".equals(_resultCode)) {
            String err_code = text(one(doc, "err_code"));
            String err_code_des = text(one(doc, "err_code_des"));
            return false;
        }

        // return_code = SUCCESS and result_code = SUCCESS 才有以下参数
        String device_info = text(one(doc, "device_info"));
        text(one(doc, "openid"));
        text(one(doc, "is_subscribe"));     // 用户是否关注公众账号: Y / N (仅在公众账号类型支付有效)
        text(one(doc, "trade_type"));       // 接口提交的交易类型: JSAPI, NATIVE, APP, MICRO PAY

        // 如果不是订单支付查询结果, 不需要校验 trade_state
        if (!isQueryResult) {
            return true;
        } else {
            /*-
             *  支付状态:
             * SUCCESS—支付成功
             * REFUND—转入退款
             * NOTPAY—未支付
             * CLOSED—已关闭
             * REVOKED—已撤销（刷卡支付）
             * USERPAYING--用户支付中
             * PAYERROR--支付失败(其他原因，如银行返回失败)
             */
            String tradeState = text(one(doc, "trade_state"));       //
            text(one(doc, "bank_type"));
            text(one(doc, "total_fee"));
            text(one(doc, "fee_type"));
            text(one(doc, "cash_fee"));
            text(one(doc, "cash_fee_type"));
            text(one(doc, "transaction_id"));
            text(one(doc, "out_trade_no"));
            text(one(doc, "trade_state_desc"));

            return "SUCCESS".equals(tradeState);
        }
    }

    /**
     * https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_2
     *
     * @throws IOException
     */
    public String queryTrade(String tradeNo) throws IOException {
        String orderQueryUrl = "https://api.mch.weixin.qq.com/pay/orderquery";

        Map<String, String> params = new TreeMap<>();
        params.put("appid", appId);
        params.put("mch_id", partnerId);

        // transaction_id 和 out_trade_no 二选一即可 (空也不行)
        params.put("transaction_id", "");
        params.put("out_trade_no", tradeNo);
        params.put("nonce_str", createNonce());
        params.put("sign", sign(params, partnerKey));

        String xml = toXml(params);
        return HttpUtils.post(orderQueryUrl, "text/xml", xml.getBytes("UTF-8"), 0, 0);
    }


    /* *********************************************
     *                 签名
     * ********************************************/

    /**
     * 根据微信签名规则，生成签名
     * https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=4_3
     */
    private static String sign(Map<String, String> params, String partnerKey) {
        String text = Utils.toSortedNVString(params, "sign", "key");
        return sign(text, partnerKey);
    }

    private static String sign(String text, String partnerKey) {
        text += "&key=" + partnerKey;
        return new Hash.MD5(text).toHex().toUpperCase();    // uppercase
    }

    /* *********************************************
     *                  JSAPI Oauth
     * *********************************************/

    private static final String AUTHORIZE_URL = "https://open.weixin.qq.com/connect/oauth2/authorize";
    private static final String ACCESS_TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token";
    // 企业号 access_token 获取地址, 尼玛, 微信文档找遍了都没看见
    private static final String QY_ACCESS_TOKEN_URL = "https://qyapi.weixin.qq.com/cgi-bin/gettoken";
    private static final String COMPANY_USER_INFO_URL = "https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo";
    private static final String COMPANY_OPENID_TO_USER_ID_URL = "https://qyapi.weixin.qq.com/cgi-bin/user/convert_to_openid";
    private static final String WXPAY_OAUTH_COOKIE_NAME = "_wxps_";    // wxpay oauth state
    private static final Pattern PATTERN_ERROR = Pattern.compile("\"?errcode\"?\\s*:\\s*\"?([-_0-9a-zA-Z]+)\"?", Pattern.MULTILINE);
    private static final Pattern PATTERN_OPENID = Pattern.compile("\"?openid\"?\\s*:\\s*\"?([-_0-9a-zA-Z]+)\"?", Pattern.MULTILINE);
    private static final Pattern PATTERN_ACCESS_TOKEN = Pattern.compile("\"?access_token\"?\\s*:\\s*\"?([-_0-9a-zA-Z]+)\"?", Pattern.MULTILINE);
    private static final Pattern PATTERN_COM_USER_ID = Pattern.compile("\"?UserId\"?\\s*:\\s*\"?([-_0-9a-zA-Z]+)\"?", Pattern.MULTILINE);
    private static final Pattern PATTERN_COM_OPENID = Pattern.compile("\"?OpenId\"?\\s*:\\s*\"?([-_0-9a-zA-Z]+)\"?", Pattern.MULTILINE);
    private static final Pattern PATTERN_DEVICE_ID = Pattern.compile("\"?DeviceId\"?\\s*:\\s*\"?([-_0-9a-zA-Z]+)\"?", Pattern.MULTILINE);

    /**
     * 重定向到微信 oauth2 静默认证地址, 用于获取 openid
     *
     * @param request  HttpRequest
     * @param response HttpResponse
     * @throws IOException
     */
    private void issueRedirectToAuthorize(HttpServletRequest request, HttpServletResponse response) throws IOException {
        final String scheme = request.getScheme();
        final String host = request.getServerName();
        final int port = request.getServerPort();

        final String url = scheme + "://" + host + (port == 80 ? "" : ":" + port);
        // FIX forward 后获取的URI不是forward前的URI
        // String requestUri = request.getRequestURI();
        String requestUri = WebUtils.getRequestUri(request);
        final String state = Identifier.get();
        if (null != request.getQueryString()) {
            requestUri += "?" + request.getQueryString();
        }
        // 认证后重新跳转到当前请求的地址
        final String redirectUri = encode(url + requestUri);
        // WARN: state 放在 scope 前面会提示错误
        final String authorizeUrl = AUTHORIZE_URL + "?appid=" + appId + "&redirect_uri=" + redirectUri
                + "&response_type=code&scope=snsapi_base&state=" + state + "#wechat_redirect";
        Cookie cookie = new SimpleCookie(WXPAY_OAUTH_COOKIE_NAME);
        cookie.setValue(state);
        cookie.saveTo(request, response);
        response.sendRedirect(authorizeUrl);
    }

    private String getOpenid(HttpServletRequest request, HttpServletResponse response) throws IOException {
        LOG.debug("get open id from parameter.");
        // http://mp.weixin.qq.com/wiki/17/c0f37d5704f0b64713d5d2c37b468d75.html#.E7.AC.AC.E4.B8.80.E6.AD.A5.EF.BC.9A.E7.94.A8.E6.88.B7.E5.90.8C.E6.84.8F.E6.8E.88.E6.9D.83.EF.BC.8C.E8.8E.B7.E5.8F.96code
        // 1. 尝试从从参数中获取
        String openid = request.getParameter("openid");
        if (null != openid) {
            return openid;
        }

        LOG.debug("get open id from request.");
        // 2. 尝试从 request 属性中获取
        openid = (String) request.getAttribute("wxpay.openid");
        if (null != openid) {
            return openid;
        }

        LOG.debug("get open id from session.");
        // 3. 尝试从 session 中获取
        openid = (String) request.getSession().getAttribute("wxpay.openid");
        if (null != openid) {
            return openid;
        }

        LOG.debug("get open id from session#oauth2.authorized.wechat.openid.");
        // 4. 尝试从 session 中获取 ponly oauth2 设置的 微信 openid
        openid = (String) request.getSession().getAttribute("oauth2.authorized.wechat.openid");
        if (null != openid) {
            return openid;
        }

        LOG.debug("get open id from oauth2.");

        // 5. 判断是否是微信 oauth2 认证回调
        final String state = request.getParameter("state");
        final String code = request.getParameter("code");
        final Cookie oauthStateCookie = new SimpleCookie(WXPAY_OAUTH_COOKIE_NAME);
        final String sessionState = oauthStateCookie.readValue(request, response);

        oauthStateCookie.removeFrom(request, response);     // 每次都清理, 不允许重用

        // 处理 oauth2 回调
        if (StringUtils.hasText(code) && (null == sessionState || sessionState.equals(state))) {
            // 公众账号获取 access_token / openid
            final String accessTokenUrl_ = ACCESS_TOKEN_URL + "?appid=" + appId + "&secret=" + appSecret + "&code=" + code + "&grant_type=authorization_code";
            final String responseBody = HttpUtils.get(accessTokenUrl_, null, "utf-8");

            LOG.debug("wxpay oauth2 reponse body: {}", responseBody);

            final Matcher matcher = getResponseMatcher(PATTERN_OPENID, responseBody);
            if (matcher.find()) {
                // 服务号响应
                openid = matcher.group(1);
            } else {
                // 可能是企业号
                final String qyAccessToken = getQyAccessToken(appId, appSecret);
                openid = getQyOpenId(qyAccessToken, code);
            }

            if (null != openid) {
                request.getSession().setAttribute("wxpay.openid", openid);
            } else {
                throw new IllegalStateException(responseBody);
            }
        }

        LOG.debug("open id is {}", openid);

        return openid;
    }

    private Matcher getResponseMatcher(final Pattern pattern, final String responseBody) {
        /*
        final Matcher errorMatcher = PATTERN_ERROR.matcher(responseBody);
        if (errorMatcher.find() && !"0".equals(errorMatcher.group(1))) {
            throw new IllegalStateException(responseBody);
        }
        */
        return pattern.matcher(responseBody);
    }


    /**
     * 获取企业号的 access_token.
     * <p/>
     * 设置 -- 功能设置 -- 权限管理 -- 任意组 看到 corp
     *
     * @param corpId     企业号corpId
     * @param corpSecret 企业号corpSecret
     * @return
     */
    private String getQyAccessToken(final String corpId, final String corpSecret) throws IOException {
        final String accessTokenUrl = QY_ACCESS_TOKEN_URL + "?corpid=" + corpId + "&corpsecret=" + corpSecret;
        final String json = HttpUtils.get(accessTokenUrl, null, "UTF-8");
        final Matcher matcher = getResponseMatcher(PATTERN_ACCESS_TOKEN, json);
        return matcher.find() ? matcher.group(1) : null;
    }

    private String getQyOpenId(final String accessToken, final String code) throws IOException {
        /*-
         * 可能是企业号
         * http://qydev.weixin.qq.com/wiki/index.php?title=OAuth%E9%AA%8C%E8%AF%81%E6%8E%A5%E5%8F%A3
         */
        if (null == accessToken) {
            return null;
        }

        // 使用企业服务号获取用户信息
        final String infoUrl = COMPANY_USER_INFO_URL + "?access_token=" + accessToken + "&code=" + code;
        final String infoJson = HttpUtils.get(infoUrl, null, "UTF-8");
        final Matcher openidMatcher = getResponseMatcher(PATTERN_COM_OPENID, infoJson);
        final Matcher userIdMatcher = getResponseMatcher(PATTERN_COM_USER_ID, infoJson);

        String openid = null;
        String responseBody = null;
        if (openidMatcher.find()) {
            /*-
             * 非企业用户响应: { "OpenId":"OPENID", "DeviceId":"DEVICEID" }
             */
            openid = openidMatcher.group(1);
        } else if (userIdMatcher.find()) {
            /*-
             * 企业员工响应:  { "UserId":"USERID", "DeviceId":"DEVICEID" }
             */
            final String url = COMPANY_OPENID_TO_USER_ID_URL + "?access_token=" + accessToken;
            final String userId = userIdMatcher.group(1);
            final byte[] data = ("{\"userid\": \"" + userId + "\"}").getBytes("UTF-8");

            // userid --> openid
            responseBody = HttpUtils.post(url, "application/json", data, 0, 0);
            // http://qydev.weixin.qq.com/wiki/index.php?title=Userid%E4%B8%8Eopenid%E4%BA%92%E6%8D%A2%E6%8E%A5%E5%8F%A3
            final Matcher xMatcher = getResponseMatcher(PATTERN_OPENID, responseBody);

            // 如果是公众账号, 可以直接获取到 openid
            if (xMatcher.find()) {
                openid = xMatcher.group(1);
            }
        } else {
            throw new IllegalStateException("Unknown response body: " + responseBody);
        }
        return openid;
    }
    

    /* ******************************************************
     *                   Helper Method
     * ******************************************************/

    /**
     * 获取给定 dom 元素 下的第一个节点
     *
     * @param element 父元素
     * @param tagName 子节点名称
     * @param <N>     节点类型
     * @return 节点, 如果不存在返回 null
     */
    @SuppressWarnings("unchecked")
    static <N extends Node> N one(Element element, String tagName) {
        NodeList list = element.getElementsByTagName(tagName);
        return (N) (1 > list.getLength() ? null : list.item(0));
    }

    /**
     * 获取给定节点的文本内容
     *
     * @param node dom 节点
     * @return 节点内容
     */
    static String text(Node node) {
        String text = null != node ? node.getTextContent() : null;
        return null != text ? text.trim() : null;
    }

    /**
     * 创建一个 16 位随机字符串
     *
     * @return 16位随机字符串
     */
    public static String createNonce() {
        return createNonce(16);
    }

    /**
     * 创建一个给定长度的随机字符串
     *
     * @param length 字符串长度
     * @return 随机字符串
     */
    public static String createNonce(int length) {
        String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        String res = "";
        for (int i = 0; i < length; i++) {
            Random rd = new Random();
            res += chars.charAt(rd.nextInt(chars.length() - 1));
        }
        return res;
    }

    /**
     * 将给定数据转换为 xml
     *
     * @param data 要转换的数据
     * @return xml 字符串
     */
    private static String toXml(Map<String, String> data) {
        StringBuilder xml = new StringBuilder();
        xml.append("<xml>\n");
        for (Map.Entry<String, String> entry : data.entrySet()) {
            String key = entry.getKey();
            xml.append("  <").append(key).append(">").append("<![CDATA[").append(entry.getValue()).append("]]>").append("</").append(key).append(">\n");
        }
        xml.append("</xml>");
        return xml.toString();
    }


    private Map<String, String> toUniqueMap(String xml) {
        Map<String, String> result = new TreeMap<String, String>();
        Element doc = JAXP.parse(xml).getDocumentElement();
        NodeList children = doc.getChildNodes();
        int len = children.getLength();
        for (int i = 0; i < len; i++) {
            Node node = children.item(i);
            if (Node.ELEMENT_NODE == node.getNodeType()) {
                Element el = (Element) node;
                String nodeName = el.getNodeName();
                String content = el.getTextContent();
                content = null != content ? content.trim() : null;
                result.put(nodeName, content);
            }
        }
        return result;
    }

    public static void main(String[] args) throws IOException {
        /*
        final String deepLink = tryGetDeepLinkFromMwebUrl(
                "https://wx.tenpay.com/cgi-bin/mmpayweb-bin/checkmweb?prepay_id=wx201707041419491a1d338cde0380155565&package=52101283",
                "http://wxpay.wxutil.com/mch/pay/h5.v2.php"
        );
        System.out.println(deepLink);
        */
        final Wxpay wxpay = new Wxpay("wx8a3ef8854a8a246b", "be7e002eda0209b00aa696a4e74ee9aa", "1367595902", "beeeup7270glanway7270beeeup7270b");
        /*
        final String appId = "wx2d1f6ee115ba1b85";
        final String appSecret = "d0d72d9047d986c86222dd60af25cfed";
        final String partnerId = "1276984801";
        final String partnerKey = "b4bacc7fb83b3f4b08ef5910b7b7feec";
        final Wxpay wxpay = new Wxpay(appId, appSecret, partnerId, partnerKey);
        */
        wxpay.setNotifyUrl("http://www.beeeup.com/wxpay");
//        String url = wxpay.getWapPayDeepLink("201705020001", 1, Dates.after(100, TimeUnit.DAYS), "支付测试", "", null);
//        String url = wxpay.getWapPayDeepLink("201705020001", 1, Dates.after(100, TimeUnit.DAYS), "支付测试", "", null);
         // String url = wxpay.getMwebUrl("201705020001", 1, Dates.after(100, TimeUnit.DAYS), "支付测试", "", null);
        String url = wxpay.getDeepLink("201705020001", 1, Dates.after(100, TimeUnit.DAYS), "支付测试", "", null, "http://www.beeeup.com/pay-gateway", "116.226.204.245");
        System.out.println(url);
    }
}
