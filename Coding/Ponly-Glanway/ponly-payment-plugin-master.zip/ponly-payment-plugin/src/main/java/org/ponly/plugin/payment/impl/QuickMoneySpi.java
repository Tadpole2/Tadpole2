package org.ponly.plugin.payment.impl;

import org.ponly.plugin.payment.Payment;
import org.ponly.plugin.payment.PaymentSpi;

import java.util.Properties;

/**
 * 快钱支付 SPI
 *
 * @author vacoor
 */
public class QuickMoneySpi extends PaymentSpi {
    public static final String ID = "quickmoney";
    public static final String MERCHANT_ACCT_ID = ID + ".merchant_acct_id";
    // 私钥从 pfx 提取
    public static final String BASE64_ENCODED_PRIVATE_KEY = ID + ".base64_encoded_private_key";
    // 公钥 从 cer 提取
    public static final String BASE64_ENCODED_PUBLIC_KEY = ID + ".base64_encoded_public_key";

    private static final OptionInfo[] OPTIONS = {
            new OptionInfo(MERCHANT_ACCT_ID, "快钱人民币网关账号", OPT_TYPE_STRING, true),
            new OptionInfo(BASE64_ENCODED_PRIVATE_KEY, "快钱私钥(Base64)", OPT_TYPE_BSTRING, true),
            new OptionInfo(BASE64_ENCODED_PUBLIC_KEY, "快钱公钥(Base64)", OPT_TYPE_BSTRING, true)
    };

    @Override
    public String getId() {
        return ID;
    }

    @Override
    public String getName() {
        return "快钱支付";
    }

    @Override
    public String getVersion() {
        return "0.1-beta";
    }

    @Override
    public Payment create(Properties props) {
        props = null != props ? props : new Properties();
        String mid = props.getProperty(MERCHANT_ACCT_ID);
        String privateKey = props.getProperty(BASE64_ENCODED_PRIVATE_KEY);
        String publicKey = props.getProperty(BASE64_ENCODED_PUBLIC_KEY);

        mid = "1002408886501";
        privateKey = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAM9BXYg5AYO2MDqjSeDO9AWWL6PDNebKwCOtztUoVhRfYagXymm+qXauS9S0u9ekPmR4YTco9py+WldeUuU+hd6i5YwCx2diTn9vgxo1rvO+8LoniJIP4BBmnEPTPCTI5u3PkuDPwI3BW0HLo1rwuXoTy1NqeKVSbeUNCuW/LPKVAgMBAAECgYEAuBMnHlj7Jl9HAJ2MfTVx+BBG6Zz0n7HN6yJwxFMZ+OgqFSBkL30eiAEP6rBG8aS3oYZlWZdxSQ+rr1NgLqlUPSobVT2BMfZZjd2nukQENMIZ4FxWpWQuu7PlBe5F9onKu13WHn9o3efKE1xHMQXVAgumPN5f4TSPYAbs8USSuHUCQQDyn3JEE4kszvkS9QcjnBjx5W3ALFTk2l0W8g2aWAoWytN3OI51YS9Wc48jDhsEFzpIehcBLId+0t5eBp53embDAkEA2q63cHwlfs2n9SqTowqoWnrPZm2Jr9gfm26eTUf0gPW5c9s7mo6HOYKYAkeeGcaVGMeeBR08EgMS3XTTKwWbxwJAbdF+BxJQpNeKJeqCsLuXDuaqJrHqOywbtqcZQSNYbbigvvX6hWbX5mmoAFYCJHffCa85em6NZfpMbILSd4IPwQJAatmvvACM+ZZXGM3C8YlFlWAocq3W9tqtJu833h7ocxKdmORoDS7TF+CdkY+YypNjSoZOycTtEwf5ccehXoYRBQJBAJMOEP8XhwwF4bfsRvuRYzETpniHnYKOzjzSIA6fgD3RHYHTZUVHaTQn6fz6zhu1W6uRePnBbrO0XuuvHm4OSZs=";
        publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA30S5TQieACF5PpnlVnlCN4CDp7cuB29aN7b6Ekv6Uu9+ixm9ydnAJ6LeouKKO/fhuPbP24WVO1yEQvsxw3UFxG0Zv7+kJqANMgq4sJAIhw8nNcOFQFk0Z7R4ROzrMZKv88AQ3X5IGbHZXodzY2S5kj4rJ3LxIa0Vq7vA2uu4nOiojh1epru3Dw3ooOp0FLax0EwcltBhEGOeDmS+BQXI5wsHYaWEFSEcq8OoqByC52RXx+emiK3aZdFCwbBssgH/klXjS/SOmBTaOd9sJRcjVTlGKV0k/ZR88edcSQYKqEpYDTSO/LPHKa4r9bDB6N6Y53xRTAHQFfh0gWRlDSBkqQIDAQAB";

        return new QuickMoney(mid, privateKey, publicKey);
    }

    @Override
    public OptionInfo[] getOptionInfo() {
        return OPTIONS;
    }

}
