package org.ponly.plugin.payment.impl;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.*;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.ponly.common.codec.Base64;
import org.ponly.common.util.StringUtils;
import org.ponly.plugin.payment.Payment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import static org.ponly.plugin.payment.impl.Utils.*;

/**
 * 快钱支付
 * 基于《快钱人民币网关支付接口文档_V3.0.3》,《快钱移动网关支付接口文档_V3.0.3》
 * 注: 人民币网关/银行直连两者是一个,只是后者需要专门在开通
 * 移动支付网关和这个基本一致, 除了需要额外开通外, 不同如下
 * 1. 网关 https://www.99bill.com/mobilegateway/recvMerchantInfoAction.htm (gateway -- mobilegateway)
 * 2. 参数 version 2.0 -- mobile1.0, 增加 mobileGateway: phone/pad
 * 3. 签名参数插入 mobileGateway
 * 4. payType 和 bankId 取值不同
 * <p/>
 * http://open.99bill.com/menu!access.do
 *
 * @author vacoor
 */
public class QuickMoney implements Payment {
    private static final Logger LOG = LoggerFactory.getLogger(QuickMoney.class);

    public static final String QUICK_GATEWAY = "https://www.99bill.com/gateway/recvMerchantInfoAction.htm";
    public static final String QUICK_SANDBOX_GATEWAY = "https://sandbox.99bill.com/gateway/recvMerchantInfoAction.htm";
    public static final String QUICK_SANDBOX_MOBILE_GATEWAY = "https://sandbox.99bill.com/mobilegateway/recvMerchantInfoAction.htm";
    // public static final String QUICK_GATEWAY = QUICK_SANDBOX_MOBILE_GATEWAY;
    /**
     * 这个不能使用始终java.lang.NumberFormatException
     * com.bill99.seashell.appcontroller.website.filter.MobileSessionFilter.doFilter(MobileSessionFilter.java:81)
     */
    // public static final String QUICK_MOBILE_SHORT_URL = "https://www.99bill.com/mobilegateway/recvMerchantBackendPostOrderAction.htm";
    public static final String QUICK_MOBILE_SHORT_URL = "https://www.99bill.com/mobilegateway/recvMerchantInfoAction.htm";

//     public static final String QUICK_GATEWAY = "https://sandbox.99bill.com/gateway/recvMerchantInfoAction.htm";

    private static final String DEFAULT_MID = "1001213884201";      // sandbox
    private static final String DEFAULT_KEY_STORE_PFX = "/99bill/99bill-rsa.pfx";
    private static final String DEFAULT_KEY_STORE_TYPE = KS_TYPE_PKCS12;
    private static final String DEFAULT_KEY_STORE_PASS = "123456"; //"jzsp0001";
    private static final String DEFAULT_PRIVATE_KEY_ALIAS = "test-alias";
    private static final String DEFAULT_PRIVATE_KEY_PASS = DEFAULT_KEY_STORE_PASS;
    private static final String DEFAULT_CER = "/99bill/99bill.cert.rsa.cer";

    private static final PrivateKey DEFAULT_PRIVATE_KEY;
    private static final X509Certificate DEFAULT_CERTIFICATE;

    // 参数
    public static final String INPUT_CHARSET = "1";    // 编码方式: 1代表 UTF-8, 2 代表 GBK, 3代表 GB2312 默认为1, 该参数必填。
    public static final String VERSION_PC_V2 = "v2.0"; // 网关版本，固定值：v2.0,该参数必填。
    public static final String VERSION_WAP_V1 = "mobile1.0";

    public static final String LANGUAGE = "1";    //语言: 1=中文,2=英文
    // 签名类型,该值为4，代表PKI加密方式,该参数必填。
    public static String SIGN_TYPE = "4";
    // 支付方式，一般为00，代表所有的支付方式。如果是银行直连商户，该值为10，必填。
    public static String PAY_TYPE = "00";
    // 银行代码，如果payType为00，该值可以为空；如果payType为10，该值必须填写，具体请参考银行列表。
    public static String BANK_ID = "";
    // 同一订单禁止重复提交标志，实物购物车填1，虚拟产品用0。1代表只能提交一次，0代表在支付不成功情况下可以再提交。可为空。
    public static String REDO_FLAG = "";

    // 订单提交时间，格式：yyyyMMddHHmmss，如：20071117020101，不能为空。
    // public static String orderTime = new java.text.SimpleDateFormat("yyyyMMddHHmmss").format(new java.util.Date());

    // 协议参数
    public static final String CHARSET_PARAM = "inputCharset";  // 字符编码, 1: utf-8, 2: gbk, 3: gb2312
    public static final String PAGE_URL_PARAM = "pageUrl";      // 接收支付结果的页面, 一般为直接跳转不处理业务, 优先 bgUrl, 可空
    public static final String BG_URL_PARAM = "bgUrl";          // 服务器接收支付结果的页面, 可空
    public static final String VERSION_PARAM = "version";       // 网关版本, 固定 v2.0, 必填
    public static final String LANGUAGE_PARAM = "language";     // 语言类型, 固定 1: 中文, 必填
    public static final String SIGN_TYPE_PARAM = "signType";    // 签名方式, 4: RSA/DSA, 必填

    // 业务参数
    public static final String MERCHANT_ACCT_ID_PARAM = "merchantAcctId";       // 人民币账号, 不可空
    public static final String PAYER_NAME_PARAM = "payerName";                  // 支付人姓名, 可空
    public static final String PAYER_CONTACT_TYPE_PARAM = "payerContactType";   // 支付人联系方式类型: 1: 电子邮件 2: 手机, 可空
    public static final String PAYER_CONTACT_PARAM = "payerContact";            // 支付人联系方式, 可空
    private static final String PAYER_ID_TYPE_PARAM = "payerIdType";
    private static final String PAYER_ID_PARAM = "payerId";
    private static final String PAYER_IP_PARAM = "payerIP";

    public static final String ORDER_ID_PARAM = "orderId";                      // 订单号, 必填
    public static final String ORDER_AMOUNT_PARAM = "orderAmount";              // 订单金额, 分为单位, 必填
    public static final String ORDER_TIME_PARAM = "orderTime";                  // 订单提交时间, yyyyMMddHHmmss 必填
    private static final String ORDER_TIMESTAMP_PARAM = "orderTimestamp";

    private static final String CARD_ISSUER_PARAM = "cardIssuer";
    private static final String CARD_NUM_PARAM = "cardNum";
    private static final String REMIT_TYPE_PARAM = "remitType";
    private static final String REMIT_CODE_PARAM = "remitCode";

    public static final String PRODUCT_NAME_PARAM = "productName";              // 商品名称, 可空
    public static final String PRODUCT_NUM_PARAM = "productNum";                // 商品数量, 可空
    public static final String PRODUCT_ID_PARAM = "productId";                  // 商品标识, 可空
    public static final String PRODUCT_DESC_PARAM = "productDesc";              // 商品描述, 可空
    public static final String EXT1_PARAM = "ext1";                             // 扩展字段, 原样返回, 可空
    public static final String EXT2_PARAM = "ext2";                             // 扩展字段, 原样返回, 可空

    private static final String SUBMIT_TYPE_PARAM = "submitType";
    private static final String ORDER_TIMEOUT_PARAM = "orderTimeOut";
    private static final String EXT_DATA_TYPE_PARAM = "extDataType";
    private static final String EXT_DATA_CONTENT_PARAM = "extDataContent";
    /**
     * 支付方式, 必填
     * 00: 显示快钱各支付方式列表
     * 10: 只显示银行卡支付方式
     * 10-1: 储蓄卡网银支付
     * 10-2: 信用卡网银支付
     * 11: 电话银行支付
     * 11-1: 储蓄卡电话支付
     * 11-2: 信用卡电话支付
     * 12: 只显示快钱账户支付方式
     * 13: 只显示线下支付方式
     * 14: 显示企业网银支付
     * 15: 信用卡无卡支付
     * 17: 预付卡支付
     * 19: 手机语言支付
     * 21: 快捷支付
     */
    public static final String PAY_TYPE_PARAM = "payType";
    public static final String BANK_ID_PARAM = "bankId";        // 银行代码, 可空
    public static final String REDO_FLAG_PARAM = "redoFlag";    // 同一订单禁止重复提交, 1: 只允许提交1次, 0: 不限制, 建议实体使用0, 虚拟产品使用1, 可空
    public static final String PID_PARAM = "pid";               // 快钱用户编号, 可空

    private static final String[] PARAMS_SIGN_SEQ = {
            CHARSET_PARAM, PAGE_URL_PARAM, BG_URL_PARAM, VERSION_PARAM, LANGUAGE_PARAM, SIGN_TYPE_PARAM,
            MERCHANT_ACCT_ID_PARAM, PAYER_NAME_PARAM, PAYER_CONTACT_TYPE_PARAM, PAYER_CONTACT_PARAM,
            PAYER_ID_TYPE_PARAM, PAYER_ID_PARAM, PAYER_IP_PARAM,
            ORDER_ID_PARAM, ORDER_AMOUNT_PARAM, ORDER_TIME_PARAM,
            ORDER_TIMESTAMP_PARAM,
            PRODUCT_NAME_PARAM, PRODUCT_NUM_PARAM, PRODUCT_ID_PARAM, PRODUCT_DESC_PARAM,
            EXT1_PARAM, EXT2_PARAM, PAY_TYPE_PARAM, BANK_ID_PARAM,
            CARD_ISSUER_PARAM, CARD_NUM_PARAM, REMIT_TYPE_PARAM, REMIT_CODE_PARAM,
            REDO_FLAG_PARAM, PID_PARAM,
            SUBMIT_TYPE_PARAM, ORDER_TIMEOUT_PARAM, "mobileGateway", EXT_DATA_TYPE_PARAM, EXT_DATA_CONTENT_PARAM
    };

    private static final String[] PARAMS_VERIFY_SEQ = {
            MERCHANT_ACCT_ID_PARAM, VERSION_PARAM,
            LANGUAGE_PARAM, SIGN_TYPE_PARAM,
            PAY_TYPE_PARAM, BANK_ID_PARAM,
            ORDER_ID_PARAM, ORDER_TIME_PARAM,
            ORDER_AMOUNT_PARAM,
                /* S mobile*/
            "bindCard", "bindMobile",
                 /* E mobile */
            "dealId",
            "bankDealId", "dealTime",
            "payAmount", "fee",
            EXT1_PARAM, EXT2_PARAM,
            "payResult", "errCode"
    };


    /* ***************************************************
     *
     * ************************************************* */

    public static final String ENV_SANDBOX = "sandbox";
    public static final String ENV_PRODUCTION = "production";

    private String env = ENV_SANDBOX;
    // 人民币网关账号，该账号为11位人民币网关商户编号+01,该参数必填。
    private final String merchantAcctId;
    private final String base64EncodedPrivateKey;         // base64 编码的私钥
    private final String base64EncodedX509PublicKey;      // base64 编码的x509公钥

    private final String keyStorePath;
    private final String keyStorePass;
    private final String privateKeyAlias;
    private final String privateKeyPass;
    private final String certPath;

    private String bgUrl = "";
    private String pageUrl = "";

    /**
     * 初始化一个默认的快钱支付
     * <p/>
     * keystore: classpath:99bill/env/99bill-rsa.pfx <br/>
     * cert: classpath:99bill/env/99bill.cert.rsa.cer
     * </p>
     *
     * @param env            环境名称 sandbox/production
     * @param merchantAcctId 商户ID
     * @since 0.1
     */
    public QuickMoney(String env, String merchantAcctId) {
        this(env, merchantAcctId,
                "/99bill/" + env + "/99bill-rsa.pfx", DEFAULT_KEY_STORE_PASS,
                DEFAULT_PRIVATE_KEY_ALIAS, DEFAULT_PRIVATE_KEY_PASS,
                "/99bill/" + env + "/99bill.cert.rsa.cer"
        );
    }

    /**
     * 使用给定配置构建一个沙箱环境的支付.
     *
     * @param merchantAcctId  商户ID
     * @param keyStorePath    KeyStore(jks/pfx) 路径
     * @param keyStorePass    KeyStore 密码
     * @param privateKeyAlias 私钥别名
     * @param privateKeyPass  私钥密码
     * @param certPath        证书路径
     * @since 0.1
     */
    public QuickMoney(String merchantAcctId,
                      String keyStorePath, String keyStorePass,
                      String privateKeyAlias, String privateKeyPass,
                      String certPath) {
        this(ENV_SANDBOX, merchantAcctId, keyStorePath, keyStorePass, privateKeyAlias, privateKeyPass, certPath);
    }

    /**
     * 使用给定配置构建支付.
     *
     * @param env             环境名称 sandbox / production
     * @param merchantAcctId  商户ID
     * @param keyStorePath    KeyStore(jks/pfx) 路径
     * @param keyStorePass    KeyStore 密码
     * @param privateKeyAlias 私钥别名
     * @param privateKeyPass  私钥密码
     * @param certPath        证书路径
     * @since 0.1
     */
    public QuickMoney(String env, String merchantAcctId,
                      String keyStorePath, String keyStorePass,
                      String privateKeyAlias, String privateKeyPass,
                      String certPath) {
        this.env = env;
        this.merchantAcctId = merchantAcctId;
        this.keyStorePath = keyStorePath;
        this.keyStorePass = keyStorePass;
        this.privateKeyAlias = privateKeyAlias;
        this.privateKeyPass = privateKeyPass;
        this.certPath = certPath;

        this.base64EncodedPrivateKey = null;
        this.base64EncodedX509PublicKey = null;
    }

    public QuickMoney(String merchantAcctId, String base64EncodedPrivateKey, String base64EncodedX509PublicKey) {
        this(ENV_SANDBOX, merchantAcctId, base64EncodedPrivateKey, base64EncodedX509PublicKey);
    }

    public QuickMoney(String env, String merchantAcctId, String base64EncodedPrivateKey, String base64EncodedX509PublicKey) {
        this.env = env;
        this.merchantAcctId = merchantAcctId;
        this.base64EncodedPrivateKey = base64EncodedPrivateKey;
        this.base64EncodedX509PublicKey = base64EncodedX509PublicKey;

        this.keyStorePath = null;
        this.keyStorePass = null;
        this.privateKeyAlias = null;
        this.privateKeyPass = null;
        this.certPath = null;
    }


    @Override
    public void setNotifyUrl(String url) {
        this.bgUrl = url;
    }

    @Override
    public void setReturnUrl(String url) {
        this.pageUrl = url;
    }

    @Override
    public void postTransaction(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee, Date expire, String subject, String body) throws IOException {
        postTransaction(request, response, tradeNo, fee, expire, subject, body, null);
    }

    @Override
    public void postTransaction(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee, Date expire, String subject, String body, Map<String, String> udfParams) throws IOException {
        String gatewayUrl = getGatewayUrl();
        Map<String, String> params = getParams(tradeNo, fee, expire, subject, body, udfParams);
        if (isMobileRequest(request)) {
            gatewayUrl = getMobileGatewayUrl();
            params.put(VERSION_PARAM, VERSION_WAP_V1);
            params.put("mobileGateway", "phone");
        }
        params.put("signMsg", sign(params));

        String html = buildRequestHtml(gatewayUrl, "POST", params);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().print(html);
    }

    @Override
    public String getQRCodeUrl(String tradeNo, int fee, Date expire, String subject, String body, int width) throws IOException {
        return null;
    }

    private Map<String, String> getParams(String orderNo, int fee, Date expire, String subject, String body, Map<String, String> udfParams) {
        Map<String, String> params = new HashMap<String, String>();

        //固定协议参数
        params.put(CHARSET_PARAM, INPUT_CHARSET);
        params.put(PAGE_URL_PARAM, pageUrl);
        params.put(BG_URL_PARAM, bgUrl);

        params.put(VERSION_PARAM, VERSION_PC_V2);
//        params.put(VERSION_PARAM, VERSION_WAP_V1);
//        params.put("mobileGateway", "phone");   // phone/pad, 但是测试了下, 没区别
        params.put(LANGUAGE_PARAM, LANGUAGE);
        params.put(SIGN_TYPE_PARAM, SIGN_TYPE); // 4:DSA, 3:RSA

        // 买卖双方信息参数
        String mid = StringUtils.hasText(merchantAcctId) ? merchantAcctId : DEFAULT_MID;
        params.put(MERCHANT_ACCT_ID_PARAM, mid);
        params.put(PAYER_NAME_PARAM, "");
        params.put(PAYER_CONTACT_TYPE_PARAM, "");
        params.put(PAYER_CONTACT_PARAM, "");
        params.put(PAYER_ID_TYPE_PARAM, "");
        params.put(PAYER_ID_PARAM, "");
        params.put(PAYER_IP_PARAM, "");

        // 业务参数
        params.put(ORDER_ID_PARAM, orderNo);
        params.put(ORDER_AMOUNT_PARAM, Integer.toString(fee));
        params.put(ORDER_TIME_PARAM, getNowTime());
        params.put(ORDER_TIMESTAMP_PARAM, "");   // 高钓鱼风险商户必填
        params.put(PRODUCT_NAME_PARAM, subject);
        params.put(PRODUCT_NUM_PARAM, "");
        params.put(PRODUCT_ID_PARAM, "");
        params.put(PRODUCT_DESC_PARAM, body);
        params.put(EXT1_PARAM, "");             // 原样返回
        params.put(EXT2_PARAM, "");
        params.put(PAY_TYPE_PARAM, PAY_TYPE);   // 原样返回
        /*-
          银行代码
          仅在银行直连/快捷支付挃定银行定制时使用
          银行直连:payType=10,10-1,10-2,14
          快捷支付指定银行定制:payType=21-1,21-2
          无卡支持指定银行定制:payType=15
         */
        String bankId = "ICBC";
        bankId = "";
        if (null != bankId && !"".equals(bankId)) {
            params.put(PAY_TYPE_PARAM, "10");
        }
        params.put(BANK_ID_PARAM, bankId);          //
        params.put(CARD_ISSUER_PARAM, "");          // 发卡机构
        params.put(CARD_NUM_PARAM, "");
        params.put(REMIT_TYPE_PARAM, "");
        params.put(REMIT_CODE_PARAM, "");
        /*-
          同一订单禁止重复提交标志
          1 代表同一订单号只允许提交 1 次;
          0 表示同一订单 号在没有支付成功的前提下可重复提交多次。
          默讣为 0
          建议实物购物车结算类商户采用 0;虚拟产品类商户 采用 1;
         */
        params.put(REDO_FLAG_PARAM, "");        //
        params.put(PID_PARAM, "");
        /*-
           提交方式
           00:代表前台提交 01:代表后台提交 为空默讣为前台提交。
         */
        params.put(SUBMIT_TYPE_PARAM, "");
        if (null != expire) {
            long now = new Date().getTime() / 1000;
            long timeout = (expire.getTime() / 1000 - now);
            timeout = Math.min(Math.max(0, timeout), 2592000);  // 最大30天
            params.put(ORDER_TIMEOUT_PARAM, timeout + ""); // 订单超时时间, 单位s, 超时自动退款
        }
        params.put(EXT_DATA_TYPE_PARAM, "");
        params.put(EXT_DATA_CONTENT_PARAM, "");

        if (null != udfParams) {
            params.putAll(udfParams);
        }

        return params;
    }

    /**
     * 注意加签验签说明, 顺序是固定的
     *
     * @param params
     * @return
     */
    protected String sign(Map<String, String> params) {
        // 签名时必须保证顺序
        String text = toNVString(params, PARAMS_SIGN_SEQ);
        return sign(text);
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean verifyTransaction(HttpServletRequest request, TransactionCallback callback) {
        Map<String, String> uniqueMap = new HashMap<String, String>();
        Map<String, String[]> parameterMap = request.getParameterMap();
        for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
            String key = entry.getKey();
            String[] values = entry.getValue();
            for (String value : values) {
                uniqueMap.put(key, value);
            }
        }

        //处理结果， 10支付成功，11 支付失败，00订单申请成功，01 订单申请失败
        String payResult = uniqueMap.get("payResult");

        boolean executed = false;
        if ("10".equals(payResult) && verifyTransaction(uniqueMap)) {
            String order = uniqueMap.get(ORDER_ID_PARAM);           // 订单号
            String orderTime1 = uniqueMap.get("orderTime");         // 订单提交时间
            String orderAmount = uniqueMap.get("orderAmount");      // 订单提交金额
            String payAmountStr = uniqueMap.get("payAmount");       // 支付金额
            String fee = uniqueMap.get("fee");                      // 快钱收取的手续费
            String transaction = uniqueMap.get("dealId");           // 快钱交易号
            String dealId = uniqueMap.get("dealId");                // 快钱交易号
            String bankDealId = uniqueMap.get("bankDealId");        // 银行交易号
            String bankId = uniqueMap.get("bankId");                // 银行ID
            String dealTimeStr = uniqueMap.get("dealTime");         // 交易支付时间 yyyyMMddHHmmss
            Date paidTime = parseDate(dealTimeStr, "yyyyMMddHHmmss");
            int amount = Integer.parseInt(payAmountStr);

            callback.onFinished(order, amount, paidTime, transaction, uniqueMap);
            executed = true;
        }
        if (!executed) {
            callback.onError(null, null, null, uniqueMap);
        }
        return executed;
    }

    @Override
    public boolean verifyTransaction(HttpServletRequest request, HttpServletResponse response, TransactionCallback callback) throws IOException {
        PrintWriter writer = response.getWriter();
        boolean executed = false;
        if (verifyTransaction(request, callback)) {
            // 1 表示处理成功
            response.getWriter().print("<result>1<result><redirecturl>" + pageUrl + "</redirecturl>");
            executed = true;
        } else {
            writer.print("<result>-1<result><redirecturl></redirecturl>");
        }
        writer.flush();

        return executed;
    }


    /**
     * 当支付成功后应该返回"<result>1</result><redirecturl>xxxx</redirecturl>"
     * 当 result 不是1 时会在18小时内不断调用
     */
    public boolean verifyTransaction(Map<String, String> callbackParams) {
        String signMsg = callbackParams.get("signMsg");
        // 必须保证顺序
        String text = toNVString(callbackParams, PARAMS_VERIFY_SEQ);
        return verifyTransaction(text, signMsg);
    }

    /**
     * 消息签名
     *
     * @return base64 编码签名
     */
    public String sign(String message) {
        String sign = null;
        try {
            final PrivateKey privateKey = getPrivateKey();
            sign = signAsBase64(BC_PROV_ALGORITHM_SHA1RSA, privateKey, message.getBytes("UTF-8"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return sign;
    }


    /**
     * 消息签名验证
     *
     * @param text 消息
     * @param sign base64 编码签名
     */
    public boolean verifyTransaction(String text, String sign) {
        boolean valid = false;
        try {
            PublicKey publicKey = getPublicKey();
            // 实际是 SHA1withRSA
            Signature signature = Signature.getInstance("SHA1withRSA");
            signature.initVerify(publicKey);
            signature.update(text.getBytes("utf-8"));
            valid = signature.verify(Base64.decode(sign));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return valid;
    }

    /**
     * @return 网关地址
     */
    public String getGatewayUrl() {
        return ENV_SANDBOX.equals(this.env) ? QUICK_SANDBOX_GATEWAY : QUICK_GATEWAY;
    }

    /**
     * @return 手机网关地址
     */
    public String getMobileGatewayUrl() {
        return ENV_SANDBOX.equals(this.env) ? QUICK_SANDBOX_MOBILE_GATEWAY : QUICK_MOBILE_SHORT_URL;//getGatewayUrl();
    }

    protected PublicKey getPublicKey() throws InvalidKeySpecException, NoSuchAlgorithmException {
        PublicKey publicKey = null;
        X509Certificate cert;
        if (StringUtils.hasText(base64EncodedX509PublicKey)) {
            publicKey = toPublicKey(base64EncodedX509PublicKey);
        } else if (null != (cert = doGetCertificateFromResource())) {
            publicKey = cert.getPublicKey();
        } else if (null != DEFAULT_CERTIFICATE) {
            publicKey = DEFAULT_CERTIFICATE.getPublicKey();
        }
        return publicKey;
    }

    protected PrivateKey getPrivateKey() throws InvalidKeySpecException, NoSuchAlgorithmException {
        PrivateKey privateKey = null;
        if (StringUtils.hasText(base64EncodedPrivateKey)) {
            privateKey = toPrivateKey(base64EncodedPrivateKey);
        }
        if (null == privateKey) {
            privateKey = doGetPrivateKeyFromResource();
        }
        if (null == privateKey) {
            privateKey = DEFAULT_PRIVATE_KEY;
        }
        return privateKey;
    }

    /**
     * @return 从资源文件中获取的私钥
     */
    protected PrivateKey doGetPrivateKeyFromResource() {
        KeyStore ks = loadKeyStore(getClass(), keyStorePath, DEFAULT_KEY_STORE_TYPE, keyStorePass);
        return getKey(ks, privateKeyAlias, privateKeyPass);
    }

    /**
     * @return 从证书文件中加载证书.
     */
    protected X509Certificate doGetCertificateFromResource() {
        return getX509Certificate(getClass(), certPath);
    }

    /**
     * 获取当前时间，格式：yyyyMMddHHmmss，如：20071117020101，不能为空。
     *
     * @return yyyyMMddHHmmss
     */
    private String getNowTime() {
        return new java.text.SimpleDateFormat("yyyyMMddHHmmss").format(new java.util.Date());
    }

    static {
        // Security.addProvider(new BouncyCastleProvider());
        X509Certificate cert = null;
        PrivateKey privateKey = null;

        try {
            cert = getX509Certificate(QuickMoney.class, DEFAULT_CER);
        } catch (Exception ex) {
            LOG.debug("load default certificate failed", ex);
        }
        try {
            KeyStore ks = loadKeyStore(QuickMoney.class, DEFAULT_KEY_STORE_PFX, DEFAULT_KEY_STORE_TYPE, DEFAULT_KEY_STORE_PASS);
            privateKey = getKey(ks, DEFAULT_PRIVATE_KEY_ALIAS, DEFAULT_PRIVATE_KEY_PASS);
            if (null == cert) {
                LOG.debug("load default certificate from default keystore");
                cert = getFirstCertificate(ks);
            }
        } catch (Exception ex) {
            LOG.debug("load default keystore failed", ex);
        }

        DEFAULT_CERTIFICATE = cert;
        DEFAULT_PRIVATE_KEY = privateKey;
    }
}
