package org.ponly.plugin.payment.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.ponly.common.crypto.digest.Hash;

/**
 * Created by Vacoor on 2017-03-25.
 */
public class AllinPay {
    // B2B/B2C gateway.
    public static final String GATEWAY_B2X_SANDBOX = "http://ceshi.allinpay.com/gateway/index.do";
    public static final String GATEWAY_B2X = "https://cashier.allinpay.com/gateway/index.do";

    // PC 快捷.
    public static final String GATEWAY_QUICK = "https://cashier.allinpay.com/gateway/index.do";

    // WAP.
    public static final String GATEWAY_WAP_SANDBOX = "http://ceshi.allinpay.com/mobilepayment/mobile/SaveMchtOrderServlet.action";
    public static final String GATEWAY_WAP = "https://cashier.allinpay.com/mobilepayment/mobile/SaveMchtOrderServlet.action";

    public static final String GATEWAY_H5 = GATEWAY_WAP;

    private String merchantId = "100020091218001";
    private String key = "1234567890";

    public Map<String, String> getPayParams(String tradeNo, int fee, Date expire, String subject, String body, Map<String, String> udfParams) {
        final Map<String, String> params = new HashMap<String, String>();

        params.put("inputCharset", "1");    // 1=UTF-8, 2=GBK, 3=GB2312
        params.put("pickupUrl", "http://www.display.com/display/1");        //
        params.put("receiveUrl", "http://ponly.org/notify");       // 支付结果URL.
        params.put("version", "v1.0");      //
        params.put("language", "1");         // 1=简体中文, 2=繁体中文, 3=英文
        params.put("signType", "0");        // 0=订单上送和交易结果都使用MD5进行签名, 1=订单上送使用MD5, 结果通知使用证书签名

        params.put("merchantId", merchantId);
        params.put("payerName", "");
        params.put("payerEmail", "");
        params.put("payerTelephone", "");
        params.put("payerIDCard", "");
        params.put("pid", "");

        params.put("orderNo", tradeNo);
        params.put("orderAmount", String.valueOf(fee));
        params.put("orderCurrency", "0");
        params.put("orderDatetime", Utils.getCurrentDate());
        params.put("orderExpireDatetime", "");

        params.put("productName", "111");
        params.put("productPrice", "");
        params.put("productNum", "");
        params.put("productId", "p_id");
        params.put("productDesc", "p_desc");
        params.put("ext1", "");
        params.put("ext2", "");
        params.put("extTL", "");

        params.put("payType", "1");
        params.put("issuerId", "");
        params.put("pan", "");
        params.put("tradeNature", "");

        if (null != udfParams) {
            params.putAll(udfParams);
        }

        final String src = Utils.toNVString(
                params,
                "inputCharset",
                "pickupUrl",
                "receiveUrl",
                "version",
                "language",
                "signType",
                "merchantId",
                "payerName",
                "payerEmail",
                "payerTelephone",
                "payerIDCard",
                "pid",
                "orderNo",
                "orderAmount",
                "orderCurrency",
                "orderDatetime",
                "orderExpireDatetime",
                "productName",
                "productPrice",
                "productNum",
                "productId",
                "productDesc",
                "ext1",
                "ext2",
                "extTL",
                "payType",
                "issuerId",
                "pan",
                "tradeNature"/*,

                "signMsg",
                "customsExt"
                */
        );
        final String sign = new Hash.MD5(src + "&key=" + key).toHex().toUpperCase();

        params.put("signMsg", sign);
//        params.put("customsExt", "");

        return params;
    }

    public static void main(String[] args) {
        AllinPay allinPay = new AllinPay();
        Map<String, String> payParams = allinPay.getPayParams("2017010101001", 1, null, null, null, null);
        String html = Utils.buildRequestHtml(GATEWAY_B2X_SANDBOX, "POST", payParams);
        System.out.println(html);
    }
}
