package org.ponly.plugin.payment.impl;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.ponly.common.util.StringUtils;
import org.ponly.plugin.payment.Payment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import static org.ponly.plugin.payment.impl.Utils.buildRequestHtml;
import static org.ponly.plugin.payment.impl.Utils.parseDate;

/**
 * 民生E支付(http://epay.cmbc.com.cn/portal/).
 */
public class CmbcEpay implements Payment {

    private static final Logger LOG = LoggerFactory.getLogger(CmbcEpay.class);

    //网关地址
    public static final String EPAY_GATEWAY = "https://epay.cmbc.com.cn/ipad/service.html";

    //partner_id
    private static final String DEFAULT_PARTNER_ID = "1002201701164507";
    //正式账户商户名称
    private static final String DEFAULT_BUSINESS_NAME = "蜂起（北京）智能科技有限公司";
    //seller_email
    private static final String DEFAULT_SELLER_EMAIL = "beeeup123";
    //正式商户签名证书
    private static final String DEFAULT_SM2_SIGN_CER_PATH = "epay_cert/testMer.sm2";
    //正式商户证书密码
    private static final String DEFAULT_SM2_PASSWORD = "fengqi@beeeup";
    //e支付平台DN名（用于验签）
    private static final String DEFAULT_DN_NAME = "C=CN,O=CFCA OCA1,OU=CMBC,OU=Organizational-1,CN=0305@710001898-8@EPAY@4";


    private static final String service = "create_direct_pay_by_user";
    private final String input_charset = "utf-8";
    private static final String sign_type = "SM2";
    private static final String payMethod = "bankPay";
    private final String partnerId;
    private final String partnerName;
    private final String sm2Pwd;
    private final String seller_email;
    private static final String default_bank = "";


    //接口名称   not null
    private static final String SERVICE = "service";
    //合作商ID    not null
    private static final String PARTNER_ID = "partner_id";
    //编码方式   not null
    private static final String INPUT_CHARSET = "input_charset";
    //签名类型   not null
    private static final String SIGN_TYPE = "sign_type";
    //通知地址   not null
    private static final String NOTIFY_URL = "notify_url";
    //外部订单号   not null
    private static final String OUT_TRADE_NO = "out_trade_no";
    //交易标题（商品名称）   not null
    private static final String SUBJECT = "subject";
    //卖家账号  可空
    private static final String BUYER_EMAIL = "buyer_email";
    //卖家账号 not null
    private static final String SELLER_EMAIL = "seller_email";
    //交易金额（单位元精确到0.01） not null
    private static final String AMOUNT = "amount";
    //交易详细内容 not null
    private static final String BODY = "body";
    //商品展示网址
    private static final String SHOW_URL = "show_url";
    //支付方式， bankPay为网银支付
    private static final String PAYMETHOD = "payMethod";
    //默认银行
    private static final String DEFAULT_BANK = "default_bank";
    //分润账号
    private static final String ROYALTY_PARAMETERS = "royalty_parameters";
    //回调地址 not null
    private static final String RETURN_URL = "return_url";
    //签名  not null
    private static final String SIGN = "sign";


    private String notify_url = "";
    private String return_url = "";


    public CmbcEpay(String partnerId, String sm2Passwd, String partnerName, String sellerEmail) {
        this.partnerId = partnerId;
        this.partnerName = partnerName;
        this.sm2Pwd = sm2Passwd;
        this.seller_email = sellerEmail;
    }

    @Override
    public void setNotifyUrl(String url) {
        this.notify_url = url;

    }

    @Override
    public void setReturnUrl(String url) {
        this.return_url = url;

    }

    @Override
    public void postTransaction(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee,
                                Date expire, String subject, String body) throws IOException {
        String gatewayUrl = EPAY_GATEWAY;
        Map<String, String> params = getParams(tradeNo, fee, expire, subject, body);

        String html = buildRequestHtml(gatewayUrl, "POST", params);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().print(html);
        LOG.info(html);
    }

    @Override
    public void postTransaction(HttpServletRequest request, HttpServletResponse response, String arg2, int arg3, Date arg4,
                                String arg5, String arg6, Map<String, String> udfParams) throws IOException {
        // TODO Auto-generated method stub

    }

    private Map<String, String> getParams(String orderNo, int fee, Date expire, String subject, String body) {

        if (!StringUtils.hasText(body)) {
            body = "交易详情";
        }

        if (!StringUtils.hasText(subject)) {
            subject = "蜂起支付";
        }

        String yuan = Utils.toYuan(fee);

        Map<String, String> params = new LinkedHashMap<>();
        params.put(SERVICE, service);
        params.put(PARTNER_ID, partnerId);
        params.put(INPUT_CHARSET, input_charset);
        params.put(SIGN_TYPE, sign_type);
        params.put(NOTIFY_URL, notify_url);
        params.put(OUT_TRADE_NO, orderNo);
        params.put(SUBJECT, subject);
        params.put(BUYER_EMAIL, "");
        params.put(SELLER_EMAIL, seller_email);
        params.put(AMOUNT, yuan);
        params.put(BODY, body);
        params.put(SHOW_URL, "");
        params.put(PAYMETHOD, payMethod);
        params.put(DEFAULT_BANK, default_bank);
        params.put(ROYALTY_PARAMETERS, "");
        params.put(RETURN_URL, return_url);
        //FIXME params.put(SIGN, SM2SignHelper.sign(params, DEFAULT_SM2_SIGN_CER_PATH, StringUtils.hasText(sm2Pwd) ? sm2Pwd : DEFAULT_SM2_PASSWORD));
        return params;
    }

    @Override
    public String getQRCodeUrl(String tradeNo, int fee, Date expire, String subject, String body, int width)
            throws IOException {
        return null;
    }

    @Override
    public boolean verifyTransaction(HttpServletRequest request, TransactionCallback callback) {
        Map<String, String> uniqueMap = new HashMap<String, String>();
        Map<String, String[]> parameterMap = request.getParameterMap();
        for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
            String key = entry.getKey();
            String[] values = entry.getValue();
            for (String value : values) {
                uniqueMap.put(key, value);
            }
        }

        String notifyType = uniqueMap.get("notify_type");    // 通知类型
        String tradeStatus = uniqueMap.get("trade_status");    // 支付状态
        String isSuccess = uniqueMap.get("is_success");    // 支付返回的结果

        boolean executed = false;
        /*-
         * 返回类型为 支付成功 (isSuccess=T 且 已支付 (TRADE_FINISHED/TRADE_PAYED)
         */
        if ("T".equals(isSuccess)
                && ("TRADE_PAYED".equals(tradeStatus) || "TRADE_FINISHED".equals(tradeStatus))) {
            return true;
        }
        /*-
         * 通知类型为 支付 (TRADE_PAY)或者返回的isSuccess(T) 且 已支付 (TRADE_FINISHED/TRADE_PAYED) 且 验签成功
         */
        if ("TRADE_PAY".equals(notifyType)
                && ("TRADE_PAYED".equals(tradeStatus) || "TRADE_FINISHED".equals(tradeStatus))
                && verifyTransaction(uniqueMap)) {
            String order = uniqueMap.get("out_trade_no");           // 订单号
            String createTime = uniqueMap.get("gmt_create");         //订单创建时间 
            String payTime = uniqueMap.get("pay_date");         // 支付时间
            Date paidTime = parseDate(payTime, "yyyyMMddHHmmss");
            String partner_id = uniqueMap.get("partner_id");        //合作商户号
            String orderAmount = uniqueMap.get("orderAmount");      // 订单提交金额
            String payAmountStr = uniqueMap.get("payAmount");       // 支付金额
            String total_fee = uniqueMap.get("total_fee");          // 交易总金额
            int amount = Utils.toFen(total_fee);
            String seller_email = uniqueMap.get("seller_email");    // 卖家账户号
            String notify_id = uniqueMap.get("notify_id");          //通知校验ID
            String transaction = uniqueMap.get("pay_order_no");          //支付平台订单号

            callback.onFinished(order, amount, paidTime, transaction, uniqueMap);
            executed = true;
        }
        LOG.debug("====================支付成功==" + executed);
        if (!executed) {
            callback.onError(null, null, null, uniqueMap);
        }
        return executed;
    }

    /**
     * 验证签名
     * 当 results
     */
    public boolean verifyTransaction(Map<String, String> callbackParams) {

        // FIXME
        /*
        boolean isVerified = SM2SignHelper.verify(callbackParams, DEFAULT_DN_NAME);
        LOG.info("-------------------------验签：" + isVerified + "--DN_NAME:" + DEFAULT_DN_NAME + "---------------------");
        return isVerified;
        */
        return false;

    }

    /**
     * 验证请求是否有效, 如果需要则对接口进行响应
     *
     * @param request  支付回调请求
     * @param callback 支付成功回调操作
     * @return 请求是否有效
     * @throws Exception
     */
    @Override
    public boolean verifyTransaction(HttpServletRequest request, HttpServletResponse response,
                                     TransactionCallback callback) throws Exception {
        PrintWriter writer = response.getWriter();
        boolean executed = false;
        if (verifyTransaction(request, callback)) {
            // 1 表示处理成功
            response.getWriter().print("true");
            executed = true;
        } else {
            writer.print("false");
        }
        writer.flush();

        return executed;
    }


    public static String getSrcPath(String name) {
        String result = null;
        URL urlpath = CmbcEpay.class.getClassLoader().getResource(name);
        String path = urlpath.toString();
        //remove the head "file:",if it exists  
        if (path.startsWith("file")) {
            path = path.substring(5);
        }
        path.replace("/", File.separator);
        result = path;
        return result;
    }

}
