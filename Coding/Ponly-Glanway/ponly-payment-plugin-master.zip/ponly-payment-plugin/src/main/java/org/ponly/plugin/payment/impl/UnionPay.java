package org.ponly.plugin.payment.impl;

import java.util.concurrent.TimeUnit;
import org.ponly.common.codec.Base64;
import org.ponly.common.crypto.digest.Hash;
import org.ponly.common.util.Dates;
import org.ponly.common.util.StringUtils;
import org.ponly.plugin.payment.Payment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static org.ponly.plugin.payment.impl.Utils.*;

/**
 * 银联网关支付 (全渠道,在手机端该接口会自动切换到手机版)
 * <p/>
 * 按照《网关支付产品接口规范V1.4》实现
 * -----------------------------
 * 名词:
 * 前台类交易:
 * 指交易请求方(如商户、收单机构)与全渠道平台之间的交易信息通过用户浏览器进 行传递的交易,是一种异步的、需要持卡人参与完成的交易类型
 * 后台类资金类交易:
 * 指交易请求方(如商户、收单机构),将交易信息(涉及资金清算的交易)直 接通过请求方服务器发送至全渠道平台服务器的交易方式。
 * 是一种异步的、不需要持卡人参与完成的交 易类型
 * ------------------------------
 * <p/>
 * 《网关支付产品商户接入测试指引1.1》中提供的测试环境测试卡号:
 * ------------------
 * 银行卡号: 6216261000000000018
 * 身份证号: 341126197709218366
 * 短信验证码: 111111
 * ---------------------
 * 平安银行!借记卡!：6216261000000000018
 * 证件号: 341126197709218366
 * 手机号: 13552535506
 * 密码: 123456
 * 姓名: 全渠道
 * ------------------
 * 平安银行!贷记卡!：6221 5588 1234 0000
 * 姓名：互联网
 * 证件号: 341126197709218366
 * 手机号: 13552535506
 * CVN2: 123
 * 有效期: 1711
 * ------------------
 * B2B企业网银农行虚拟卡
 * 卡号：123456789001
 * 密码：789001
 * ------------------
 * -----------------------------------------------
 * 注册测试商户获取测试证书: https://open.unionpay.com/ajweb/register, 我的测试 -- 测试参数 (生产环境联系operation@unionpay.com)
 * <p/>
 * https://open.unionpay.com/ajweb/tech
 * https://merchant.unionpay.com/portal/pages/login/download.jsp?locale=zh_CN
 * https://open.unionpay.com/ajweb/help/file
 * 应答码: https://open.unionpay.com/ajweb/help/respCode/respCodeList
 * https://open.unionpay.com/ajweb/help/apiTool
 *
 * @author vacoor
 */
public class UnionPay implements Payment {
    private static final Logger LOG = LoggerFactory.getLogger(UnionPay.class);

    private static final String ENC_ISO_8859_1 = "ISO-8859-1";
    private static final String ENC_UTF_8 = "UTF-8";
    private static final Charset ISO_8859_1 = Charset.forName(ENC_ISO_8859_1);
    private static final Charset UTF_8 = Charset.forName(ENC_UTF_8);

    /* *****************************************************************
     *       入网测试环境交易发送地址(《网关支付产品商户接入测试指引1.1》)
     * *****************************************************************/
    // 前台类交易发送地址: acpsdk.frontTransUrl
    public static final String UNIONPAY_SANDBOX_FRONT_TRANS_URL = "https://101.231.204.80:5000/gateway/api/frontTransReq.do";
    // app 交易请求地址 acpsdk.appTransUrl
    private static final String UNIONPAY_SANDBOX_APP_TRANS_URL = "https://101.231.204.80:5000/gateway/api/appTransReq.do";
    // 后台类交易发送地址(无卡): acpsdk.backTransUrl
    private static final String UNIONPAY_SANDBOX_BACK_TRANS_URL = "https://101.231.204.80:5000/gateway/api/backTransReq.do";
    // 后台交易请求地址(有卡) acpsdk.cardTransUrl
    private static final String UNIONPAY_SANDBOX_CARD_TRANS_URL = "https://101.231.204.80:5000/gateway/api/cardTransReq.do";
    // 交易状态查询地址: acpsdk.singleQueryUrl
    private static final String UNIONPAY_SANDBOX_SINGLE_QUERY_URL = "https://101.231.204.80:5000/gateway/api/queryTrans.do";
    // 批量交易请求地址: acpsdk.batchTransUrl
    private static final String UNIONPAY_SANDBOX_BATCH_TRANS_URL = "https://101.231.204.80:5000/gateway/api/batchTransReq.do";
    // 文件传输类交易地址（对账文件下载接口）: acpsdk.fileTransUrl
    private static final String UNIONPAY_SANDBOX_FILE_TRANS_URL = "https://101.231.204.80:9080";

    // 前台类交易发送地址: acpsdk.frontTransUrl
    private static final String UNIONPAY_PRODUCTION_FRONT_TRANS_URL = "https://gateway.95516.com/gateway/api/frontTransReq.do";
    // app 交易请求地址 acpsdk.appTransUrl
    private static final String UNIONPAY_PRODUCTION_APP_TRANS_URL = "https://gateway.95516.com /gateway/api/appTransReq.do";
    // 后台类交易发送地址(无卡): acpsdk.backTransUrl
    private static final String UNIONPAY_PRODUCTION_BACK_TRANS_URL = "https://gateway.95516.com/gateway/api/backTransReq.do";
    // 后台交易请求地址(有卡) acpsdk.cardTransUrl
    private static final String UNIONPAY_PRODUCTION_CARD_TRANS_URL = "https://gateway.95516.com /gateway/api/cardTransReq.do";
    // 交易状态查询地址: acpsdk.singleQueryUrl
    private static final String UNIONPAY_PRODUCTION_SINGLE_QUERY_URL = "https://gateway.95516.com/gateway/api/queryTrans.do";
    // 批量交易请求地址: acpsdk.batchTransUrl
    private static final String UNIONPAY_PRODUCTION_BATCH_TRANS_URL = "https://gateway.95516.com/gateway/api/batchTrans.do";
    // 文件传输类交易地址（对账文件下载接口）: acpsdk.fileTransUrl
    private static final String UNIONPAY_PRODUCTION_FILE_TRANS_URL = "https://filedownload.95516.com/";

    /* **************************************
     *       签名证书配置
     * **************************************/
    // 签名证书路径(生产环境需要从cfca下载得到): acpsdk.signCert.path=/acpsdk/acp_test_sign.pfx
//    private static final String DEFAULT_KEY_STORE_PFX = "/acpsdk/acp_test_sign.pfx";
    private static final String DEFAULT_KEY_STORE_PFX = "/acpsdk/djmall/signCert-ds20170321.pfx";
    // 签名证书类型, 固定不需要修改
    private static final String DEFAULT_KEY_STORE_TYPE = KS_TYPE_PKCS12;
    // 签名证书密码
//    private static final String DEFAULT_KEY_STORE_PASS = "000000";
    private static final String DEFAULT_KEY_STORE_PASS = "331723";
    //    private static final String DEFAULT_PRIVATE_KEY_ALIAS = "test-alias";
    private static final String DEFAULT_PRIVATE_KEY_PASS = DEFAULT_KEY_STORE_PASS;

    /* **************************************
     *       验签证书配置
     * **************************************/
    // 验证签证书 acpsdk.validateCert.dir
//    private static final String DEFAULT_CER = "/acpsdk/acp_test_verify_sign.cer";
    private static final String DEFAULT_CER = "/acpsdk/djmall/acp_prod_verify_sign.cer";

    /* **************************************
     *       加密证书配置(不需要)
     * **************************************/
//    private static final String DEFAULT_ENCRYPT_CERT = "/acpsdk/acp_test_enc.cer";
    private static final String DEFAULT_ENCRYPT_CERT = "/acpsdk/djmall/acp_prod_enc.cer";

    private static final PrivateKey DEFAULT_PRIVATE_KEY;        // 默认加密私钥
    private static final X509Certificate DEFAULT_CERTIFICATE;   // 验签默认证书
    private static final X509Certificate DEFAULT_SIGN_CERTIFICATE;        // 默认加密私钥

    private static final String BC_PROV_ALGORITHM_SHA1RSA = "SHA1withRSA";
    private static final String UNIONPAY_VERSION = "5.0.0";     // 接口版本号
    private static final String SIGN_METHOD_RSA = "01";          // RSA 方式证书加密, 只支持 01:RSA
    private static final String TXN_TYPE = "01";                // 交易类型, 消费
    private static final String TXN_SUB_TYPE = "01";            // 交易子类型, 自助消费
    private static final String BIZ_TYPE = "000201";            // 业务类型, B2C 网关支付
    private static final String CHANNEL_TYPE = "07";            // 渠道类型 - 07：PC,平板      08：手机
    private static final String ACCESS_TYPE = "0";              // 接入类型，直接接入


    private static final String SIGN_PARAM = "signature";
    private String signCertPwd = "000000";
    private String signCertType = "PKCS12";

    private String merIdKey = "777290058123292";    // 商户号merchantId
    private String base64EncodedPrivateKey;         // base64 编码的私钥
    private String base64EncodedX509PublicKey;      // base64 编码的x509公钥
    private String returnUrl = "";                  // 前端响应地址
    private String notifyUrl = "";                  // 后端响应地址
    private String currencyCode = "156";            // 币种: RMB = 156
    private String certId = "";

    public UnionPay(String mid, String base64EncodedPrivateKey, String base64EncodedX509PublicKey) {
        this.merIdKey = mid;
        this.base64EncodedPrivateKey = base64EncodedPrivateKey;
        this.base64EncodedX509PublicKey = base64EncodedX509PublicKey;
    }

    @Override
    public void setNotifyUrl(String url) {
        notifyUrl = url;
    }

    @Override
    public void setReturnUrl(String url) {
        returnUrl = url;
    }

    @Override
    public void postTransaction(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee, Date expire, String subject, String body) throws IOException {
        postTransaction(request, response, tradeNo, fee, expire, subject, body, null);
    }

    @Override
    public void postTransaction(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee, Date expire, String subject, String body, Map<String, String> udfParams) throws IOException {
        Map<String, String> payParams = getPayParams(tradeNo, fee, expire, subject, body, udfParams);
        String html = buildRequestHtml(UNIONPAY_SANDBOX_FRONT_TRANS_URL, "POST", payParams);

        if (LOG.isDebugEnabled()) {
            LOG.debug("build pay html: {}", html);
        }

        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().print(html);
    }

    @Override
    public String getQRCodeUrl(String tradeNo, int fee, Date expire, String subject, String body, int width) throws IOException {
        return null;
    }

    public Map<String, String> getPayParams(String tradeNo, int fee, Date expire, String subject, String body, Map<String, String> udfParams) {
        //创建交易数据集合
        Map<String, String> params = new HashMap<String, String>();

        /******* 基本参数 *******/

        // 银联全渠道系统，产品参数，除了encoding自行选择外其他不需修改
        params.put("version", UNIONPAY_VERSION);
        params.put("encoding", ENC_UTF_8);
        params.put("signMethod", SIGN_METHOD_RSA);
        // https://open.unionpay.com/ajweb/product/detail?id=2
        params.put("txnType", TXN_TYPE);                            // 交易类型, 01消费, 79开通跳转支付
        params.put("txnSubType", TXN_SUB_TYPE);                     // 01自助消费 03分期付款

        /*-
         * 产品类型:
         *   000201: B2C网关支付
         *   000301: 无跳转（商户侧）
         *   Token版固定填写: 000902
         */
        params.put("bizType", BIZ_TYPE);
        params.put("channelType", CHANNEL_TYPE);                    // 渠道类型

        /******* 商户接入参数 ********/

        params.put("accessType", ACCESS_TYPE);                      // 接入类型, 0普通商户直连,2平台商户接入
        params.put("merId", merIdKey);                              // 商户号码，请改成自己申请的正式商户号或者open上注册得来的777测试商户号
        params.put("frontUrl", returnUrl);                          // 同步跳转地址
        params.put("backUrl", notifyUrl);                           // 异步通知地址


        /******* 订单信息参数 ********/

        params.put("orderId", tradeNo);                             // 商户订单号，8-40位数字字母，不能含“-”或“_”，可以自行定制规则
        /*
        params.put("accType", "");
        params.put("accNo", "");                                    // 锁定消费卡号
        */
        params.put("currencyCode", currencyCode);
        params.put("txnAmt", String.valueOf(fee));                  // 交易金额，单位分，无小数点
        params.put("txnTime", getCurrentDate("yyyyMMddHHmmss"));    // 订单发送时间，取系统时间，格式为YYYYMMDDhhmmss，必须取当前时间，否则会报txnTime无效

        if (null != expire) {
            params.put("payTimeout", formatDate(expire, "yyyyMMddHHmmss")); // 订单支付超时时间, 超过此时间用户支付成功的交易, 不通知商户,系统自动退款,大约 5 个工作日金额返还到用户账户
        }
        /*-
          以下问客服问答:
          要实现跳转到指定银行,首先业务上需要申请开通网银支付和网银前置功能
          然后在请求报文中上送发卡机构代码issInsCode字段
          测试环境不支持网银跳转,所以实现不了
         */
        params.put("issInsCode", "");                               // 发卡机构代码, 在前台类交易时填写银行代码，直接跳转到发卡行网银，需要开通相关权限
        /*
        params.put("customerInfo", "");
        params.put("orderTimeout", "");                             // 订单接收超时时间(防钓鱼)
        params.put("termId", "");
        params.put("reqReserved", "");                              // 请求方保留域，透传字段（可以实现商户自定义参数的追踪）本交易的后台通知,对本交易的交易状态查询交易、对账文件中均会原样返回，商户可以按需上传，长度为1-1024个字节
        params.put("reserved", "");
        params.put("riskRateInfo", "");
        params.put("encryptCertId", "");
        params.put("frontFailUrl", "");                             // 仅跳转
        params.put("instalTransInfo", "");                          // 分期付款信息
        params.put("defaultPayType", "");                           //
        params.put("supPayType", "");
        params.put("userMac", "");
        params.put("customerIp", "");                               // 持卡人 ID, 有 IP 防钓鱼要求的商户 上送
        params.put("cardTransData", "");                            // 有卡交易信息域
        params.put("orderDesc", "");                                // 移动支付上送
        */

        if (null != udfParams) {
            params.putAll(udfParams);
        }

        // 加签
        return sign(params, ENC_UTF_8);
    }

    /**
     * 对给定数据进行加签, 返回加签后的参数
     *
     * @param data     待加签数据
     * @param encoding 加签使用的编码
     * @return 加签后的数据
     */
    private Map<String, String> sign(Map<String, String> data, String encoding) {
        Map<String, String> filtered = new HashMap<String, String>();
        for (Map.Entry<String, String> entry : data.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            if (StringUtils.hasText(value)) {
                filtered.put(key, value.trim());
            }
        }
        return doSign(filtered, encoding);
    }

    private Map<String, String> doSign(Map<String, String> data, String encoding) {
        PrivateKey privateKey = DEFAULT_PRIVATE_KEY;

        if (StringUtils.hasText(base64EncodedPrivateKey)) {
            try {
                privateKey = toPrivateKey(base64EncodedPrivateKey);
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }
        X509Certificate cert = DEFAULT_SIGN_CERTIFICATE;
        String certId = cert.getSerialNumber().toString();

        data.put("certId", certId);
        Charset charset = Charset.forName(encoding);

        /*
         * base64(sign(hex(sha1(sort(data)))))
         * 1.字典顺序排序
         * 2. SHA1
         * 3. HEX
         * 4. SIGN
         * 5. BASE64
         */
        String unsignParams = toSortedNVString(data, SIGN_PARAM);
        String encoded = new Hash.SHA1(unsignParams.getBytes(charset)).toHex();
        String sign = signAsBase64(BC_PROV_ALGORITHM_SHA1RSA, privateKey, encoded.getBytes(charset));

        data.put(SIGN_PARAM, sign);
        return data;
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean verifyTransaction(HttpServletRequest request, TransactionCallback callback) {
        try {
            request.setCharacterEncoding(ENC_ISO_8859_1);
        } catch (UnsupportedEncodingException e) {
            // ignore
        }
        String encoding = request.getParameter("encoding");
        encoding = null != encoding ? encoding : ENC_UTF_8;

        Map<String, String> uniqueMap = new HashMap<String, String>();
        Map<String, String[]> parameterMap = request.getParameterMap();
        for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
            String key = entry.getKey();
            String[] values = entry.getValue();
            for (String value : values) {
                uniqueMap.put(key, new String(value.getBytes(ISO_8859_1), UTF_8));
            }
        }

        String txnType = uniqueMap.get("txnType");
        uniqueMap.get("txnSubType");
        uniqueMap.get("bizType");
        uniqueMap.get("accessType");
        uniqueMap.get("merId");
        uniqueMap.get("currencyCode");  // 只有异步有？
        String respCode = uniqueMap.get("respCode"); //获取应答码，收到后台通知了respCode的值一般是00，可以不需要根据这个应答码判断。
        String respMsg = uniqueMap.get("respMsg");


        /**
         * 根据文档只有成功才会调用, 值都是 00, 不需要判断, 但是还是判断下因为前台也会调用这个方法来验证
         * TODO 前台不允许处理逻辑必须等待后台通知
         */
        boolean executed = false;
        if (TXN_TYPE.equals(txnType) && "00".equals(respCode) && doVerify(uniqueMap)) {
            String orderId = uniqueMap.get("orderId");                  //
            int amount = Integer.parseInt(uniqueMap.get("txnAmt"));     // 交易金额
            String transactionId = uniqueMap.get("queryId");            // 银联交易流水号
            String paidTimeStr = uniqueMap.get("traceTime");            // 交易传输时间, 异步才有, yyyyMMddHHmmss
            Date paidTime = parseDate(paidTimeStr, "yyyyMMddHHmmss");
            uniqueMap.get("exchangeDate");                              // 兑换日期, 境外交易时返回
            uniqueMap.get("exchangeRate");                              // 兑换汇率, 境外交易时返回
            if (null == paidTime) {
                String sendTimeStr = uniqueMap.get("txnTime");          // 订单发送时间, yyyyMMddHHmmss
                paidTime = parseDate(sendTimeStr, "yyyyMMddHHmmss");
            }

            callback.onFinished(orderId, amount, paidTime, transactionId, uniqueMap);
            executed = true;
        }
        if (!executed) {
            callback.onError(null, null, null, uniqueMap);
        }
        return executed;
    }

    @Override
    public boolean verifyTransaction(HttpServletRequest request, HttpServletResponse response, TransactionCallback callback) throws Exception {
        boolean executed = false;
        if (verifyTransaction(request, callback)) {
            //返回给银联服务器http 200  状态码
            response.getWriter().print("ok");
            executed = true;
        } else {
            response.sendError(400);
        }
        return executed;
    }

    protected boolean doVerify(Map<String, String> callbackParams) {
        String sign = callbackParams.get(SIGN_PARAM);
        String certId = callbackParams.get("certId");
        String signMethod = callbackParams.get("signMethod");
        // 签名方法允许与提交的不同

        // 用银联发给商户的公钥证书验证签名.
        X509Certificate cert = DEFAULT_CERTIFICATE;
        if (!cert.getSerialNumber().toString().equals(certId)) {
            return false;
        }

        String unsignParams = toSortedNVString(callbackParams, SIGN_PARAM);
        String encoded = new Hash.SHA1(unsignParams.getBytes(UTF_8)).toHex();
        byte[] signBytes = Base64.decode(sign);
        byte[] encodedBytes = encoded.getBytes(UTF_8);

        PublicKey publicKey = cert.getPublicKey();
        return verifySign(BC_PROV_ALGORITHM_SHA1RSA, publicKey, encodedBytes, signBytes);
    }

    static {
        X509Certificate cert = null;
        PrivateKey privateKey = null;
        X509Certificate signCert = null;

        try {
            cert = getX509Certificate(UnionPay.class, DEFAULT_CER);
        } catch (Exception ex) {
            LOG.debug("load default certificate failed", ex);
        }
        try {
            KeyStore ks = loadKeyStore(UnionPay.class, DEFAULT_KEY_STORE_PFX, DEFAULT_KEY_STORE_TYPE, DEFAULT_KEY_STORE_PASS);
//             privateKey = getKey(ks, DEFAULT_PRIVATE_KEY_ALIAS, DEFAULT_PRIVATE_KEY_PASS);
            // 获取签名证书私钥（单证书模式）
            privateKey = getFirstKey(ks, DEFAULT_PRIVATE_KEY_PASS);
            signCert = getFirstCertificate(ks);
            if (null == cert) {
                LOG.debug("load default certificate from default keystore");
                cert = getFirstCertificate(ks);
            }
        } catch (Exception ex) {
            LOG.debug("load default keystore failed", ex);
        }

        DEFAULT_CERTIFICATE = cert;
        DEFAULT_PRIVATE_KEY = privateKey;
        DEFAULT_SIGN_CERTIFICATE = signCert;
    }

    public static void main(String[] args) {
        String merIdKey = "826130050210001";    // 商户号merchantId
        UnionPay unionPay = new UnionPay(merIdKey, null, null);
        unionPay.setNotifyUrl("http://localhost/notify");
        unionPay.setReturnUrl("http://localhost/return");
        Map<String, String> payParams = unionPay.getPayParams("201731123238320001", 1, Dates.after(100, TimeUnit.MINUTES), "鼎坚商城", "", null);
        System.out.println(Utils.buildRequestHtml(UNIONPAY_PRODUCTION_FRONT_TRANS_URL, payParams));
    }
}
