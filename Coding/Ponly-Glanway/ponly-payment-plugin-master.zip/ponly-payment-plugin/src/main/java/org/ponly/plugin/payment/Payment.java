package org.ponly.plugin.payment;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.Map;

/**
 * 支付接口
 *
 * @author vacoor
 */
public interface Payment {
    /**
     * 回调函数
     */
    interface TransactionCallback {
        /**
         * 不执行任何操作的回调, 只用于检测是否成功
         */
        TransactionCallback NOP = new TransactionCallback() {
            @Override
            public void onFinished(String tradeNo, int fee, Date paidTime, String transactionId, Map<String, String> callbackParams) {
            }

            @Override
            public void onError(String errorCode, String errorMsg, Exception ex, Map<String, String> callbackParams) {
            }
        };

        /**
         * 支付成功回调
         *
         * @param tradeNo        订单号
         * @param fee            付款金额
         * @param paidTime       付款时间
         * @param transactionId  交易号
         * @param callbackParams 回调参数
         */
        void onFinished(String tradeNo, int fee, Date paidTime, String transactionId, Map<String, String> callbackParams);

        /**
         * 当支付回调验证失败
         *
         * @param errorCode      错误代码
         * @param errorMsg       错误消息
         * @param ex             错误异常
         * @param callbackParams 回调函数
         */
        void onError(String errorCode, String errorMsg, Exception ex, Map<String, String> callbackParams);

    }

    /**
     * 设置异步通知 URL
     *
     * @param url 异步通知 URL
     */
    void setNotifyUrl(String url);

    /**
     * 设置同步通知 URL
     *
     * @param url 同步通知 URL
     */
    void setReturnUrl(String url);

    /**
     * 发起支付请求
     *
     * @param request  HttpRequest
     * @param response HttpResponse
     * @param tradeNo  订单号
     * @param fee      订单金额
     * @param expire   过期时间
     * @param subject  订单主题
     * @param body     订单明细
     * @throws IOException
     */
    void postTransaction(final HttpServletRequest request,
                         final HttpServletResponse response,
                         final String tradeNo,
                         final int fee,
                         final Date expire,
                         final String subject,
                         final String body) throws IOException;

    /**
     * 发起支付请求
     *
     * @param request   HttpRequest
     * @param response  HttpResponse
     * @param tradeNo   订单号
     * @param fee       订单金额
     * @param expire    过期时间
     * @param subject   订单主题
     * @param body      订单明细
     * @param udfParams 用户自定义参数
     * @throws IOException
     */
    void postTransaction(final HttpServletRequest request,
                         final HttpServletResponse response,
                         final String tradeNo,
                         final int fee,
                         final Date expire,
                         final String subject,
                         final String body,
                         final Map<String, String> udfParams) throws IOException;

    /**
     * 获取 QRCODE 支付二维码
     *
     * @param tradeNo 订单号
     * @param fee     订单金额
     * @param expire  过期时间
     * @param subject 订单主题
     * @param body    订单明细
     * @param width   期望的宽度
     * @return 二维码地址或二维码内容
     * @throws IOException
     */
    String getQRCodeUrl(String tradeNo, int fee, Date expire, String subject, String body, int width) throws IOException;

    /**
     * 只验证请求是否有效, 不对接口做任何响应
     *
     * @param request  支付回调请求
     * @param callback 支付成功回调操作
     * @return 请求是否有效
     */
    boolean verifyTransaction(HttpServletRequest request, TransactionCallback callback);

    /**
     * 验证请求是否有效, 如果需要则对接口进行响应
     *
     * @param request  支付回调请求
     * @param callback 支付成功回调操作
     * @return 请求是否有效
     * @throws Exception
     */
    boolean verifyTransaction(HttpServletRequest request, HttpServletResponse response, TransactionCallback callback) throws Exception;

}
