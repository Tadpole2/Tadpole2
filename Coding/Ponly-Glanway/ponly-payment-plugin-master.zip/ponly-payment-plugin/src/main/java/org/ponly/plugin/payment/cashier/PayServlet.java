package org.ponly.plugin.payment.cashier;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

/**
 * Created by Vacoor on 2017-03-25.
 */

public class PayServlet {

    private static BigDecimal toStdValue(final BigDecimal decimal) {
        if (null == decimal) {
            return null;
        }
        DecimalFormat fmt = new DecimalFormat("#.0");
        fmt.setRoundingMode(RoundingMode.CEILING);;
        return new BigDecimal(fmt.format(decimal));
    }

    public static void main(String[] args) {
        BigDecimal decimal = BigDecimal.valueOf(99999991.22);
        System.out.println(toStdValue(decimal));
    }

}
