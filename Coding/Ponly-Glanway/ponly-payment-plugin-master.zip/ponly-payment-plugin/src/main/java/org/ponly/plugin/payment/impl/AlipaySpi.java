package org.ponly.plugin.payment.impl;

import org.ponly.plugin.payment.Payment;
import org.ponly.plugin.payment.PaymentSpi;

import java.util.Properties;

/**
 * 支付宝即时到账 SPI
 *
 * @author vacoor
 */
public class AlipaySpi extends PaymentSpi {
    public static final String ID = "alipay";
    public static final String NAME = "支付宝即时到账";

    public static final String SELLER = ID + ".seller";
    public static final String PID = ID + ".pid";
    public static final String KEY = ID + ".key";

    private static final OptionInfo[] OPTIONS = new OptionInfo[]{
            new OptionInfo(SELLER, "支付宝卖家账号", OPT_TYPE_BOOL, true),
            new OptionInfo(PID, "支付宝合作者身份(PID)", OPT_TYPE_STRING, true),
            new OptionInfo(KEY, "支付宝安全校验码(KEY)", OPT_TYPE_STRING, true)
    };

    @Override
    public String getId() {
        return ID;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String getVersion() {
        return "0.1-beta";
    }

    @Override
    public Payment create(Properties props) {
        props = null != props ? props : new Properties();
        String seller = props.getProperty(SELLER);
        String pid = props.getProperty(PID);
        String key = props.getProperty(KEY);

        return new Alipay(seller, pid, key);
    }

    @Override
    public OptionInfo[] getOptionInfo() {
        return OPTIONS;
    }
}
