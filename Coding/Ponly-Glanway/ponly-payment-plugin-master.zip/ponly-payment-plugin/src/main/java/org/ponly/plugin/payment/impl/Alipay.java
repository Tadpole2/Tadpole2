package org.ponly.plugin.payment.impl;

import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;
import org.ponly.common.crypto.digest.Hash;
import org.ponly.common.util.*;
import org.ponly.plugin.payment.Payment;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import static org.ponly.plugin.payment.impl.Utils.*;

/**
 * 支付宝支付
 * <p/>
 * 支付宝即时到帐:
 * https://cshall.alipay.com/enterprise/help_detail.htm?help_id=477479
 * https://doc.open.alipay.com/doc2/detail?treeId=62&articleId=103566&docType=1
 * 手机网站支付(WAP):
 * https://b.alipay.com/order/productDetail.htm?productId=2015110218008816&tabId=4#ps-tabinfo-hash
 * https://doc.open.alipay.com/doc2/detail?treeId=60&articleId=103564&docType=1
 * 移动支付(手机APP):
 * https://doc.open.alipay.com/doc2/detail?treeId=59&articleId=103563&docType=1
 *
 * @author vacoor
 */
public class Alipay implements Payment {
    public static final String ALIPAY_GATEWAY = "https://mapi.alipay.com/gateway.do";
    // 基本参数
    public static final String SERVICE_PARAM = "service";                   // 接口名称, 固定值 create_direct_pay_by_user, 必填
    public static final String PARTNER_PARAM = "partner";                   // 合作者身份ID, 支付宝账号对应的支付宝唯一用户号, 2088 开头16位纯数字, 必填
    public static final String INPUT_CHARSET_PARAM = "_input_charset";      // 字符编码, utf-8, gbk, gb2312, 必填
    public static final String SIGN_TYPE_PARAM = "sign_type";               // 签名方式, RSA/DSA/MD5, 必填
    public static final String SIGN_PARAM = "sign";                         // 签名, 必填
    public static final String NOTIFY_URL_PARAM = "notify_url";             // 异步通知 url, 可空
    public static final String RETURN_URL_PARAM = "return_url";             // 页面跳转同步通知 url, 可空
    public static final String ERROR_NOTIFY_URL_PARAM = "error_notify_url"; // 错误通知 url, 可空
    // 业务参数
    public static final String OUT_TRADE_NO_PARAM = "out_trade_no";         // 商户网站唯一订单号, 必填
    public static final String SUBJECT_PARAM = "subject";                   // 交易标题, 必填
    public static final String PAYMENT_TYPE_PARAM = "payment_type";         // 收款类型, 1: 商品购买, 必填
    public static final String TOTAL_FEE_PARAM = "total_fee";               // 交易金额, 必填

    public static final String SELLER_ID_PARAM = "seller_id";               // 卖家支付宝账号对应用户号, 2088 开头16位, 必填
    public static final String BUYER_ID_PARAM = "buyer_id";                 // 买家支付宝账号对应用户号, 2088 开头16位, 可空
    public static final String SELLER_EMAIL_PARAM = "seller_email";         // 卖家支付宝账号, 可空
    public static final String BUYER_EMAIL_PARAM = "buyer_email";           // 买家支付宝账号, 可空
    public static final String SELLER_ACCOUNT_NAME_PARAM = "seller_account_name";   // 卖家别名支付宝账号, 可空
    public static final String BUYER_ACCOUNT_NAME_PARAM = "buyer_account_name";     // 买家别名支付宝账号, 可空
    public static final String PRICE_PARAM = "price";                       // 商品单价, 单位 RMB, 两位小数, 与 total_fee 互斥, 可空
    public static final String QUANTITY_PARAM = "quantity";                 // 数量, 可空
    public static final String BODY_PARAM = "body";                         // 商品描述, <1000, 可空
    public static final String SHOW_URL_PARAM = "show_url";                 // 商品展示 URL, 可空
    public static final String PAYMETHOD_PARAM = "paymethod";               // 支付方式: creditPay(信用支付)/directPay(余额支付) 可空
    // 以下没有太大用处
    public static final String ENABLE_PAYMETHOD_PARAM = "enable_paymethod";     // 支付渠道, 可空
    public static final String NEED_CTU_CHECK_PARAM = "need_ctu_check";         // 可空
    public static final String ANTI_PHISHING_KEY_PARAM = "anti_phishing_key";   // 防钓鱼时间戳, 可空, 如果开通必填
    public static final String EXTER_INVOKE_IP_PARAM = "exter_invoke_ip";       // 防钓鱼客户IP, 可空
    public static final String EXTRA_COMMON_PARAM_PARAM = "extra_common_param"; // 公用回传参数, 传递后会回传给商户, 可空
    public static final String EXTEND_PARAM_PARAM = "extend_param";             // 公用业务扩展参数, 可空
    public static final String IT_B_PAY_PARAM = "it_b_pay";                     // 超时时间, 1m~15d, m: 分, h: 小时, d: 天, 可空
    public static final String DEFAULT_LOGIN_PARAM = "default_login";           // 自动登录, 可空
    public static final String PRODUCT_TYPE_PARAM = "product_type";             // 商家申请的产品类型, 可空
    public static final String TOKEN_PARAM = "token";                           // 快捷登录令牌, 如果开通快捷支付产品, 可空
    public static final String SIGN_ID_EXT_PARAM = "sign_id_ext";               // 商户买家签约号, 可空
    public static final String SIGN_NAME_EXT_PARAM = "sign_name_ext";           // 商户买家签约名, 可空

    public static final String QR_PAY_MODE_PARAM = "qr_pay_mode";               // QR 扫码支付方式, 可空
    public static final String QRCODE_WIDTH_PARAM = "qrcode_width";             // QRCODE 宽度, 当 qr_pay_mode = 4有效

    public static final String QR_PAY_EMBED = "0";           // 订单码-简约前置模式
    public static final String QR_PAY_NORMAL = "1";         // 订单码-前置模式
    public static final String QR_PAY_CASHIER = "2";        // 订单码-跳转模式
    public static final String QR_PAY_EMBED_MINI = "3";     // 订单码-迷你前置模式
    public static final String QR_PAY_ONLY = "4";            // 只有

    // 响应参数
    public static final String NOTIFY_ID_PARAM = "notify_id";       // 通知 ID

    private static final String PAYMENT_TYPE = "1";      // 只支持:支付方式, 1: 商品购买
    private static final String TRUE = "true";

    /* *****************************
     *
     * *****************************/

    private final String sellerEmail;
    private final String pid;
    private final String key;

    private String charset = "utf-8";
    private String notifyUrl;
    private String returnUrl;

    public Alipay(String sellerEmail, String pid, String key) {
        this.sellerEmail = sellerEmail;
        this.pid = pid;
        this.key = key;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    protected String getGatewayUrl() {
        return ALIPAY_GATEWAY;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    @Override
    public void postTransaction(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee, Date expire, String subject, String body) throws IOException {
        postTransaction(request, response, tradeNo, fee, expire, subject, body, null);
    }

    @Override
    public void postTransaction(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee, Date expire, String subject, String body, Map<String, String> udfParams) throws IOException {
        /*-
         * wap 支付: 支付宝钱包中打开链接可以直接调用支付, 浏览器中打开, 登录后支付
         * 扫码支付: 支付宝钱包中打开链接可以直接调用支付, 浏览器中打开, 可以调用钱包支付
         */
        Map<String, String> params;
        if (isMobileRequest(request)) {
            params = getWapPayParams(tradeNo, fee, expire, subject, body, udfParams);

            // 如果没有开通 wap 接口
            if (isWapIllegal(params)) {
                InputStream in = Alipay.class.getResourceAsStream("alipay-wap-qr-bridge.html");
                String html = IOUtils.toString(in, Charset.forName("UTF-8"), true);
                final String qrCodeUrl = getQRCodeUrl(tradeNo, fee, expire, subject, body, 0);
                html = new TokenParser("${", "}") {

                    @Override
                    protected String handleToken(String s) {
                        return "qrcode_url".equals(s) ? qrCodeUrl : "";
                    }
                }.doParse(html);
                response.setCharacterEncoding(charset);
                response.setContentType("text/html;charset=UTF-8");
                response.getWriter().print(html);
                return;
            } else {
                response.sendRedirect(ALIPAY_GATEWAY + "?" + HttpUtils.buildQuery(params, getCharset()));
                return;
            }
        } else {
            params = getPayParams(tradeNo, fee, expire, subject, body, udfParams, null, 0);
        }
        String html = buildRequestHtml(ALIPAY_GATEWAY + "?" + INPUT_CHARSET_PARAM + "=" + charset, "POST", params);
        response.setCharacterEncoding(charset);
        response.setContentType("text/html;charset=" + charset);
        response.getWriter().print(html);
    }

    @Override
    public String getQRCodeUrl(String tradeNo, int fee, Date expire, String subject, String body, int width) {
        Map<String, String> payParams = getPayParams(tradeNo, fee, expire, subject, body, null, QR_PAY_ONLY, width);
        return ALIPAY_GATEWAY + "?" + HttpUtils.buildQuery(payParams, getCharset());
    }

    /* **********************************
     *
     * **********************************/

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    public boolean verifyTransaction(HttpServletRequest request, TransactionCallback callback) {
        Map<String, String> uniqueMap = toUniqueMap(request.getParameterMap());

        boolean finish = false;
        String outTradeNo = uniqueMap.get(OUT_TRADE_NO_PARAM);
        String exterface = uniqueMap.get("exterface");          // 调用的哪个接口
        String tradeNo = uniqueMap.get("trade_no");             // 支付宝交易号
        String tradeStatus = uniqueMap.get("trade_status");     // TRADE_FINISHD, TRADE_SUCCESS
        String notifyTime = uniqueMap.get("notify_time");
        String notifyType = uniqueMap.get("notify_type");       // 通知类型, trade_status_sync/trade_status_sync

        /*
        String sellerEmail = uniqueMap.get("seller_email");
        String seller = uniqueMap.get("seller_id");
        String buyerEmail = uniqueMap.get("buyer_email");
        String buyer = uniqueMap.get("buyer_id");
        String qrcode = uniqueMap.get("business_scene");        // 是否扫码支付: qrpay
        String refund_status = uniqueMap.get("refund_status");
        String gmt_refund = uniqueMap.get("gmt_refund");        // yyyy-MM-dd HH:mm:ss
        String extraParams = uniqueMap.get(EXTRA_COMMON_PARAM_PARAM);      // 公共回传
        String channel = uniqueMap.get("out_channel_inst");     // 实际支付渠道, 可空, ICBC
        */

        final String totalFee = uniqueMap.get(TOTAL_FEE_PARAM);
        final int fee = StringUtils.hasText(totalFee) ? toFen(totalFee) : 0;

        String paidTimeStr = uniqueMap.get("gmt_payment");      // 支付时间, 可空, yyyy-MM-dd HH:mm:ss
        if (null == paidTimeStr) {
            paidTimeStr = notifyTime;
        }
        Date paidTime = parseDate(paidTimeStr, "yyyy-MM-dd HH:mm:ss");

        Exception exception = null;
        try {
            // TRADE_FINISHED
            if (("TRADE_FINISHED".equals(tradeStatus) || "TRADE_SUCCESS".equals(tradeStatus)) && doVerify(uniqueMap)) {
                callback.onFinished(outTradeNo, fee, paidTime, tradeNo, uniqueMap);
                finish = true;
            }
        } catch (Exception ex) {
            exception = ex;
        } finally {
            if (!finish) {
                callback.onError(null, null, exception, uniqueMap);
            }
        }
        return finish;
    }

    /**
     * {@inheritDoc}
     */
    public boolean verifyTransaction(HttpServletRequest request, HttpServletResponse response, TransactionCallback callback) throws IOException {
        boolean executed = false;
        PrintWriter writer = response.getWriter();
        if (verifyTransaction(request, callback)) {
            writer.println("success");  // 成功必须返回 success
            executed = true;
        } else {
            writer.println("fail");
        }
        writer.flush();
        return executed;
    }


    /**
     * 获取即时到账支付参数
     *
     * @param tradeNo     订单号
     * @param fee         订单费用
     * @param expire      过期时间
     * @param subject     订单主题
     * @param body        订单明细
     * @param qrpayMode   是否二维码支付模式
     * @param qrcodeWidth 二维码宽度
     * @return 即时到帐支付参数
     */
    public Map<String, String> getPayParams(String tradeNo, int fee, Date expire, String subject, String body, final Map<String, String> udfParams, String qrpayMode, int qrcodeWidth) {
        Map<String, String> params = new HashMap<String, String>();

        /* *********** 基本参数 *********** */
        params.put(SERVICE_PARAM, "create_direct_pay_by_user");
        params.put(PARTNER_PARAM, pid);
        params.put(INPUT_CHARSET_PARAM, charset);

        // 回调
        params.put(NOTIFY_URL_PARAM, notifyUrl);    // 服务器异步通知页面路径
        params.put(RETURN_URL_PARAM, returnUrl);    // 页面跳转同步通知页面路径
        params.put(ERROR_NOTIFY_URL_PARAM, "");     // 请求出错时的通知页面路径

        /* ************* 业务参数 - 通用参数 *********** */
        params.put(PAYMENT_TYPE_PARAM, PAYMENT_TYPE);
        params.put(OUT_TRADE_NO_PARAM, tradeNo);
        params.put(SUBJECT_PARAM, subject);
        params.put(TOTAL_FEE_PARAM, toYuan(fee));
        params.put(BODY_PARAM, body);
        params.put(SHOW_URL_PARAM, ""); // 商品展示地址

        // 三选一
        params.put(SELLER_ID_PARAM, "");
        params.put(SELLER_EMAIL_PARAM, sellerEmail);
        params.put(SELLER_ACCOUNT_NAME_PARAM, "");

        params.put(IT_B_PAY_PARAM, getExpireStr(expire));

        /* ************* 业务参数 - 即时到账参数 *********** */
        params.put(BUYER_ID_PARAM, "");
        params.put(BUYER_EMAIL_PARAM, "");
        params.put(BUYER_ACCOUNT_NAME_PARAM, "");
        /*-
          用于标识商户是否使用自动登录的流程。如果和参数buyer_email一起使用时，就不会再让用户登录支付宝，
          即在收银台中不会出现登录页面 (直接输入支付密码) Y/N
         */
        params.put(DEFAULT_LOGIN_PARAM, "");        //

        params.put(PRICE_PARAM, "");
        params.put(QUANTITY_PARAM, "");

        params.put(PAYMETHOD_PARAM, "");
        params.put(ENABLE_PAYMETHOD_PARAM, "");
        params.put(NEED_CTU_CHECK_PARAM, "");
        params.put(ANTI_PHISHING_KEY_PARAM, "");
        params.put(EXTER_INVOKE_IP_PARAM, "");
        params.put(EXTRA_COMMON_PARAM_PARAM, "");   // max length 100
        params.put(EXTEND_PARAM_PARAM, "");
        params.put(PRODUCT_TYPE_PARAM, "");
        params.put(TOKEN_PARAM, "");                // 快捷登录 token
        params.put(SIGN_ID_EXT_PARAM, "");
        params.put(SIGN_NAME_EXT_PARAM, "");

        qrpayMode = null != qrpayMode ? qrpayMode : "";
        params.put(QR_PAY_MODE_PARAM, qrpayMode);
        params.put(QRCODE_WIDTH_PARAM, String.valueOf(qrcodeWidth));         // QRCODE 宽度, 只对 4 有效

        if (null != udfParams) {
            params.putAll(udfParams);
        }

        // 基本参数 - 签名
        params.put(SIGN_TYPE_PARAM, "MD5");
        params.put(SIGN_PARAM, sign(key, charset, params));

        return params;
    }

    /**
     * 获取手机网站支付(WAP)网关参数
     * <p/>
     * 支付宝 WAP 支付在客户端中打开会自动识别直接调用支付, 不像微信需要自行判断,使用 JSAPI 和 WAP支付
     *
     * @param tradeNo 订单号
     * @param fee     订单费用
     * @param subject 订单主题
     * @param expire  过期时间
     * @param body    订单明细
     * @return WAP支付参数
     */
    public Map<String, String> getWapPayParams(String tradeNo, int fee, Date expire, String subject, String body) {
        return getWapPayParams(tradeNo, fee, expire, subject, body, null);
    }

    /**
     * 获取手机网站支付(WAP)网关参数
     * <p/>
     * 支付宝 WAP 支付在客户端中打开会自动识别直接调用支付, 不像微信需要自行判断,使用 JSAPI 和 WAP支付
     *
     * @param tradeNo   订单号
     * @param fee       订单费用
     * @param subject   订单主题
     * @param expire    过期时间
     * @param body      订单明细
     * @param udfParams 自定义参数.
     * @return WAP支付参数
     */
    public Map<String, String> getWapPayParams(String tradeNo, int fee, Date expire, String subject, String body, final Map<String, String> udfParams) {
        Map<String, String> params = new HashMap<>();

        /* *********** 基本参数 *********** */
        params.put(SERVICE_PARAM, "alipay.wap.create.direct.pay.by.user");
        params.put(PARTNER_PARAM, pid);
        params.put(INPUT_CHARSET_PARAM, charset);

        // 回调参数
        params.put(NOTIFY_URL_PARAM, notifyUrl);
        params.put(RETURN_URL_PARAM, returnUrl);

        /* ************* 业务参数 *********** */
        params.put(PAYMENT_TYPE_PARAM, PAYMENT_TYPE);
        params.put(OUT_TRADE_NO_PARAM, tradeNo);
        params.put(SUBJECT_PARAM, subject);
        params.put(TOTAL_FEE_PARAM, toYuan(fee));
        params.put(BODY_PARAM, body);
        params.put(SHOW_URL_PARAM, "");

        params.put(SELLER_ID_PARAM, sellerEmail);

        params.put(IT_B_PAY_PARAM, getExpireStr(expire));         // 设置未付款交易的超时时间，一旦超时，该笔交易就会自动被关闭

        // WAP 支付字段
        params.put("extern_token", "");         // 手机支付宝token, 接入极简版wap收银台时支持
        params.put("otherfee", "");             // 航旅订单其它费用, 航旅订单中除去票面价之外的费用，单位为RMB-Yuan
        /*-
         航旅订单金额描述，由四项或两项构成，各项之间由“|”分隔，每项包含金额与描述，
         金额与描述间用“^”分隔，票面价之外的价格之和必须与otherfee相等
         800^票面价|50^机建费|120^燃油费|30^航意险
         或
         800^票面价|50^其他
         */
        params.put("airticket", "");
        params.put("rn_check", "");             // 是否发起实名校验: T/F (true/false)
        params.put("buyer_cert_no", "");        // 买家证件号码
        params.put("buyer_real_name", "");      // 买家真实姓名
        params.put("scene", "");                // 收单场景

        // update 20170704 增加 app_pay
        params.put("app_pay", "Y");

        if (null != udfParams) {
            params.putAll(udfParams);
        }

        // 通用签名参数
        params.put(SIGN_TYPE_PARAM, "MD5");
        params.put(SIGN_PARAM, sign(key, charset, params));

        return params;
    }


    /**
     * 获取手机 APP 支付参数
     *
     * @param tradeNo 订单号
     * @param fee     订单费用
     * @param subject 订单主题
     * @param body    订单明细
     * @return APP 支付参数
     */
    protected Map<String, String> getAppPayParams(String tradeNo, int fee, Date expire, String subject, String body) {
        Map<String, String> params = new HashMap<>();

        /* *********** 基本参数 *********** */
        params.put(SERVICE_PARAM, "mobile.securitypay.pay");
        params.put(PARTNER_PARAM, pid);
        params.put(INPUT_CHARSET_PARAM, charset);

        // 回调参数
        params.put(NOTIFY_URL_PARAM, "");
        // params.put(RETURN_URL_PARAM, "");

        /* ************* 业务参数 *********** */
        params.put(PAYMENT_TYPE_PARAM, PAYMENT_TYPE);
        params.put(OUT_TRADE_NO_PARAM, tradeNo);
        params.put(SUBJECT_PARAM, subject);
        params.put(TOTAL_FEE_PARAM, toYuan(fee));
        params.put(BODY_PARAM, body);
        // params.put(SHOW_URL_PARAM, showUrl);

        params.put(SELLER_ID_PARAM, sellerEmail);

        params.put(IT_B_PAY_PARAM, getExpireStr(expire));

        /* ************* MOBILE 特有 *********** */
        params.put("app_id", "");
        params.put("appenv", "");

        params.put("rn_check", "");
        params.put("goods_type", "");
        params.put("extern_token", "");
        params.put("out_context", "");

        return params;
    }

    /**
     * 获取退款参数
     *
     * @return 退款参数
     */
    private Map<String, String> getRefundParams() {
        Map<String, String> params = new HashMap<String, String>();

        // 基本参数
        // params.put(SERVICE_PARAM, "refund_fastpay_by_platform_nopwd");   // 无密接口
        params.put(SERVICE_PARAM, "refund_fastpay_by_platform_pwd");        // 有密接口
        params.put(PARTNER_PARAM, pid);
        params.put(INPUT_CHARSET_PARAM, charset);
        params.put(NOTIFY_URL_PARAM, "http://g.ngrok.cc/payment/alipay/refund");
        // params.put(RETURN_URL_PARAM, returnUrl);

        params.put(SELLER_EMAIL_PARAM, sellerEmail);
        params.put(SELLER_ID_PARAM, "");
        // params.put(SELLER_ID_PARAM, pid);
        // 业务参数
        params.put("batch_no", getCurrentDate("yyyyMMdd")); // 退款批次, 不可重复, 退款日期(8位)+流水号3~24位 201512030001
        params.put("refund_date", getCurrentDate("yyyy-MM-dd HH:mm:ss"));   // 退款请求日期
        params.put("batch_num", "1");       // "单笔数据集"里面的交易总笔数
        // '支付宝交易订单号^退款金额^退款描述#第二笔支付宝交易订单号^退款金额^退款描述'
        params.put("detail_data", "2016022621001004320214116863^0.01^自主退款");      // 单笔数据集,包含退交易,退分润,退收费信息,最多1000条
        params.put("return_type", "xml");   // html/xml

        // 加签
        params.put(SIGN_TYPE_PARAM, "MD5");
        String sign = sign(key, charset, params);
        params.put(SIGN_PARAM, sign);

        return params;
    }

    /* *****************************************
     *                  签名
     * *****************************************/

    /**
     * 使用给定的 key 和 charset 来计算给定参数的签名
     *
     * @param key     支付宝签约账号 Key
     * @param charset 签名使用的字符编码
     * @param params  要签名的参数(sign_type, sign 不参与签名)
     * @return 签名值
     */
    protected static String sign(String key, String charset, Map<String, String> params) {
        String text = toSortedNVString(params, SIGN_PARAM, SIGN_TYPE_PARAM);  // 过滤且按照字典顺序排列
        return sign(key, charset, text);
    }

    /**
     * 使用给定的 key 和 charset 来计算给定文本的签名
     *
     * @param key     支付宝签约账号 Key
     * @param charset 签名使用的字符编码
     * @param text    要签名的字符串
     * @return 签名值
     */
    protected static String sign(String key, String charset, String text) {
        Charset cs = Charset.forName(charset);
        text = text + key;
        byte[] bytes = text.getBytes(cs);
        return new Hash.MD5(bytes).toHex();
    }

    /* *****************************************
     *                  验签
     * *****************************************/

    /**
     * 根据给定参数验证 return_url / notify_url 请求是否合法
     * <p/>
     * 合法性有以下条件决定
     * 1. notify_id 由 alipay 发出 (对于 return_url 参数中 notify_id 是可能为空的, 此时无法确定是否是 alipay 通知)
     * 2. 参数签名正确
     * <p/>
     * return_url: 同步通知, 用于支付后回调跳转, notify_id 可能为空, 当为空时无法确认有效性
     * notify_url: 异步通知, 用于支付后通知商户, 成功后返回"success"字符串, 否则会3分钟后重试继续通知
     *
     * @param params return_url / notify_url 请求参数
     * @return 请求是否合法
     */
    protected boolean doVerify(Map<String, String> params) {
        String notifyId = params.get(NOTIFY_ID_PARAM);
        String signType = params.get(SIGN_TYPE_PARAM);
        String sign = params.get(SIGN_PARAM);

        if (!"MD5".equalsIgnoreCase(signType)) {
            // 不支持的签名类型
            throw new RuntimeException("不支持的签名类型:" + signType);
        }

        sign = null == sign ? "" : sign;

        // 当不存在 notifyId 时无法确定来源
        return null != notifyId && sign.equalsIgnoreCase(sign(key, charset, params)) && doVerifyNotify(pid, notifyId);
    }

    /**
     * 根据 notify id 验证通知是否是支付宝发送过来的
     *
     * @param partner  合作者id
     * @param notifyId 通知id
     * @return 是否是支付宝发送的通知
     */
    protected boolean doVerifyNotify(String partner, String notifyId) {
        boolean fromAlipay = false;
        try {
            // 当 get 请求时, 是否需要解码后重新请求?
            // notifyId = URLDecoder.decode(notifyId, "utf-8");
            String verifyUrl = getGatewayUrl() + "?service=notify_verify&partner=" + partner + "&notify_id=" + notifyId;

            URL url = new URL(verifyUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            String ret = null;

            if (200 == conn.getResponseCode()) {
                Reader reader = new InputStreamReader(conn.getInputStream(), Charset.forName("utf-8"));
                StringWriter writer = new StringWriter();
                int len;
                char[] buff = new char[256];
                while (-1 != (len = reader.read(buff))) {
                    writer.write(buff, 0, len);
                }
                reader.close();
                ret = writer.toString();
            }
            ret = null != ret ? ret.trim() : null;
            fromAlipay = TRUE.equalsIgnoreCase(ret);
        } catch (IOException e) {
            // LOG
        }
        return fromAlipay;
    }

    private static String getExpireStr(Date date) {
        if (null == date) {
            return "";
        }
        int min = 1;
        int max = 15 * 24 * 60;     // 15d
        long now = new Date().getTime() / 1000 / 60;
        long expire = date.getTime() / 1000 / 60;
        long timeout = expire - now;
        return Math.min(Math.max(min, timeout), max) + "m";
    }

    protected boolean isWapIllegal(Map<String, String> wapPayParams) {
        try {
            String body = HttpUtils.get(ALIPAY_GATEWAY, wapPayParams);
            return body.contains("ILLEGAL_PARTNER_EXTERFACE");
        } catch (IOException e) {
            return true;
        }
    }

    public static void main(String[] args) {
//        final String seller = "dingjianmall@163.com";
//        final String pid = "2088121001015522";
//        final String key = "oh8ua3bwn2j2iybqpdfp1llc42fofu3i";
        final String seller = "service@aimon.cn";
        final String pid = "2088711210989349";
        final String key = "8euvzvsdwsuk5xo51c09kmnqr97xt0am";

        final Alipay alipay = new Alipay(seller, pid, key);
        final String tradeNo = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());

        alipay.setNotifyUrl("http://moehot.com/ALIPAY/notify");
        alipay.setReturnUrl("http://moehot.com/ALIPAY/return");

        final String body = "";
        final Map<String, String> params = alipay.getWapPayParams(tradeNo, 1, Dates.after(1, TimeUnit.DAYS), "", body, null);
        String html = buildRequestHtml(ALIPAY_GATEWAY + "?" + INPUT_CHARSET_PARAM + "=UTF-8", "POST", params);
        System.out.println(html);
    }
}
