# Ponly 支付组件开发说明 - Ponly Payment Guide
[TOC]
## 前言
	Ponly Payment 是对常用的支付网关的封装，提供一个统一的支付调用接口， 来处理常用的支付网关，例如：支付宝，银联，快钱，微信 等

## Maven 配置
```
<dependency>
    <groupId>org.ponly</groupId>
    <artifactId>ponly-payment-plugin</artifactId>
    <!-- 具体版本 eg: 0.1-SNAPSHOT -->
    <version>${ponly.version}</version>
</dependency>
```

## 核心 API
	**Payment 接口**：
    	定义了对于常用支付网关的统一调用接口，通过 Payment 不同实例来实现对不同支付网关的调用， 包含 PC, 二维码，WAP
	**Payments 工具类**：
    	提供了用户快捷获取不同支付网关通道实例的方法
### Payment
	Payment 定义了常用支付方式的通用调用接口，其核心方法
    1. setNotifyUrl(String url)
       设置支付异步通知地址
    2. setReturnUrl(String url)
       设置同步跳转地址
    3. postTransaction(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee, Date expireTime, String subject, String body);
       提交一个交易请求
       参数说明:
			request: 请求交易的 Http 请求, Payment 实现会根据请求来判断处理方式，例如 PC网关支付, 手机 WAP 支付, 或内置浏览器支付 (如微信公众账号的JSAPI支付)
			response: 请求交易的 Http 响应, Payment 根据请求返回不同的结果写入该响应中
            tradeNo: 订单号， 系统中唯一的订单号
            fee: 订单费用， 单位为分
            expireTime: 订单支付过期时间, 提交时传递给相关的支付网关，如果超时支付，网关会自动退款
            subject: 订单支付的主题, 例如: Ponly网上支付
            body: 订单支付明细， 可为空字符串， 例如： 某某商品
    4. getQRCodeUrl(HttpServletRequest request, HttpServletResponse response, String tradeNo, int fee, Date expireTime, String subject, String body); 获取扫码支付的条码/二维码 URL
    	说明： 对于不同的实现，返回的内容可能不同， 例如
        	对于支付宝，返回的是 二维码 的 iframe url
            对于微信, 返回的是 二维码 url 内容，需要自行生成 二维码
    5. verifyTransaction(HttpServletRequest req, Payment.TransactionCallback callback);
       验证同步返回的交易请求请求
       参数说明：
       		req: 支付同步返回请求
            callback: 同步返回的支付结果处理回调， 详见 Payment.TransactionCallback
    	一般来讲， 同步返回只需要验证是否有效，并不处理业务逻辑(这里指更新订单状态等)，因此 callback 可以传入一个空实现 Payment.TransactionCallback.NOP, 然后根据返回结果来判断是否有效
    6. verifyTransaction(HttpServletRequest req, HttpServletResponse resp, Payment.TransactionCallback callback)
       验证异步通知返回的交易请求
       参数说明：
			req: 支付通知请求
			resp: 支付通知响应， 如果回调中没有异常，Payment实现会按照支付网关的要求返回相应的成功结果
            callback: 支付结果处理回调， 在该回调中应该对支付结果，订单状态等进行处理，如果没有处理成功应该在回调中抛出异常
### Payment.TransactionCallback
	Payment.TransactionCallback 定义了交易的回调函数定义如下：
```
interface TransactionCallback {

    void onFinished(String tradeNo, int fee, Date paidTime, String transactionId, Map<String, String> callbackParams);

    void onError(String errCode, String errMsg, Exception ex, Map<String, String> callbackParams);
}
```
	onFinished: 支付成功回调
    参数说明:
    	tradeNo: 支付时传递给网关的订单号
        fee: 支付的金额
        paidTime: 支付时间
        transactionId: 支付网关的交易号, 用于查询/退换货等
        callbackParams: 原始的请求参数
    onError: 支付验证失败回调
    	errCode: 错误代码, 可 null
        errMsg: 错误消息, 可 null
        ex: 错误异常, 可 null
        callbackParams: 原始的请求参数
### Payments
	Payments 是一个 Payment 实例的工具类/工厂类, 只提供一个静态方法:
    Payment getPayment(String channel, Properties props)
    channel: 支付通道, 当前支持见《支持的网关》
    props: 配置参数

#### 支持的网关
	P: PC, PC 网关支付
    Q: QRCODE, 扫码支付
    W: WAP, HTML5手机端
    I: Internal, 应用内, 例如: 微信浏览器内

| 网关名称  | 网关代码(channel) | 支持情况 |
|-----------|-------------------|---------|
| 支付宝    | alipay            |  PQWI   |
| 微信支付  | wxpay             |  QWI    |
| 快钱支付  | quick_money       |  PW     |
| 银联支付  | union_pay         |  PW     |

#### 配置参数

| channel     | prop                     |     说明              |
|-------------|--------------------------|-----------------------|
| alipay      | alipay.seller            | 支付宝卖家账号        |
| alipay      | alipay.pid               | 支付宝商户 PID        |
| alipay      | alipay.key               | 支付宝商户 KEY        |
| wxpay       | wxpay.appid              | 微信支付 App ID       |
| wxpay       | wxpay.appSecret          | 微信支付 App Secrect  |
| wxpay       | wxpay.partnerId          | 微信支付 Partner ID   |
| wxpay       | wxpay.partnerKey         | 微信支付 Partner Key  |
| quick_money | quick_money.env          | 快钱环境 (sandbox/production) (since 0.1) |
| quick_money | quick_money.mid          | 快钱商户 ID (MID)     |
| quick_money | quick_money.private_key  | 快钱加签私钥(BASE64)  |
| quick_money | quick_money.public_key   | 快钱验签公钥(BASE64)  |
| quick_money | quick_money.keystore_path | 快钱keystore路径(classpath路径) (since 0.1)  |
| quick_money | quick_money.keystore_password | 快钱keystore密码 (since 0.1) |
| quick_money | quick_money.private_key_alias | 快钱keystore中加签私钥别名 (since 0.1) |
| quick_money | quick_money.private_key_password | 快钱keystore中加签私钥密码 (since 0.1) |
| quick_money | quick_money.certificate_path | 快钱验签证书路径(claspath路径) (since 0.1) |
| unionpay    | unionpay.mid             | 银联商户 ID (MID)     |
| unionpay    | unionpay.private_key     | 银联加签私钥(BASE64)  |
| unionpay    | unionpay.public_key      | 银联验签公钥(BASE64)  |
    说明:
    quick_money:
    配置以下任意一组即可(其中1的优先级高于2):
    1. `quick_money.private_key`, `quick_money.public_key`
    2. `quick_money.key_store_path`, `quick_money.keystore_password`, `quick_money.private_key_alias`, `quick_money.private_key_password`, `quick_money.certificate_path`

## 使用实例
	// 以下为 spring mvc 使用样例
```
/**
 * 提交订单到支付网关
 *
 * @param channel 支付通道
 * @param id 订单 id
 */
@RequestMapping("pay")
public String postPay(String channel, Long id, HttpServletRequest req,
                    HttpServletResponse rsp) throws IOException {
	// TODO 订单预校验, 是否存在, 是否已经支付等

    // 获取支付网关
    Payment payment = getPayment(channel);
    if (null == payment) {
    	// 如果网关不支持, 跳转到非法请求, 也可以返回 null, 跳转到 404
    	return "redirect:illegal_request";
    }

    /* *******  开始提交支付  ******** */
    String orderNo = ...;		// 订单号
    int fee = 1;				// 订单费用, 转换为分
    Date expireTime = ...;		// 过期时间, 一般是创建时间 + 24h
    String subject = "一分钱支付测试";
    String body = "";
    String returnUrl = getUrlWithoutApplication(req, "payment/" + channel + "/return");
	String notifyUrl = getUrlWithoutApplication(req, "payment/" + channel + "/notify");

    payment.setNotifyUrl(notifyUrl);
    payment.setReturnUrl(returnUrl);
    pay.postTransaction(req, resp, orderNo, fee, expireTime, subject, body);

    // postTransaction 已经响应, 因此这里返回null
    return null;
}

/**
 * 支付结果同步回调
 *
 * @param channel 支付通道
 */
@RequestMapping("{channel}/return")
public String payReturn(@PathVariable("channel") String channel,
						HttpServletRequest req,
                        HttpServletResponse resp) {
	Payment payment = getPayment(channel);
    if (null == payment) {
    	// 支付方式不存在跳转到错误页面, 如果是同步回调应该不会出现
    	return "redirect:illegal_request";
    }

    // 验证是否支付成功, 因为是同步， 因此这里可以不做业务处理
    if (verifyTransaction(request, Payment.TransactionCallback.NOP))) {
    	return "paySuccess";
    } else {
    	return "payFail";
    }
}

/**
 * 支付结果异步回调
 *
 * @param channel 支付通道
 */
@RequestMapping("{channel}/notify")
public void payReturn(@PathVariable("channel") String channel,
						HttpServletRequest req,
                        HttpServletResponse resp) {
	Payment payment = getPayment(channel);
    if (null == payment) {
    	// 支付方式不存在跳转到错误页面, 如果是同步回调应该不会出现
    	return "redirect:illegal_request";
    }

	// 验证是否支付成功
    payment.verifyTransaction(request, response, new Payment.TransactionCallback() {

        /**
         * 支付成功
         *
         * @param tradeNo 订单编号
         * @param fee 支付金额
         * @param paidTime 支付时间
         * @param transactionId 交易id
         * @param params 原始参数
         */
        @Override
        public void onFinished(String tradeNo, int fee, Date paidTime,
        						String transactionId, Map<String, String> params) {
            /*-
             * TODO 执行相关支付成功逻辑
             * 例如 没有支付成功的话，更新支付状态, 保存支付方式，支付时间，交易ID，库存等
             * 注意： 异步回调可能会被调用多次，因此应该先判断支付状态
             */
        }

        @Override
        public void onError(String errCode, String errMsg, Exception ex,
        				Map<String, String> callbackParams) {
            /*-
             * TODO 验证失败, 执行相关逻辑, 如果需要
             */
        }
    }
}

/**
 * 获取给定支付通道对应的支付实例
 *
 * @param channel 支付通道
 */
protected Payment getPayment(String channel) {
	// TODO 配置参数, 这里是样例， 实际应该从配置管理中获取
	Properties props = new Properties();

    // alipay
    props.setProperty("alipay.seller", "alipay@ponly.org");
    props.setProperty("alipay.pid", "2088******");
    props.setProperty("alipay.key", "mvy7******");

    // quick money
    props.setProperty("quick_money.mid", "100240*****");
    props.setProperty("quick_money.mid", "10012138*****");
    props.setProperty("quick_money.private_key", "*****");
    props.setProperty("quick_money.public_key", "*****");

    // china union pay
    props.setProperty("unionpay.mid", "*****");
    props.setProperty("unionpay.private_key", "*****");
    props.setProperty("unionpay.public_key", "*****");

    // wxpay
    props.setProperty("wxpay.appid", "wx123*********");
    props.setProperty("wxpay.appSecret", "d0d72d9047***");
    props.setProperty("wxpay.partnerId", "12769***");
    props.setProperty("wxpay.partnerKey", "b4bacc7***");

    return Payments.getPayment(channel, props);
}
```