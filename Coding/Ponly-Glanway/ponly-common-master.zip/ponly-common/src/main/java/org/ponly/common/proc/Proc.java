package org.ponly.common.proc;

import org.ponly.common.proc.mgt.ProcManager;
import org.ponly.common.util.LazyValue;
import org.ponly.common.misc.util.Platform;
import org.ponly.common.util.ArrayUtils;
import org.ponly.common.util.function.Condition;
import org.ponly.common.util.function.Processor;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.regex.Pattern;

/**
 * 系统进程信息
 *
 * @author vacoor
 */
public class Proc {
    private static final Pattern WINDOWS_STATE_PATTERN = Pattern.compile("................");
    private static final Pattern WINDOWS_CPU_TIME_PATTERN = Pattern.compile("[0-9:]*");

    private final String user;
    private final int pid;
    private final float cpuPercentage;      // CPU 使用率
    private final float memPercentage;      // 内存使用率
    // taille virtuelle de l'image du processus (code + données + pile).
    private final int vsz;                  // 虚拟内存大小
    private final int rss;                  // 内存驻留集大小
    private final String tty;
    /*-
     * 进程状态
     * R (runnable) prêt à  être exécuté,
     * S (sleeping) endormi,
     * D sommeil ininterruptible,
     * T (traced) arrêté ou suivi,
     * Z (zombie).
     * Le second champ contient W si le processus n'a pas de pages résidentes.
     * Le troisième champ contient N si le processus a une valeur de gentillesse positive (nice, champ NI).
     **/
    private final String stat;              // 进程状态
    private final String start;             // 启动时间
    private final String cpuTime;           //
    private final String command;           // 命令行
    private final String desc;              // 描述

    Proc(String user, int pid, float cpuPercentage, float memPercentage, int vsz, int rss,
         String tty, String stat, String start, String cpuTime, String command, String desc) {
        this.user = user;
        this.pid = pid;
        this.cpuPercentage = cpuPercentage;
        this.memPercentage = memPercentage;
        this.vsz = vsz;
        this.rss = rss;
        this.tty = tty;
        this.stat = stat;
        this.start = start;
        this.cpuTime = cpuTime;
        this.command = command;
        this.desc = desc;
    }

    /**
     * 获取进行的启动用户
     *
     * @return 用户名称或标识
     */
    public String getUser() {
        return user;
    }

    /**
     * 获取进程 ID
     *
     * @return PID
     */
    public int getPid() {
        return pid;
    }

    /**
     * 获取进程的 CPU 使用率
     *
     * @return CPU使用率
     */
    public float getCpuPercentage() {
        return cpuPercentage;
    }

    /**
     * 获取内存使用率
     *
     * @return 内存使用率
     */
    public float getMemPercentage() {
        return memPercentage;
    }

    /**
     * 虚拟内存大小
     */
    public int getVsz() {
        return vsz;
    }

    /**
     * 内存驻留集大小
     */
    public int getRss() {
        return rss;
    }

    public String getTty() {
        return tty;
    }

    public String getStat() {
        return stat;
    }

    public String getStart() {
        return start;
    }

    public String getCpuTime() {
        return cpuTime;
    }

    public String getCommand() {
        return command;
    }

    public String getDesc() {
        return desc;
    }

    /**
     * 结束当前进程
     */
    public void kill() {
        ProcManager.getInstance().kill(pid);
    }

    @Override
    public String toString() {
        StringBuilder buff = new StringBuilder();
        buff.append(user).append("\t")
                .append(pid).append("\t")
                .append(cpuPercentage).append("\t")
                .append(memPercentage).append("\t")
                .append(vsz).append("\t")
                .append(rss).append("\t")
                .append(tty).append("\t")
                .append(stat).append("\t")
                .append(start).append("\t")
                .append(cpuTime).append("\t")
                .append(command).append("\t")
                .append(desc).append("\t");
        return buff.toString();
    }

    /**
     * 给定 PID 进程是否存在
     *
     * @param pid PID
     */
    public static boolean has(final int pid) {
        return hasAny(pid);
    }

    /**
     * 是否存在给定的 PID 中的任意一个
     *
     * @param pids PID 列表
     * @return 是否存在任意一个 PID, 如果 pids 为空返回 false
     */
    public static boolean hasAny(final int... pids) {
        return null != pids && 0 < pids.length && null != find(new Condition<Proc>() {
            @Override
            public boolean value(Proc value) {
                return ArrayUtils.has(pids, value.getPid());
            }
        });
    }

    /**
     * 获取给定 PID 的进程信息
     *
     * @param pid PID
     * @return PID 对应的进程信息
     */
    public static Proc get(final int pid) {
        return find(new Condition<Proc>() {
            @Override
            public boolean value(Proc value) {
                return value.getPid() == pid;
            }
        });
    }

    /**
     * 获取给定正则表达式能匹配到命令行的第一个进程信息
     *
     * @param commandRegex 命令行匹配的正则表达式
     * @return 第一个匹配到的进程信息, 如果不存在返回 null
     */
    public static Proc find(String commandRegex) {
        return find(Pattern.compile(commandRegex));
    }

    public static Proc find(final Pattern commandPattern) {
        return find(new Condition<Proc>() {
            @Override
            public boolean value(Proc value) {
                return commandPattern.matcher(value.getCommand()).find();
            }
        });
    }

    /**
     * 获取给定符合给定 Condition 的第一个进程信息
     *
     * @param condition 进程匹配条件
     * @return 第一个匹配到的进程信息, 如果不存在返回 null
     */
    public static Proc find(final Condition<Proc> condition) {
        Iterator<Proc> procs = gatherProcesses(new Processor<Proc>() {
            @Override
            public boolean process(Proc proc) {
                return !condition.value(proc);
            }
        }).iterator();
        return procs.hasNext() ? procs.next() : null;
    }

    /**
     * 获取给定正则表达式能匹配到命令行的所有进程信息
     *
     * @param commandRegex 命令行匹配的正则表达式
     * @return 匹配到的所有进程信息
     */
    public static Iterator<Proc> query(String commandRegex) {
        return query(Pattern.compile(commandRegex));
    }

    /**
     * 获取给定正则表达式能匹配到命令行的所有进程信息
     *
     * @param commandPattern 命令行匹配的正则表达式
     * @return 匹配到的所有进程信息
     */
    public static Iterator<Proc> query(final Pattern commandPattern) {
        return query(new Condition<Proc>() {
            @Override
            public boolean value(Proc value) {
                return commandPattern.matcher(value.getCommand()).find();
            }
        });
    }

    /**
     * 获取给定符合给定 Condition 的所有进程信息
     *
     * @param condition 进程匹配条件
     * @return 匹配到的所有进程信息
     */
    public static Iterator<Proc> query(final Condition<Proc> condition) {
        return new Iterator<Proc>() {
            private LazyValue<Iterator<Proc>> procs = new LazyValue<Iterator<Proc>>() {
                @Override
                protected Iterator<Proc> compute() {
                    return getProcesses().iterator();
                }
            };
            private Proc next = null;

            @Override
            public boolean hasNext() {
                if (null == next) {
                    Iterator<Proc> procs = this.procs.getValue();
                    while (procs.hasNext()) {
                        Proc n = procs.next();
                        if (condition.value(n)) {
                            next = n;
                            break;
                        }
                    }
                }
                return null != next;
            }

            @Override
            public Proc next() {
                if (hasNext()) {
                    Proc proc = next;
                    next = null;
                    return proc;
                }
                throw new NoSuchElementException();
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    /**
     * 获取当前所有的进程信息
     */
    public static Iterable<Proc> getProcesses() {
        return new Iterable<Proc>() {
            @SuppressWarnings("unchecked")
            private LazyValue<Iterator<Proc>> processes = new LazyValue<Iterator<Proc>>() {
                @Override
                protected Iterator<Proc> compute() {
                    return gatherProcesses(Processor.TRUE).iterator();
                }
            };

            @Override
            public Iterator<Proc> iterator() {
                return processes.getValue();
            }
        };
    }

    /**
     * 获取当前 JVM PID
     */
    public static int getCurrentProcessId() {
        return ProcManager.getInstance().getCurrentProcessId();
    }

    /**
     * 获取给定 Process 的 PID
     * <p>
     * {@link ProcManager#getProcessId(Process)}
     *
     * @param process 进程对象
     * @return PID
     */
    public static int getProcessId(Process process) {
        return ProcManager.getInstance().getProcessId(process);
    }

    /**
     * 结束给定 PID 进程
     * <p>
     * {@link ProcManager#kill(int)}
     *
     * @param pid 要结束的进程 PID
     */
    public static void kill(int pid) {
        ProcManager.getInstance().kill(pid);
    }

    /**
     * 提取系统进程信息
     *
     * @param processor 进程信息处理器
     */
    private static Iterable<Proc> gatherProcesses(Processor<Proc> processor) {
        try {
            if (Platform.isWindows()) {
                return gatherWinProcesses(processor);
            } else if (Platform.isLinux() || Platform.isMac()) {
                return gatherUnixProcesses(processor);
            }
        } catch (IOException ex) {
            // TODO ignore
        }
        throw new UnsupportedOperationException();
    }

    /**
     * 提取 Unix 系统进程信息
     *
     * @param processor 进程信息处理器
     * @throws IOException
     */
    private static Iterable<Proc> gatherUnixProcesses(Processor<Proc> processor) throws IOException {
        Set<Proc> processes = new HashSet<Proc>();

        Process process = Runtime.getRuntime().exec(new String[]{"/bin/sh", "-c", "ps wmux"});
        final Scanner sc = new Scanner(process.getInputStream(), "utf-8");
        sc.useRadix(10);
        sc.useLocale(Locale.US);
        sc.nextLine();

        while (sc.hasNext()) {
            String user = sc.next();
            int pid = sc.nextInt();
            float cpuPercentage = Float.parseFloat(sc.next().replace(",", "."));
            float memPercentage = Float.parseFloat(sc.next().replace(",", "."));
            int vsz = sc.nextInt();
            int rss = sc.nextInt();
            String tty = sc.next();
            String stat = sc.next();
            String start = null;
            if (sc.hasNextInt()) {
                start = sc.next() + ' ' + sc.next();
            } else {
                start = sc.next();
            }
            String cpuTime = sc.next();
            String command = sc.nextLine();

            Proc proc = new Proc(user, pid, cpuPercentage, memPercentage, vsz, rss, tty, stat, start, cpuTime, command, null);
            processes.add(proc);

            if (!processor.process(proc)) {
                break;
            }
        }

        return processes;
    }

    /**
     * 提取 Windows 系统进程信息
     *
     * @param processor 进程信息处理器
     * @throws IOException
     */
    private static Iterable<Proc> gatherWinProcesses(Processor<Proc> processor) throws IOException {
        Set<Proc> processes = new HashSet<Proc>();
        Map<Integer, String> commands = new HashMap<Integer, String>();

        // wmic 不包含 用户等信息, tasklist 没有命令行..
        Process process;
        Scanner sc;
        try {
            process = Runtime.getRuntime().exec(new String[]{"wmic", "process", "get", "CommandLine,ProcessId"});
            InputStream is = process.getInputStream();
            sc = new Scanner(is, "cp936");
            sc.useRadix(10);
            sc.useLocale(Locale.US);
            sc.nextLine();  // title

            while (sc.hasNext()) {
                String commandLine = "";
                while (!sc.hasNextInt()) {
                    commandLine += ' ' + sc.next();
                }
                commandLine = commandLine.trim();
                int pid = sc.nextInt();
                // sc.nextLine();

                commands.put(pid, commandLine);
            }
            sc.close();
        } catch (IOException ex) {
            // TODO ignore
        }

        //
        process = Runtime.getRuntime().exec(new String[]{"cmd", "/c", "tasklist /V"});
        sc = new Scanner(process.getInputStream(), "cp936");
        sc.nextLine();
        sc.nextLine();
        sc.nextLine();
        while (sc.hasNext()) {
            String image = "";
            while (!sc.hasNextInt()) {
                image += " " + sc.next();
            }
            image = image.trim();
            int pid = sc.nextInt();
            String session = sc.next();
            if ("Console".equals(session) || "Services".equals(session)) {
                sc.next();  // skip #session
            }
            String memory = sc.next();
            float cpuPercentage = -1;
            float memPercentage = -1;
            int vsz = Integer.parseInt(memory.replace(".", "").replace(",", "").replace("ÿ", ""));
            int rss = -1;
            String tty = null;

            sc.next();  // skip status
            sc.skip(WINDOWS_STATE_PATTERN);
            String stat = null;

            String user = sc.next();
            while (!sc.hasNext(WINDOWS_CPU_TIME_PATTERN)) {
                user += ' ' + sc.next();
            }

            String start = null;
            String cpuTime = sc.next();
            String desc = sc.nextLine().trim();

            String command = commands.get(pid);
            if (null == command || "".equals(command)) {
                command = image;
            }
            Proc proc = new Proc(user, pid, cpuPercentage, memPercentage, vsz, rss, tty, stat, start, cpuTime, command, desc);
            processes.add(proc);

            if (!processor.process(proc)) {
                break;
            }
        }
        sc.close();

        return processes;
    }
}
