/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.util;

import org.ponly.common.reflect.Reflect;

import java.io.*;
import java.net.*;
import java.nio.charset.Charset;
import java.security.CodeSource;
import java.util.Properties;

/**
 * class path 资源加载工具类
 *
 * @author vacoor
 */
@SuppressWarnings("unused")
public abstract class Resources {
    public static final String CLASSPATH_PREFIX = "classpath:";

    public static InputStream getResourceAsStream(String resource) {
        URL url = getResource(resource);
        try {
            return null != url ? url.openStream() : null;
        } catch (IOException e) {
            return null;
        }
    }

    public static File getResourceAsFile(String resource) {
        URL url = getResource(resource);
        return null != url ? toFile(url) : null;
    }

    public static Properties getResourceAsProperties(String resource) {
        InputStream in = getResourceAsStream(resource);
        if (null != in) {
            Properties props = new Properties();
            try {
                props.load(in);
            } catch (IOException e) {
                throw new IllegalStateException("cannot load resource as properties: " + resource);
            } finally {
                close(in);
            }
            return props;
        }
        return null;
    }

    public static Properties getResourceAsProperties(String resource, Charset charset) {
        Properties props = null;
        InputStream in = getResourceAsStream(resource);

        if (null != in) {
            charset = null != charset ? charset : Charset.defaultCharset();
            Reader reader = new InputStreamReader(in, charset);
            props = new Properties();
            try {
                props.load(reader);
            } catch (IOException e) {
                throw new IllegalStateException("cannot load resource as properties: " + resource);
            } finally {
                close(reader);
                close(in);
            }
        }
        return props;
    }

    public static URL getResource(String resource) {
        if (resource.startsWith(CLASSPATH_PREFIX)) {
            return getClassPathResource(resource.substring(CLASSPATH_PREFIX.length()));
        }
        try {
            return new URL(resource);
        } catch (MalformedURLException e) {
            try {
                return new File(resource).toURI().toURL();
            } catch (MalformedURLException e1) {
                return null;
            }
        }
    }

    public static File toFile(URL url) {
        if (!"file".equals(url.getProtocol())) {
            throw new IllegalArgumentException("cannot be resolved to absolute file path " + "because it does not reside in the file system: " + url);
        }
        try {
            return new File(new URI(url.toExternalForm().replace(" ", "%20")).getSchemeSpecificPart());
        } catch (URISyntaxException e) {
            return new File(url.getFile());
        }
    }

    private static void close(Closeable closeable) {
        if (null != closeable) {
            try {
                closeable.close();
            } catch (IOException e) {
                // ignore
            }
        }
    }

    private static URL getClassPathResource(String resource) {
        resource = "/".equals(resource) ? "." : (resource.startsWith("/") ? resource.substring(1) : resource);
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        cl = null != cl ? cl : Reflect.getGrandCallerClass().getClassLoader();

        return cl.getResource(resource);
    }

    /**
     * 返回给定 class 的基本目录在文件系统中的 location
     * <p/>
     * 如果 clazz 在文件系统中则返回 classpath 的标准路径
     * 如果 clazz 在 jar 中, 则返回 jar 在文件系统中的所处目录的标准路径
     * 如果无法获取返回 null
     */
    public static File getClassBaseLocation(Class<?> clazz) {
        CodeSource codeSource = clazz.getProtectionDomain().getCodeSource();
        File loc = null;

        try {
            if (null != codeSource && null != codeSource.getLocation()) {
                loc = new File(codeSource.getLocation().toURI());
            } else {
                String path = clazz.getResource(clazz.getSimpleName() + ".class").getPath();

                int startIndex = path.indexOf(":") + 1;
                int endIndex = path.indexOf("!");
                if ((1 > startIndex) || (endIndex == -1)) {
                    throw new IllegalStateException("Class " + clazz.getSimpleName() + " is located not within a jar: " + path);
                }
                String jarFilePath = path.substring(startIndex, endIndex);
                jarFilePath = URLDecoder.decode(jarFilePath, "UTF-8");
                loc = new File(jarFilePath).getParentFile();
            }
        } catch (UnsupportedEncodingException ignore) {
        } catch (URISyntaxException ignore) {
        }
        return loc;
    }

    private Resources() {
    }
}
