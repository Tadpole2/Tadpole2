/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.io;

import org.ponly.common.codec.Hex;
import org.ponly.common.util.Throwables;

import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 信息摘要流
 * <p>
 * 避免文件过大读取为 byte[] 时内存溢出
 */
public class MessageDigestOutputStream extends OutputStream {
    private MessageDigest digester;
    private byte[] hashed;
    private String hexEncoded;
    private volatile boolean hasContent;

    public static MessageDigestOutputStream of(String algorithm) {
        return new MessageDigestOutputStream(algorithm);
    }

    public MessageDigestOutputStream(String algorithm) {
        if (algorithm == null) {
            throw new NullPointerException("algorithm argument cannot be null.");
        }

        try {
            digester = MessageDigest.getInstance(algorithm);
            digester.reset();
        } catch (NoSuchAlgorithmException e) {
            Throwables.rethrowRuntimeException(e);
        }
    }

    @Override
    public void write(int b) throws IOException {
        digester.update((byte) b);
        if (!hasContent) {
            hasContent = true;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        digester.update(b, off, len);
        if (!hasContent) {
            hasContent = true;
        }
    }

    /**
     * 获取当前输出流的 Hash 值
     *
     * @return Hash值
     */
    public byte[] getHash() {
        if (!hasContent) {
            return new byte[0];
        }

        if (hashed == null) {
            hashed = digester.digest();
        }
        byte[] copy = new byte[hashed.length];
        System.arraycopy(hashed, 0, copy, 0, hashed.length);
        return copy;
    }

    /**
     * 获取当前输出流的 Hash 值的16进制形式
     *
     * @return Hash值
     */
    public String getHashAsHex() {
        if (hexEncoded == null) {
            hexEncoded = Hex.encode(getHash());
        }
        return hexEncoded;
    }
}
