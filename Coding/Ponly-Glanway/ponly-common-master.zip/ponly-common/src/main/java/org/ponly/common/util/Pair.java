/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */

package org.ponly.common.util;

/**
 */
public class Pair<F, S> {

    protected F first;
    protected S second;

    public Pair() {
    }

    public Pair(F first, S second) {
        this.first = first;
        this.second = second;
    }

    /**
     * Sets first.
     */
    public void setFirst(F first) {
        this.first = first;
    }

    /**
     * Returns first.
     */
    public F getFirst() {
        return first;
    }

    /**
     * Returns second.
     */
    public S getSecond() {
        return second;
    }

    /**
     * Sets second.
     */
    public void setSecond(S second) {
        this.second = second;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Pair)) {
            return false;
        }
        Pair that = (Pair) o;

        Object n1 = getFirst();
        Object n2 = that.getFirst();

        if (n1 == n2 || (n1 != null && n1.equals(n2))) {
            Object v1 = getSecond();
            Object v2 = that.getSecond();
            if (v1 == v2 || (v1 != null && v1.equals(v2))) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (first == null ? 0 : first.hashCode()) ^
                (second == null ? 0 : second.hashCode());
    }

    @Override
    public String toString() {
        return "<" + this.first + "," + this.second + ">";
    }
}