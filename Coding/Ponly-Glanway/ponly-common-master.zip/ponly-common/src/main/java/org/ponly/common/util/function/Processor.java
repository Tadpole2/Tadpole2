/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.util.function;

/**
 * 处理器函数接口, 用于处理数据直到返回 false, 停止处理
 *
 * @param <T> Input value type.
 */
public interface Processor<T> {
    Processor TRUE = new Processor() {
        @Override
        public boolean process(Object o) {
            return true;
        }
    };

    /**
     * @param t consequently takes value of each element of the set this processor is passed to for processing.
     * @return {@code true} to continue processing or {@code false} to stop.
     */
    boolean process(T t);
}
