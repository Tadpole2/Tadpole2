/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.reflect;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

/**
 * 类型引用
 * <p>
 * java 中无法传递泛型类型, 该类主要利用类定义泛型不擦除来显式传递以及获取泛型类型
 * eg: new TypeReference&lt;List&lt;String&gt;&gt;(){}
 *
 * @author vacoor
 */
public abstract class TypeReference<T> {
    protected final Type type;

    protected TypeReference() {
        Type superClass = getClass().getGenericSuperclass();

        if (superClass instanceof Class<?>) { // miss type param, should never happen
            throw new IllegalStateException("Internal error: TypeReference constructed without actual type information");
        }

        type = ((ParameterizedType) superClass).getActualTypeArguments()[0];

        if (type instanceof TypeVariable<?>) {
            throw new IllegalStateException("Internal error: TypeReference constructed without actual type information");
        }
    }

    /**
     * 获取当前引用的类型
     */
    public Type getType() {
        return type;
    }
}
