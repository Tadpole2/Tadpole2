/**
 * Base64, Hex, MOD 等编码/解码
 *
 * @author vacoor
 */
package org.ponly.common.codec;