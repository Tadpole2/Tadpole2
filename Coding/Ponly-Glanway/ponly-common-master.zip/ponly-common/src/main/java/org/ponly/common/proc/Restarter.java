package org.ponly.common.proc;

import org.ponly.common.util.StreamRedirector;
import org.ponly.common.util.StringUtils;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * 当前 JVM 重启工具类
 *
 * @author vacoor
 */
public abstract class Restarter {
    private static final String SUN_JAVA_COMMAND = "sun.java.command";
    private static final String CLASS_PATH_OPT = "-classpath";

    public static void restart() throws IOException {
        String command = System.getProperty(SUN_JAVA_COMMAND);
        StringTokenizer st = new StringTokenizer(command, " ");
        List<String> args = new ArrayList<String>();
        while (st.hasMoreElements()) {
            args.add(st.nextToken());
        }
        String clazz = args.remove(0);
        runMainClassInProcess(clazz, args.toArray(new String[args.size()]));
    }

    /**
     * 在先进程中运行一个包含 main 方法的类
     *
     * @param clazz main 方法所在类
     * @param args  main 方法参数
     */
    public static void runMainClassInProcess(String clazz, String... args) throws IOException {
        final RuntimeMXBean mx = ManagementFactory.getRuntimeMXBean();
        final List<String> inputArgs = mx.getInputArguments();      // 启动输入参数 -D, -agent 等参数(不包含 class path, main)
        final String libraryPath = mx.getLibraryPath();             // -Djava.library.path=
        // final String bootClassPath = mx.getBootClassPath();      // -Dsun.boot.class.path
        final String classpath = mx.getClassPath();                 // 获取 classpath

        final String javaExecutableName = System.getProperty("os.name", "").toLowerCase().contains("windows") ? "java.exe" : "java";
        String javaExecutable = null;
        // String javaVmExecutablePath = System.getProperty("java.home") + File.separator + "bin" + File.separator + "java";
        // String classpath = System.getProperty("java.class.path");
        // final Process process = Runtime.getRuntime().exec("cmd " + javaVmExecutablePath + " -cp " + classpath + " com.intellij.idea.Main");

        // 查找 java 可执行文件路径: 在 library path 中查找
        for (String path : StringUtils.tokenize(libraryPath, File.pathSeparator)) {
            File javaExecutableFile = new File(path, javaExecutableName);
            if (javaExecutableFile.exists() && javaExecutableFile.isFile() && javaExecutableFile.canExecute()) {
                javaExecutable = javaExecutableFile.getAbsolutePath();
                break;
            }
        }
        if (null == javaExecutable) {
            File javaExecutableFile = new File(System.getProperty("java.home") + File.separator + "bin", javaExecutableName);
            if (javaExecutableFile.exists() && javaExecutableFile.isFile() && javaExecutableFile.canExecute()) {
                javaExecutable = javaExecutableFile.getAbsolutePath();
            }
        }
        if (null == javaExecutable) {
            javaExecutable = javaExecutableName;
        }

        Command builder = new Command(javaExecutable);
        List<String> newInputArgs = new ArrayList<String>();
        // 为了测试，防止端口冲突
        /*
        for (String inputArg : inputArgs) {
            if (!inputArg.startsWith("-agentlib")) {
                newInputArgs.add(inputArg);
            } else {
                System.out.println("skip:" + inputArg);
            }
        }
        builder.addRawArgs(newInputArgs);
        */
        builder.addRawArgs(inputArgs);
        builder.addArgs(CLASS_PATH_OPT).addRawArgs(classpath);

        builder.addArg(clazz);
        if (null != args) {
            builder.addArgs(args);
        }

        ProcessBuilder bu = new ProcessBuilder(builder.getArgs());
        Process proc = bu.start();
        new Thread(new StreamRedirector(proc.getInputStream(), System.out)).start();
        new Thread(new StreamRedirector(proc.getErrorStream(), System.err)).start();

        System.exit(0);

        try {
            System.out.println("exit:" + proc.waitFor());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
