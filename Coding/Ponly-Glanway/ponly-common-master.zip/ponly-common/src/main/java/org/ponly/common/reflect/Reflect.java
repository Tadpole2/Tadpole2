package org.ponly.common.reflect;

import com.google.common.collect.Lists;
import org.ponly.common.util.Primitives;
import org.ponly.common.util.StringUtils;
import org.ponly.common.util.Throwables;

import java.lang.reflect.*;
import java.util.Arrays;
import java.util.List;

/**
 * 反射工具类
 *
 * @author vacoor
 */
public class Reflect {
    private final Object target;
    private final Class<?> type;

    private Reflect(Object target) {
        this.target = target;
        this.type = target instanceof Class<?>
                ? (Class<?>) target
                : (null != target ? target.getClass() : Object.class);
    }

    /**
     * 获取内部维护的对象
     *
     * @param <Target> 内部维护的对象类型
     * @return 内部维护的对象
     */
    @SuppressWarnings("unchecked")
    public <Target> Target get() {
        return (Target) target;
    }

    /**
     * 使用给定的参数创建一个新的实例
     *
     * @param args 构造器参数
     * @return 新实例
     */
    public Reflect create(Object... args) {
        return create(typeof(args), args);
    }

    /**
     * 使用给定的参数类型和参数创建一个新实例
     *
     * @param argTypes 参数类型
     * @param args     参数
     * @return 新实例
     */
    public Reflect create(Class<?>[] argTypes, Object... args) {
        Constructor<?> ctor = findConstructor(type, argTypes);
        return from(call(ctor, args));
    }

    public <Return> Return call(String method, Object... args) {
        return call(method, typeof(args), args);
    }

    public <Return> Return call(String method, Class<?>[] argTypes, Object... args) {
        Method invoker = findMethod(type, method, argTypes);
        return call(invoker, target, args);
    }

    /**
     * 获取给定字段值的 {@link Reflect} 对象
     *
     * @param field 字段名
     * @return 字段值的 {@link Reflect} 对象
     */
    public Reflect field(String field) {
        return from(get(field));
    }

    /**
     * 获取当前包装对象的给定 property 值的 {@link Reflect} 对象
     *
     * @param property property
     * @return property 值的 {@link Reflect} 对象
     */
    public Reflect property(String property) {
        if (!StringUtils.hasText(property)) {
            throw new IllegalArgumentException("illegal property name: " + property);
        }
        String suffix = Character.toUpperCase(property.charAt(0)) + property.substring(1);
        Object ret;
        try {
            ret = call("get" + suffix);
        } catch (IllegalStateException ignore) {
            try {
                ret = call("is" + suffix);
            } catch (IllegalStateException ignore2) {
                throw new IllegalStateException("Method not found: get" + suffix + "/is" + suffix);
            }
        }
        return from(ret);
    }

    /**
     * 设置当前包装对象的给定 property 的值, 并返回当前 Reflect 对象
     *
     * @param property property
     * @param value    property 值
     * @return 当前 Reflect 对象
     */
    public Reflect property(String property, Object value) {
        if (!StringUtils.hasText(property)) {
            throw new IllegalArgumentException("illegal property name: " + property);
        }
        String method = "set" + Character.toUpperCase(property.charAt(0)) + property.substring(1);
        call(method, value);
        return this;
    }

    /**
     * 获取给定字段值
     *
     * @param field   字段名称
     * @param <Value> 字段值类
     * @return 字段值
     */
    @SuppressWarnings("unchecked")
    public <Value> Value get(String field) {
        try {
            return (Value) findField(type, field).get(target);
        } catch (IllegalAccessException ex) {
            return handleReflectionException(ex);
        }
    }

    /**
     * 设置给定字段的值
     *
     * @param field 字段名称
     * @param value 字段值
     * @return 当前 {@link Reflect} 对象
     */
    public Reflect set(String field, Object value) {
        try {
            findField(type, field).set(target, value);
        } catch (Exception ex) {
            handleReflectionException(ex);
        }
        return this;
    }

    /**
     * 获取给定索引对应值的 {@link Reflect} 对象
     *
     * @param index 索引
     * @return 索引对应值的 {@link Reflect}
     */
    public Reflect index(int index) {
        return from(get(index));
    }

    /**
     * 获取给定索引对应值
     *
     * @param index 索引
     * @return 索引对应值
     */
    @SuppressWarnings("unchecked")
    public <Element> Element get(int index) {
        Object ret = null;
        if (null != target) {
            if (type.isArray()) {
                int len = Array.getLength(target);
                ret = index < len ? Array.get(target, index) : null;
            } else if (target instanceof List<?>) {
                List<?> seq = (List<?>) target;
                ret = index < seq.size() ? seq.get(index) : null;
            } else {
                throw new IllegalStateException("target is not sequence: " + target);
            }
        }
        return (Element) ret;
    }

    /**
     * 设置给定索引对应值
     *
     * @param index 索引
     * @param value 索引对应值
     * @return 当前 {@link Reflect}
     */
    @SuppressWarnings("unchecked")
    public Reflect set(int index, Object value) {
        if (type.isArray()) {
            Array.set(target, index, value);
        } else if (target instanceof List<?>) {
            List<Object> seq = (List<Object>) target;
            for (int i = seq.size() - 1; i <= index; i++) {
                seq.add(null);
            }
            seq.set(index, value);
        } else {
            throw new IllegalStateException("target is not sequence: " + target);
        }
        return this;
    }

    /**
     * 使用给定对象创建一个 {@link Reflect}
     *
     * @param target 目标对象
     * @return {@link Reflect}
     */
    public static Reflect from(Object target) {
        return new Reflect(target);
    }

    /**************************************
     *         STATIC METHODS
     **************************************/

    /**
     * 设置 {@link AccessibleObject} 为可访问
     *
     * @param accessible {@link AccessibleObject}
     * @param <T>        {@link AccessibleObject} 类型
     * @return 返回传入的 {@link AccessibleObject}
     */
    public static <T extends AccessibleObject> T accessible(T accessible) {
        if (null == accessible) {
            return null;
        }
        if (accessible instanceof Member) {
            Member member = (Member) accessible;

            /*-
             * 如果 member 是 public 且定义 member 的类是 public
             */
            if (Modifier.isPublic(member.getModifiers()) &&
                    Modifier.isPublic(member.getDeclaringClass().getModifiers())) {
                return accessible;
            }
        }
        if (!accessible.isAccessible()) {
            accessible.setAccessible(true);
        }
        return accessible;
    }

    /**
     * 获取给定类中的字段<p>
     * 该方法按照以下顺序查找给定名称的字段: 1. 给定类的 public 字段 2. 给定类定义的所有字段 3. 所有祖先类中定义的字段,
     * 如果一直没有查找到则抛出 {@link IllegalStateException}
     *
     * @param clazz 目标类
     * @param name  字段名称
     * @return 查找到的字段
     */
    public static Field findField(Class<?> clazz, String name) {
        NoSuchFieldException exception = null;
        try {
            // 获取所有 public 字段 (当前类,祖先, 接口)
            return clazz.getField(name);
        } catch (NoSuchFieldException e) {
            do {
                try {
                    return accessible(clazz.getDeclaredField(name));
                } catch (NoSuchFieldException e1) {
                    exception = null != exception ? exception : e1;
                }

                clazz = clazz.getSuperclass();
            } while (null != clazz);
        }
        return handleReflectionException(exception);
    }

    /**
     * 查找能够匹配给定参数的最佳构造器
     *
     * @param clazz              目标类
     * @param applyArgumentTypes 参数类型
     * @param <T>                实例类型
     * @return 最佳匹配构造器
     */
    @SuppressWarnings("unchecked")
    public static <T> Constructor<T> findConstructor(Class<?> clazz, Class<?>... applyArgumentTypes) {
        try {
            return (Constructor<T>) clazz.getConstructor(applyArgumentTypes);
        } catch (NoSuchMethodException ex) { /* ignore */ }

        Constructor<T>[] constructors = (Constructor<T>[]) clazz.getConstructors();
        try {
            return findConstructor(constructors, applyArgumentTypes);
        } catch (NoSuchMethodException e) {
            try {
                constructors = (Constructor<T>[]) clazz.getDeclaredConstructors();
                return accessible(findConstructor(constructors, applyArgumentTypes));
            } catch (NoSuchMethodException ex) {
                return handleReflectionException(ex);
            }
        }
    }

    /**
     * 获取给定参数类型能匹配的最佳构造器
     *
     * @param constructors 构造器列表
     * @return 最佳构造器
     * @throws NoSuchMethodException
     */
    public static <T> Constructor<T> findConstructor(Constructor<T>[] constructors, Class<?>... applyArgumentTypes) throws NoSuchMethodException {
        Constructor<T> bestCandidate = null;    // 最佳方法
        Class<?>[] bestTypes = null;            // 最佳参数类型
        List<Constructor<T>> candidates = Lists.newArrayList();

        // 遍历所有构造器
        for (Constructor<T> ctor : constructors) {
            Class[] types = ctor.getParameterTypes();

            // 完全相同直接返回
            if (canApply(applyArgumentTypes, types, false)) {
                return ctor;
            }

            // 如果是可变参数, 将可变参数转换
            if (ctor.isVarArgs()) {
                // 固定参数类型长度
                final int len = types.length - 1;

                // 可能包含可变参数
                if (len <= applyArgumentTypes.length) {
                    // 可变参数长度扩充到和应用的参数一样长
                    Class<?>[] newTypes = new Class<?>[applyArgumentTypes.length];
                    System.arraycopy(types, 0, newTypes, 0, len);

                    // 实际传递的参数类型中包含可变参数类型
                    if (len < applyArgumentTypes.length) {
                        Arrays.fill(newTypes, len, applyArgumentTypes.length - len + 1, types[len].getComponentType());
                    }
                    types = newTypes;
                }
            }

            // 参数不兼容
            if (!canApply(applyArgumentTypes, types)) {
                continue;
            }

            // 如果最佳匹配为空, 直接设置
            if (null == bestCandidate) {
                bestCandidate = ctor;
                bestTypes = types;
            } else {
                /**
                 * 这里需要对以下情况处理:
                 * <A extends Serializable> test(A a);
                 * <B extends CharSequence> test(B b);
                 * args = [String.class]
                 */
                boolean isSubclass = canApply(types, bestTypes);       // 当前参数是最佳参数的的子类(具体化)
                boolean isSuperclass = canApply(bestTypes, types);     // 当前参数是最佳参数的父类

                // 不是合成方法
                if (isSuperclass && isSubclass) {
                    isSubclass = !ctor.isSynthetic();
                    isSuperclass = !bestCandidate.isSynthetic();
                }

                if (ctor.isVarArgs() != bestCandidate.isVarArgs()) {
                    if (bestCandidate.isVarArgs()) {
                        bestCandidate = ctor;
                        bestTypes = types;
                    }
                } else {
                    if (isSuperclass == isSubclass) {
                        boolean bestTypeAccuratelyMatch = canApply(bestTypes, applyArgumentTypes, false);
                        boolean typesAccuratelyMatch = canApply(types, applyArgumentTypes, false);
                        // 不自动拆箱情况下都可以都不可以
                        if (bestTypeAccuratelyMatch == typesAccuratelyMatch) {
                            candidates.add(ctor);
                        } else if (typesAccuratelyMatch) {
                            candidates.clear();
                            bestCandidate = ctor;
                            bestTypes = types;
                        }
                    } else if (isSubclass) {
                        candidates.clear();
                        bestCandidate = ctor;
                        bestTypes = types;
                    }
                }
            }
        }

        if (!candidates.isEmpty()) {
            candidates.add(0, bestCandidate);
            throw new NoSuchMethodException("Ambiguous methods are found. " + candidates);
        }

        if (null == bestCandidate) {
            throw new NoSuchMethodException("Constructor is not found ");
        }

        return bestCandidate;
    }

    /**
     * 获取给定参数类型能匹配的最佳方法
     *
     * @param clazz         目标类
     * @param method        方法名称
     * @param applyArgTypes 参数类型
     * @return 最佳方法
     */
    public static Method findMethod(Class<?> clazz, String method, Class<?>... applyArgTypes) {
        NoSuchMethodException exception = null;
        try {
            return clazz.getMethod(method, applyArgTypes);
        } catch (NoSuchMethodException ex) { /* ignore */ }

        Method[] methods = clazz.getMethods();
        try {
            return findMethod(methods, method, applyArgTypes);
        } catch (NoSuchMethodException e) {
            do {
                try {
                    methods = clazz.getDeclaredMethods();
                    return accessible(findMethod(methods, method, applyArgTypes));
                } catch (NoSuchMethodException e1) {
                    if (null == exception) {
                        exception = e1;
                    }
                }

                clazz = clazz.getSuperclass();
            } while (null != clazz);
        }
        return handleReflectionException(exception);
    }

    /**
     * 获取给定参数类型能匹配的最佳方法
     *
     * @param methods       方法列表
     * @param methodName    方法名称
     * @param applyArgTypes 参数类型
     * @return 最佳方法
     * @throws NoSuchMethodException
     */
    public static Method findMethod(Method[] methods, String methodName, Class<?>... applyArgTypes) throws NoSuchMethodException {

        Method bestCandidate = null;       // 最佳方法
        Class<?>[] bestTypes = null;     // 最佳参数类型
        List<Method> candidates = Lists.newArrayList();

        // 遍历所有构造器
        for (Method method : methods) {
            if (!method.getName().equals(methodName)) {
                continue;
            }

            Class[] types = method.getParameterTypes();

            // 完全相同直接返回
            if (canApply(applyArgTypes, types, false)) {
                return method;
            }

            // 如果是可变参数, 将可变参数转换
            if (method.isVarArgs()) {
                // 固定参数类型长度
                final int len = types.length - 1;

                // 可能包含可变参数
                if (len <= applyArgTypes.length) {
                    // 可变参数长度扩充到和应用的参数一样长
                    Class<?>[] newTypes = new Class<?>[applyArgTypes.length];
                    System.arraycopy(types, 0, newTypes, 0, len);

                    // 实际传递的参数类型中包含可变参数类型
                    if (len < applyArgTypes.length) {
                        Arrays.fill(newTypes, len, applyArgTypes.length - len + 1, types[len].getComponentType());
                    }
                    types = newTypes;
                }
            }

            // 参数不兼容
            if (!canApply(applyArgTypes, types)) {
                continue;
            }

            // 如果最佳匹配为空, 直接设置
            if (null == bestCandidate) {
                bestCandidate = method;
                bestTypes = types;
            } else {
                /**
                 * 这里需要对以下情况处理:
                 * <A extends Serializable> test(A a);
                 * <B extends CharSequence> test(B b);
                 * args = [String.class]
                 */
                boolean isSubclass = canApply(types, bestTypes);       // 当前参数是最佳参数的的子类(具体化)
                boolean isSuperclass = canApply(bestTypes, types);     // 当前参数是最佳参数的父类

                // 不是合成方法
                if (isSuperclass && isSubclass) {
                    isSubclass = !method.isSynthetic();
                    isSuperclass = !bestCandidate.isSynthetic();
                }

                if (method.isVarArgs() != bestCandidate.isVarArgs()) {
                    if (bestCandidate.isVarArgs()) {
                        bestCandidate = method;
                        bestTypes = types;
                    }
                } else {
                    if (isSuperclass == isSubclass) {
                        boolean bestTypeAccuratelyMatch = canApply(bestTypes, applyArgTypes, false);
                        boolean typesAccuratelyMatch = canApply(types, applyArgTypes, false);
                        // 不自动拆箱情况下都可以都不可以
                        if (bestTypeAccuratelyMatch == typesAccuratelyMatch) {
                            candidates.add(method);
                        } else if (typesAccuratelyMatch) {
                            candidates.clear();
                            bestCandidate = method;
                            bestTypes = types;
                        }
                    } else if (isSubclass) {
                        candidates.clear();
                        bestCandidate = method;
                        bestTypes = types;
                    }
                }
            }
        }

        if (!candidates.isEmpty()) {
            candidates.add(0, bestCandidate);
            throw new NoSuchMethodException("Ambiguous methods are found. " + candidates);
        }

        if (null == bestCandidate) {
            throw new NoSuchMethodException("Method is not found: " + methodName + "(" + Arrays.toString(applyArgTypes) + ")");
        }

        return bestCandidate;
    }

    private static boolean canApply(Class<?>[] actualTypes, Class<?>[] declaredTypes) {
        return canApply(actualTypes, declaredTypes, true);
    }

    private static boolean canApply(Class<?>[] actualTypes, Class<?>[] declaredTypes, boolean autoboxing) {
        if (declaredTypes.length != actualTypes.length) {
            return false;
        }
        for (int i = 0; i < declaredTypes.length; i++) {
            if (!canApply(actualTypes[i], declaredTypes[i], autoboxing)) {
                return false;
            }
        }
        return true;
    }

    private static boolean canApply(Class<?> actualType, Class<?> declaredType, boolean autoboxing) {
        if (actualType == declaredType) {
            return true;
        } else if (null == declaredType) {     // 限制类型为 null, 实际类型不是 null
            return false;
        } else if (null == actualType) {    // 实际类型为 null, 限制类型不是基本数据类型即可兼容
            return !declaredType.isPrimitive();
        } else {
            if (autoboxing) {
                actualType = Primitives.wrap(actualType);
                declaredType = Primitives.wrap(declaredType);
            }
            return declaredType == actualType || declaredType.isAssignableFrom(actualType);
        }
    }

    /**
     * 使用给定的参数, 调用给定的构造器, 支持可变参数
     *
     * @param ctor       构造器
     * @param args       传递给构造器的参数
     * @param <Instance> 实例类型
     * @return 调用构造器创建的实例
     */
    public static <Instance> Instance call(Constructor<Instance> ctor, Object... args) {
        try {
            args = ctor.isVarArgs() ? makeVarArgs(ctor.getParameterTypes()) : args;
            return ctor.newInstance(args);
        } catch (Exception ex) {
            return handleReflectionException(ex);
        }
    }

    /**
     * 使用给定对象和参数调用给定的方法, 支持可变参数
     *
     * @param invoker  调用的方法
     * @param target   调用方法的对象
     * @param args     调用方法的参数
     * @param <Return> 方法返回值类型
     * @return 方法调用的返回值
     */
    @SuppressWarnings("unchecked")
    public static <Return> Return call(Method invoker, Object target, Object... args) {
        try {
            args = invoker.isVarArgs() ? makeVarArgs(invoker.getParameterTypes(), args) : args;
            return (Return) invoker.invoke(target, args);
        } catch (Exception ex) {
            return handleReflectionException(ex);
        }
    }

    /**
     * 根据跟定的可变参数方法的参数类型和调用参数创建一个符合可变参数类型的参数
     *
     * @param types 可变参数方法的参数类型
     * @param args  调用参数
     * @return 符合调用可变参数方法的参数
     */
    private static Object[] makeVarArgs(Class<?>[] types, Object... args) {
        Object[] invokeArgs = new Object[types.length];
        Object varArgs;

        if (1 > types.length || !types[types.length - 1].isArray()) {
            throw new IllegalStateException("argument types not contains varargs type");
        }

        // 实际参数长度小于固定参数长度
        if (args.length < types.length - 1) {
            throw new IllegalArgumentException("wrong number of arguments");
        } else if (args.length == types.length - 1) {   // 实际参数等于固定参数(没有传递可变参数), 创建用于可变参数的参数数组
            varArgs = Array.newInstance(types[types.length - 1].getComponentType(), 0);
        } else if (args.length == types.length) {       // 实际参数长度等于参数类型长度
            Object last = args[args.length - 1];

            // 如果最后一个参数是数组, 则不需要处理
            if (null != last && last.getClass().isArray()) {
                varArgs = last;
            } else {
                /*-
                 * 传递了可变参数, 但参数长度正好等于参数列表长度 且最后一个参数不是数组, 则转换为数组
                 */
                varArgs = Array.newInstance(types[types.length - 1].getComponentType(), 1);
                Array.set(varArgs, 0, args[args.length - 1]);
            }
        } else {
            /*-
             * 参数长度超过参数类型长度, 将固定参数长度之后的参数转换为可变参数数组
             */
            int varArgsLen = args.length - types.length + 1;
            varArgs = Array.newInstance(types[types.length - 1].getComponentType(), varArgsLen);

            // system copy 不会自动装箱拆箱
            // System.arraycopy(args, types.length - 1, varArgs, 0, varArgsLen);
            for (int i = 0; i < varArgsLen; i++) {
                Array.set(varArgs, i, args[types.length - 1 + i]);
            }
        }

        System.arraycopy(args, 0, invokeArgs, 0, types.length - 1); // 拷贝固定参数
        invokeArgs[types.length - 1] = varArgs;                     // 设置可变参数

        return invokeArgs;
    }

    /**
     * 获取给定参数的类型
     *
     * @param args 参数
     * @return 参数类型
     */
    private static Class<?>[] typeof(Object... args) {
        if (null == args) {
            return new Class<?>[0];
        }

        Class<?>[] types = new Class<?>[args.length];
        for (int i = 0; i < args.length; i++) {
            types[i] = null != args[i] ? args[i].getClass() : null;
        }
        return types;
    }

    /**
     * 处理反射异常
     *
     * @param ex  异常
     * @param <R> 返回类型
     * @return 始终抛出异常, 因此不会执行返回操作
     */
    private static <R> R handleReflectionException(Exception ex) {
        if (ex instanceof NoSuchFieldException) {
            throw new IllegalStateException("Field not found: " + ex.getMessage());
        }
        if (ex instanceof NoSuchMethodException) {
            throw new IllegalStateException("Method not found: " + ex.getMessage());
        }
        if (ex instanceof IllegalAccessException) {
            throw new IllegalStateException("Could not access constructor/field/method: " + ex.getMessage());
        }
        if (ex instanceof InstantiationException) {
            throw new IllegalStateException("Could not create instance:" + ex.getMessage());
        }
        if (ex instanceof InvocationTargetException) {
            handleInvocationTargetException((InvocationTargetException) ex);
        }
        if (ex instanceof RuntimeException) {
            throw (RuntimeException) ex;
        }
        throw new UndeclaredThrowableException(ex);
    }

    private static <R> R handleInvocationTargetException(InvocationTargetException ex) {
        return Throwables.rethrowRuntimeException(ex.getTargetException());
    }

    public static <T> Class<T> getGrandCallerClass() {
        return getGrandCallerClass(true);
    }

    public static <T> Class<T> getGrandCallerClass(boolean skipSystemClass) {
        int stackFrameCount = 3;
        Class<T> callerClass = findCallerClass(stackFrameCount);
        while (null != callerClass && skipSystemClass && null == callerClass.getClassLoader()) { // looks like a system class
            callerClass = findCallerClass(++stackFrameCount);
        }
        if (null == callerClass) {
            callerClass = findCallerClass(2);
        }
        return callerClass;
    }

    /**
     * Returns the class this method was called 'framesToSkip' frames up the caller hierarchy.
     * <p>
     * NOTE:
     * <b>Extremely expensive!
     * Please consider not using it.
     * These aren't the droids you're looking for!</b>
     */
    @SuppressWarnings("unchecked")
    public static <T> Class<T> findCallerClass(int framesToSkip) {
        try {
            Class<?>[] stack = HolderSecurityManager.INSTANCE.getStack();
            int indexFromTop = 1 + framesToSkip;
            return (Class<T>) (stack.length > indexFromTop ? stack[indexFromTop] : null);
        } catch (Exception e) {
            return null;
        }
    }

    public static StackTraceElement getGrandCallerStackTrace() {
        return getGrandCallerStackTrace(true);
    }

    public static StackTraceElement getGrandCallerStackTrace(boolean skipSystemClass) {
        int stackFrameCount = 3;
        StackTraceElement callerStackTrace = findCallerStackTrace(stackFrameCount);
        while (null != callerStackTrace && skipSystemClass
                // look like syste class
                && (callerStackTrace.isNativeMethod() || null == getClassLoader(callerStackTrace.getClassName()))) {
            callerStackTrace = findCallerStackTrace(++stackFrameCount);
        }
        if (null == callerStackTrace) {
            int len = new Throwable().getStackTrace().length;
            callerStackTrace = (new Throwable()).getStackTrace()[len - 1];
        }
        return callerStackTrace;
    }

    public static StackTraceElement findCallerStackTrace(int framesToSkip) {
        StackTraceElement[] stackTrace = (new Throwable()).getStackTrace();
        int indexFromTop = 1 + framesToSkip;
        return stackTrace.length > indexFromTop ? new Throwable().getStackTrace()[indexFromTop] : null;
    }

    private static ClassLoader getClassLoader(String className) {
        ClassLoader loader = null;
        try {
            loader = null != className ? Class.forName(className).getClassLoader() : null;
        } catch (ClassNotFoundException e) {
            // ignore
        }
        return loader;
    }

    private static class HolderSecurityManager extends SecurityManager {
        private static final HolderSecurityManager INSTANCE = new HolderSecurityManager();

        public Class<?>[] getStack() {
            return getClassContext();
        }
    }
}
