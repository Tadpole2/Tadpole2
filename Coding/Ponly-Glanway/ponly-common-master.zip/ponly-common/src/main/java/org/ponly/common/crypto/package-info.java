/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */

/**
 * JCE Hash/加密 简单封装工具类
 *
 * @author vacoor
 */
package org.ponly.common.crypto;