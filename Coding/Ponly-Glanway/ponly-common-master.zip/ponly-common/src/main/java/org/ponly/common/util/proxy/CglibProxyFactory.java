/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.util.proxy;

import net.sf.cglib.core.DefaultNamingPolicy;
import net.sf.cglib.core.NamingPolicy;
import net.sf.cglib.proxy.Callback;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;

/**
 * 使用 CGLIB 实现的代理工厂
 *
 * @author vacoor
 */
public class CglibProxyFactory implements ProxyFactory {
    public static final String ENHANCER_NAME = "net.sf.cglib.proxy.Enhancer";
    private static final Logger LOG = LoggerFactory.getLogger(CglibProxyFactory.class);
    private static final NamingPolicy NAMING_POLICY = new DefaultNamingPolicy() {
        @Override
        protected String getTag() {
            return "ByMuxCGLIB";//super.getTag();
        }
    };

    static {
        try {
            Class.forName(ENHANCER_NAME);
        } catch (Throwable e) {
            throw new IllegalStateException("CGLIB is not available. Add CGLIB to your classpath.", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @SuppressWarnings("unchecked")
    public <T> T getProxy(ClassLoader loader, Class<T> targetClass, InvocationHandler invocationHandler) {
        return (T) createProxy(loader, targetClass, invocationHandler);
    }


    /* *************************************************
     *
     * *************************************************/

    /**
     * 使用给定的 ClassLoader, Class, InvocationHandler 创建一个代理对象
     *
     * @param loader      用于创建代理的 {@link ClassLoader}
     * @param targetClass 代理对象的目标类型
     * @param handler     用于处理代理行为的 {@link InvocationHandler} 实现
     * @return 代理对象
     */
    public static Object createProxy(ClassLoader loader, Class<?> targetClass, InvocationHandler handler) {
        return createProxy(loader, targetClass, handler, Collections.<Class<?>>emptyList(), Collections.emptyList());
    }

    /**
     * 使用给定的 ClassLoader, Class, InvocationHandler 创建一个含有给定构造器类型的代理,并使用给定参数创建代理对象
     *
     * @param loader              用于创建代理的 {@link ClassLoader}
     * @param superclass          代理对象的超类类型
     * @param handler             用于处理代理行为的 {@link InvocationHandler} 实现
     * @param constructorArgTypes 构造器参数类型
     * @param constructorArgs     用户创建代理对象的构造参数
     * @return 代理对象
     */
    public static Object createProxy(ClassLoader loader, Class<?> superclass, InvocationHandler handler, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
        return createProxy(loader, superclass, createCallback(handler), constructorArgTypes, constructorArgs);
    }

    /**
     * 使用给定的 ClassLoader, Class, InvocationHandler 创建一个含有给定构造器类型的代理,并使用给定参数创建代理对象
     *
     * @param loader              用于创建代理的 {@link ClassLoader}
     * @param superclass          代理对象的超类类型
     * @param callback            用于处理代理行为的 {@link Callback} 实现
     * @param constructorArgTypes 构造器参数类型
     * @param constructorArgs     用户创建代理对象的构造参数
     * @return 代理对象
     */
    public static Object createProxy(ClassLoader loader, Class<?> superclass, Callback callback, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
        try {
            Enhancer enhancer = createEnhancer();
            enhancer.setClassLoader(loader);
            enhancer.setCallback(callback);
            if (superclass.isInterface()) {
                enhancer.setInterfaces(new Class<?>[]{superclass});
            } else {
                enhancer.setSuperclass(superclass);
            }

            Object enhanced;
            if (constructorArgTypes.isEmpty()) {
                enhanced = enhancer.create();
            } else {
                Class<?>[] typesArray = constructorArgTypes.toArray(new Class[constructorArgTypes.size()]);
                Object[] valuesArray = constructorArgs.toArray(new Object[constructorArgs.size()]);
                enhanced = enhancer.create(typesArray, valuesArray);
            }
            return enhanced;
        } catch (Exception ex) {
            throw new IllegalStateException("create cglib proxy failed: ", ex);
        }
            /*
        } catch (CodeGenerationException ex) {
            // throw new ConfigException("Could not generate CGLIB subclass of class [" + superclass + "]: " + "Common causes of this problem include using a final class or a non-visible class", ex);
        } catch (IllegalArgumentException ex) {
            // throw new ConfigException("Could not generate CGLIB subclass of class [" + superclass + "]: " + "Common causes of this problem include using a final class or a non-visible class", ex);
        } catch (Exception ex) {
            // TargetSource.getTarget() failed
            // throw new ConfigException("Unexpected exception", ex);
        }
        */
    }


    private static Enhancer createEnhancer() {
        Enhancer enhancer = new Enhancer();
        enhancer.setNamingPolicy(NAMING_POLICY);
        return enhancer;
    }

    /**
     * 创建一个 {@link InvocationHandler} 到 {@link MethodInterceptor} 的适配对象
     *
     * @param handler JDK {@link InvocationHandler}
     * @return JDK {@link InvocationHandler} 的 {@link MethodInterceptor} 代理对象
     */
    private static MethodInterceptor createCallback(InvocationHandler handler) {
        return new InvocationHandlerCallback(handler);
    }

    /**
     * JDK {@link InvocationHandler} 的 {@link MethodInterceptor} 代理
     */
    private static class InvocationHandlerCallback implements MethodInterceptor {
        private final InvocationHandler delegate;

        private InvocationHandlerCallback(InvocationHandler delegate) {
            this.delegate = delegate;
        }

        @Override
        public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
            return delegate.invoke(proxy, method, args);
        }
    }
}
