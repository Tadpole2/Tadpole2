/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.io;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.WritableByteChannel;
import java.nio.channels.spi.AbstractInterruptibleChannel;

/**
 * 多输出 Channel
 *
 * @author vacoor
 */
public class MultiWritableByteChannel extends AbstractInterruptibleChannel implements WritableByteChannel {
    private WritableByteChannel wChannel1;
    private WritableByteChannel wChannel2;

    public static MultiWritableByteChannel on(WritableByteChannel wChannel1, WritableByteChannel wChannel2) {
        return new MultiWritableByteChannel(wChannel1, wChannel2);
    }

    public MultiWritableByteChannel(WritableByteChannel wChannel1, WritableByteChannel wChannel2) {
        this.wChannel1 = wChannel1;
        this.wChannel2 = wChannel2;
    }

    @Override
    public int write(ByteBuffer src) throws IOException {
        wChannel1.write(src.duplicate());
        return wChannel2.write(src);
    }

    @Override
    protected void implCloseChannel() throws IOException {
    }
}
