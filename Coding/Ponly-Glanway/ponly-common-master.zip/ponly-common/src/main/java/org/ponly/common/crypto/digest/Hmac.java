/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.crypto.digest;

import org.ponly.common.codec.Hex;
import org.ponly.common.codec.Base64;
import org.ponly.common.util.Bytes;
import org.ponly.common.util.Throwables;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
 * Hash-based Message Authentication Code
 * <p>
 * 使用: new Hmac.MD5(keyBytes, "message").toHex();
 *
 * @author vacoor
 */
@SuppressWarnings({"unused"})
public class Hmac {

    public enum Algorithm {
        HMAC_MD5("HmacMD5"), HMAC_SHA1("HmacSHA1"), HMAC_SHA256("HmacSHA256"), HMAC_SHA384("HmacSHA384"), HMAC_SHA512("HmacSHA512");

        private final String name;

        Algorithm(String algorithm) {
            this.name = algorithm;
        }
    }

    /**
     * HMAC-MD5
     */
    public static class MD5 extends Hmac {
        public MD5(byte[] key, Object source) {
            super(Algorithm.HMAC_MD5, key, source);
        }
    }

    /**
     * HMAC-SHA1
     */
    public static class SHA1 extends Hmac {
        public SHA1(byte[] key, Object source) {
            super(Algorithm.HMAC_SHA1, key, source);
        }
    }

    /**
     * HMAC-SHA256
     */
    public static class SHA256 extends Hmac {
        public SHA256(byte[] key, Object source) {
            super(Algorithm.HMAC_SHA256, key, source);
        }
    }

    /**
     * HMAC-SHA384
     */
    public static class SHA384 extends Hmac {
        public SHA384(byte[] key, Object source) {
            super(Algorithm.HMAC_SHA384, key, source);
        }
    }

    /**
     * HMAC-SHA512
     */
    public static class SHA512 extends Hmac {
        public SHA512(byte[] key, Object source) {
            super(Algorithm.HMAC_SHA512, key, source);
        }
    }


    /* ********************************
     *
     * ********************************/

    private byte[] bytes;   // hashed bytes
    private String hexEncoded;
    private String base64Encoded;

    public Hmac(Algorithm algorithm, byte[] key, Object source) {
        if (algorithm == null || key == null || source == null) {
            throw new NullPointerException("algorithm, key and source argument cannot be null.");
        }

        hash(algorithm, key, Bytes.toBytes(source));
    }

    protected void hash(Algorithm algorithm, byte[] key, byte[] source) {
        try {
            bytes = hash(algorithm.name, key, source);
        } catch (GeneralSecurityException e) {
            bytes = Throwables.rethrowRuntimeException(e);
        }
    }

    protected byte[] hash(String algorithm, byte[] key, byte[] bytes) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, algorithm);

        Mac mac = Mac.getInstance(algorithm);
        mac.init(secretKeySpec);
        mac.reset();
        return mac.doFinal(bytes);
    }

    /**
     * 获取 Hash 值
     */
    public byte[] getBytes() {
        return bytes;
    }

    /**
     * 获取 Hash 值的十六进制形式
     */
    public String toHex() {
        if (null == hexEncoded) {
            hexEncoded = Hex.encode(bytes);
        }
        return hexEncoded;
    }

    /**
     * 获取 Hash 值的Base64形式
     */
    public String toBase64() {
        if (null == base64Encoded) {
            base64Encoded = Base64.encodeToString(bytes);
        }
        return base64Encoded;
    }

    @Override
    public String toString() {
        return toHex();
    }
}
