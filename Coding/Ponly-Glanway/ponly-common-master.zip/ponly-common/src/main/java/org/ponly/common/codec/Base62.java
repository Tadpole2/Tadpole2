package org.ponly.common.codec;

import java.io.ByteArrayOutputStream;

/**
 * Base62
 * <p/>
 * 实现来自网络, 原理:替换 base64 中 i --&gt; ia, + --&gt; ib, / --&gt; ic
 *
 * @author vacoor
 */
public abstract class Base62 {
    private static char[] DIGITS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
    private static byte[] INV = new byte[256];

    static {
        for (int i = 0; i < DIGITS.length; i++) {
            INV[DIGITS[i]] = (byte) i;
        }
    }

    /**
     * 使用 Base62 编码给定的字节数组
     *
     * @param bytes 要 encode 的字节数组
     * @return 字节数组的 Base62 编码字符串
     */
    public static String encode(byte[] bytes) {
        StringBuilder buff = new StringBuilder(bytes.length * 2);
        int pos = 0;
        int val = 0;

        for (int i = 0; i < bytes.length; i++) {
            byte b = bytes[i];

            val = (val << 8) | (b & 0xFF);
            pos += 8;

            while (pos > 5) {
                char c = DIGITS[val >> (pos -= 6)];
                buff.append(c == 'i' ? "ia" : c == '+' ? "ib" : c == '/' ? "ic" : c);
                val &= ((1 << pos) - 1);
            }
        }

        if (pos > 0) {
            char c = DIGITS[val << (6 - pos)];
            buff.append(c == 'i' ? "ia" : c == '+' ? "ib" : c == '/' ? "ic" : c);
        }
        return buff.toString();
    }

    /**
     * 解码给定的 Base62 字符串到原始的字节数组
     *
     * @param base62 base62 编码字符串
     * @return 编码前的字节数组
     */
    public static byte[] decode(String base62) {
        return decode(base62.toCharArray());
    }

    /**
     * 解码给定的 Base62 字符数组到原始的字节数组
     *
     * @param base62Chars base62 编码字符数组
     * @return 编码前的字节数组
     */
    public static byte[] decode(char[] base62Chars) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(base62Chars.length);
        int pos = 0;
        int val = 0;

        for (int i = 0; i < base62Chars.length; i++) {
            char c = base62Chars[i];

            if (c == 'i') {
                c = base62Chars[++i];
                c = c == 'a' ? 'i' : c == 'b' ? '+' : c == 'c' ? '/' : base62Chars[--i];
            }

            val = (val << 6) | INV[c];
            pos += 6;

            while (pos > 7) {
                baos.write(val >> (pos -= 8));
                val &= ((1 << pos) - 1);
            }
        }
        return baos.toByteArray();
    }

    private Base62() {
    }
}
