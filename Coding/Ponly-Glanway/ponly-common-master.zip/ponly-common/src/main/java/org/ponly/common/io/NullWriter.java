package org.ponly.common.io;

import java.io.IOException;
import java.io.Writer;

/**
 * This Writer writes all data to the famous <b>/dev/null</b>.
 * <p>
 * This output stream has no destination (file/socket etc.) and all
 * chars written to it are ignored and lost.
 */
public class NullWriter extends Writer {
    /**
     * A singleton.
     */
    public static final NullWriter INSTANCE = new NullWriter();

    /**
     * Does mux - write to <code>/dev/null</code>.
     *
     * @param c The chars to write
     * @throws IOException never
     */
    @Override
    public void write(int c) throws IOException {
        //to /dev/null
    }

    /**
     * Does mux - write to <code>/dev/null</code>.
     *
     * @param cbuf The chars to write
     * @throws IOException never
     */
    @Override
    public void write(char[] cbuf) throws IOException {
        //to /dev/null
    }

    /**
     * Does mux - write to <code>/dev/null</code>.
     *
     * @param cbuf The chars to write
     * @throws IOException never
     */
    @Override
    public void write(char[] cbuf, int off, int len) throws IOException {
        //to /dev/null
    }

    /**
     * Does mux - write to <code>/dev/null</code>.
     *
     * @param str The chars to write
     * @throws IOException never
     */
    @Override
    public void write(String str) throws IOException {
        //to /dev/null
    }

    /**
     * Does mux - write to <code>/dev/null</code>.
     *
     * @param str The chars to write
     * @throws IOException never
     */
    @Override
    public void write(String str, int off, int len) throws IOException {
        //to /dev/null
    }

    /**
     * Does mux - append to <code>/dev/null</code>.
     *
     * @param csq The chars to write
     * @throws IOException never
     */
    @Override
    public Writer append(CharSequence csq) throws IOException {
        //to /dev/null
        return this;
    }

    /**
     * Does mux - append to <code>/dev/null</code>.
     *
     * @param csq The chars to write
     * @throws IOException never
     */
    @Override
    public Writer append(CharSequence csq, int start, int end) throws IOException {
        //to /dev/null
        return this;
    }

    /**
     * Does mux - append to <code>/dev/null</code>.
     *
     * @param c The char to write
     * @throws IOException never
     */
    @Override
    public Writer append(char c) throws IOException {
        //to /dev/null
        return this;
    }

    @Override
    public void flush() throws IOException {
        // mux
    }

    @Override
    public void close() throws IOException {
        // mux
    }
}
