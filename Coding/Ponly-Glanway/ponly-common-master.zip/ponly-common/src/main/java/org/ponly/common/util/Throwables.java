/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.HashSet;
import java.util.Set;

/**
 * 异常工具类
 *
 * @author vacoor
 */
@SuppressWarnings({"unused"})
public abstract class Throwables {

    private Throwables() {
    }

    /**
     * 检查异常是否由给定异常引发
     */
    public static boolean causedBy(Throwable t, Class<? extends Throwable> causeType) {
        Set<Throwable> causes = new HashSet<Throwable>();

        for (; t != null && !causeType.isInstance(t) && !causes.contains(t); t = t.getCause()) {
            causes.add(t);
        }

        return t != null && causeType.isInstance(t);
    }

    /**
     * 将给定类型异常转换为 RuntimeException 抛出
     * <p>
     * 如果给定异常已经是 RuntimeException 或 Error 则直接抛出
     * 否则转换为 RuntimeException 抛出
     *
     * @param ex  异常
     * @param <R> 异常类型
     * @return 异常实例
     */
    public static <R> R rethrowRuntimeException(Throwable ex) {
        if (ex instanceof RuntimeException) {
            throw (RuntimeException) ex;
        }
        if (ex instanceof Error) {
            throw (Error) ex;
        }
        throw new UndeclaredThrowableException(ex);
    }

    /**
     * 重新抛出异常
     *
     * @param ex  异常
     * @param <R> 异常类型
     * @return 异常实例
     * @throws Exception
     */
    public static <R> R rethrowException(Throwable ex) throws Exception {
        if (ex instanceof Exception) {
            throw (Exception) ex;
        }
        if (ex instanceof Error) {
            throw (Error) ex;
        }
        throw new UndeclaredThrowableException(ex);
    }

    /**
     * 获取异常的堆栈追踪字符串
     *
     * @param t 异常
     * @return 异常堆栈信息
     */
    public static String getStackTraceAsString(Throwable t) {
        StringWriter writer = new StringWriter();
        t.printStackTrace(new PrintWriter(writer));

        return writer.toString();
    }
}
