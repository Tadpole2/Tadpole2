package org.ponly.common.util.proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationHandler;

/**
 * 默认代理工厂
 * <p>
 * 该类内部使用 JDK 动态代理, cglib 代理, javassist 代理来创建代理对象,
 * 对于需要创建的代理对象是接口, 则使用 JDK 动态代理创建代理对象
 * 对于需要创建的代理对象不是接口, 则使用 cglib/javassist 创建代理对象
 * 具体参见 {@link #getProxy(ClassLoader, Class, InvocationHandler)}
 * <p>
 * {@link JdkDynamicProxyFactory}
 * {@link JavassistProxyFactory}
 * {@link CglibProxyFactory}
 * {@link java.lang.reflect.Proxy}
 * {@link InvocationHandler}
 *
 * @author vacoor
 */
public class DefaultProxyFactory implements ProxyFactory {
    private static final Logger LOG = LoggerFactory.getLogger(DefaultProxyFactory.class);
    private static final boolean CGLIB_PRESENT = isPresent(CglibProxyFactory.ENHANCER_NAME, DefaultProxyFactory.class.getClassLoader());
    private static final boolean JAVASSIST_PRESENT = isPresent(JavassistProxyFactory.ENHANCER_NAME, DefaultProxyFactory.class.getClassLoader());

    /**
     * 使用给定的 ClassLoader, Class, InvocationHandler 创建一个代理对象
     * <p>
     * 对于目标类型如果是接口, 则使用 JDK 动态代理进行创建代理对象
     * 对于目标类型不是接口的,<br>
     * 首先使用 javassist 创建代理对象(如果classpath存在javassist),
     * 如果创建失败, 则使用 cglib 创建代理对象 (如果classpath存在cglib),
     * 如果创建失败, 则抛出 {@link IllegalStateException}
     *
     * @param loader      用于创建代理的 {@link ClassLoader}
     * @param targetClass 代理对象的目标类型
     * @param handler     用于处理代理行为的 {@link InvocationHandler} 实现
     * @param <T>         代理对象类型
     * @return 代理对象
     */
    @Override
    @SuppressWarnings("unchecked")
    public <T> T getProxy(ClassLoader loader, Class<T> targetClass, InvocationHandler handler) {
        if (targetClass.isInterface()) {
            if (LOG.isTraceEnabled()) {
                LOG.trace("create jdk dynamic proxy, type: {}", targetClass);
            }
            return (T) JdkDynamicProxyFactory.newProxy(loader, targetClass, handler);
        }
        if (JAVASSIST_PRESENT) {
            if (LOG.isTraceEnabled()) {
                LOG.trace("create javassist proxy: {}", targetClass);
            }
            return (T) JavassistProxyFactory.createProxy(targetClass, handler, false);
        }
        if (CGLIB_PRESENT) {
            if (LOG.isTraceEnabled()) {
                LOG.trace("create cglib proxy,type: {}", targetClass);
            }
            return (T) CglibProxyFactory.createProxy(loader, targetClass, handler);
        }
        throw new IllegalStateException("create proxy failed, CGLIB/Javassist is not available. Add CGLIB/Javassist to your classpath.");
    }

    /**
     * 给定类是否存在于 classpath
     *
     * @param className   类的完全限定名
     * @param classLoader 用于加载类的 {@link ClassLoader}
     */
    private static boolean isPresent(String className, ClassLoader classLoader) {
        try {
            Class.forName(className, false, classLoader);
            return true;
        } catch (Throwable ex) {
            // Class or one of its dependencies is not present...
            return false;
        }
    }
}
