/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.util.function;

/**
 * 消费者函数接口
 *
 * @author vacoor
 */
// functional interface
public interface Consumer<T> {

    /**
     * 消费给定值
     *
     * @param t 要消费的实例
     */
    void consume(T t);

}
