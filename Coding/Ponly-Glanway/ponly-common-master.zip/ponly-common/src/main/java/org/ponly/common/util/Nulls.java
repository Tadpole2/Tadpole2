/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.util;

/**
 * 空操作工具类
 *
 * @author vacoor
 */
public abstract class Nulls {
    public static final Boolean BOOLEAN_DEFAULT_VALUE = false;
    public static final Character CHAR_DEFAULT_VALUE = '\0';
    public static final Byte BYTE_DEFAULT_VALUE = 0;
    public static final Short SHORT_DEFAULT_VALUE = 0;
    public static final Integer INT_DEFAULT_VALUE = 0;
    public static final Long LONG_DEFAULT_VALUE = 0L;
    public static final Float FLOAT_DEFAULT_VALUE = 0F;
    public static final Double DOUBLE_DEFAULT_VALUE = 0D;
    public static final String STRING_DEFAULT_VALUE = "";

    public static <T> T nvl(T value, T nullValue) {
        return null != value ? value : nullValue;
    }

    public static Boolean nvl(Boolean bool) {
        return nvl(bool, BOOLEAN_DEFAULT_VALUE);
    }

    public static Character nvl(Character character) {
        return nvl(character, CHAR_DEFAULT_VALUE);
    }

    public static Byte nvl(Byte b) {
        return nvl(b, BYTE_DEFAULT_VALUE);
    }

    public static Short nvl(Short s) {
        return nvl(s, SHORT_DEFAULT_VALUE);
    }

    public static Integer nvl(Integer integer) {
        return nvl(integer, INT_DEFAULT_VALUE);
    }

    public static Long nvl(Long l) {
        return nvl(l, LONG_DEFAULT_VALUE);
    }

    public static Float nvl(Float f) {
        return nvl(f, FLOAT_DEFAULT_VALUE);
    }

    public static Double nvl(Double d) {
        return nvl(d, DOUBLE_DEFAULT_VALUE);
    }

    public static String nvl(String string) {
        return nvl(string, STRING_DEFAULT_VALUE);
    }

    private Nulls() {
    }
}
