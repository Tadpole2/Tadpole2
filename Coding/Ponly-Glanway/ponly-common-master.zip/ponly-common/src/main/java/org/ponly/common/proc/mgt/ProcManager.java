package org.ponly.common.proc.mgt;

import org.ponly.common.misc.util.Platform;

/**
 * 系统进程管理器
 *
 * @author vacoor
 */
public abstract class ProcManager {

    private static ProcManager INSTANCE;

    public static ProcManager getInstance() {
        if (null == INSTANCE) {
            if (Platform.isWindows()) {
                INSTANCE = new WinProcManagerImpl();
            } else if (Platform.isX11() || Platform.isMac()) {
                INSTANCE = new UnixProcManagerImpl();
            } else {
                INSTANCE = new JavaProcManagerImpl();
            }
        }
        return INSTANCE;
    }

    /**
     * 获取当前 JVM 进程 ID
     */
    public abstract int getCurrentProcessId();

    /**
     * 获取给定的 {@link java.lang.Process} 的进程 ID
     *
     * @param process JDK 进程对象
     * @return JDK 进程对象 PID
     */
    public abstract int getProcessId(Process process);

    /**
     * 杀死给定的 PID 进程
     *
     * @param pid (进程ID)
     */
    public abstract void kill(int pid);
}
