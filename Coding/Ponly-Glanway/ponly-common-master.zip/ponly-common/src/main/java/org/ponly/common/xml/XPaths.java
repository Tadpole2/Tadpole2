package org.ponly.common.xml;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.xpath.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static org.ponly.common.util.Throwables.rethrowRuntimeException;

/**
 * XPath 工具类
 *
 * @author vacoor
 */
public abstract class XPaths {

    /**
     * 编译给定的 XPATH 表达式
     *
     * @param expression XPATH
     * @return XPathExpression
     */
    public static XPathExpression compile(String expression) {
        XPathExpression expr;
        try {
            expr = newXPath().compile(expression);
        } catch (XPathExpressionException e) {
            expr = rethrowRuntimeException(e);
        }
        return expr;
    }

    public static Boolean evalAsBoolean(String expression, Object item) {
        return (Boolean) eval(expression, item, XPathConstants.BOOLEAN);
    }

    public static Number evalAsNumber(String expression, Object item) {
        return (Number) eval(expression, item, XPathConstants.NUMBER);
    }

    public static String evalAsString(String expression, Object item) {
        return (String) eval(expression, item, XPathConstants.STRING);
    }

    public static Node evalAsNode(String expression, Object item) {
        return (Node) eval(expression, item, XPathConstants.NODE);
    }

    public static NodeList evalAsNodeList(String expression, Object item) {
        return (NodeList) eval(expression, item, XPathConstants.NODESET);
    }

    public static Object eval(String expression, Object item, QName returnType) {
        Object ret;
        try {
            ret = newXPath().evaluate(expression, item, returnType);
        } catch (XPathExpressionException e) {
            ret = rethrowRuntimeException(e);
        }
        return ret;
    }

    public static XPath newXPath() {
        return XPathFactory.newInstance().newXPath();
    }

    /**
     * 创建一个简单的命名空间上下文用户解析多命名空间 XPath
     * xPath.setNamespaceContext(context);
     * xPath.evaluate("/n:mappings")
     */
    public static NamespaceContext createSimpleNamespaceContext() {
        return new SimpleNamespaceContext();
    }

    protected static class SimpleNamespaceContext implements NamespaceContext {
        private Map<String, String> namespaces = new HashMap<String, String>();

        public void put(String prefix, String namespace) {
            namespaces.put(prefix, namespace);
        }

        @Override
        public String getNamespaceURI(String prefix) {
            return namespaces.get(prefix);
        }

        @Override
        public String getPrefix(String namespaceURI) {
            for (Map.Entry<String, String> e : namespaces.entrySet()) {
                if (e.getValue().equals(namespaceURI)) {
                    return e.getKey();
                }
            }
            return null;
        }

        @Override
        public Iterator<String> getPrefixes(String namespaceURI) {
            return Arrays.asList(getPrefix(namespaceURI)).iterator();
        }
    }

    private XPaths() {
    }
}
