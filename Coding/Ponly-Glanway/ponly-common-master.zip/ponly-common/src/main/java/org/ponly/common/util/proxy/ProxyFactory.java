/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.util.proxy;

import java.lang.reflect.InvocationHandler;

/**
 * 代理工厂
 * <p>
 * 该接口提供一个统一的使用 JDK {@link InvocationHandler } 来创建代理对象的规范
 *
 * @author vacoor
 */
public interface ProxyFactory {

    /**
     * 使用给定的 ClassLoader, Class, InvocationHandler 创建一个代理对象
     *
     * @param loader      用于创建代理的 {@link ClassLoader}
     * @param targetClass 代理对象的目标类型
     * @param handler     用于处理代理行为的 {@link InvocationHandler} 实现
     * @param <T>         代理对象类型
     * @return 代理对象
     */
    <T> T getProxy(ClassLoader loader, Class<T> targetClass, InvocationHandler handler);

}
