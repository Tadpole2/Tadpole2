package org.ponly.common.util;

import org.ponly.common.codec.MOD62;

import java.util.zip.CRC32;

/**
 * 随机字符标识符
 *
 * @author vacoor
 */
public abstract class Identifier {

    public static String get() {
        return get(10);
    }

    public static String get(int len) {
        len -= 2;
        int c = len / 2;
        char[] chars = Randoms.nextLetterOrDigit(len);
        // 分段计算之前字符 mod 62
        chars[c - 1] = MOD62.mod(chars, 0, c - 1);
        chars[chars.length - 1] = MOD62.mod(chars, c, chars.length - c - 1);
        // 计算整段的 crc32
        return String.valueOf(chars) + String.format("%02x", getCRC32(chars, 0, chars.length) & 0xff); // + String.format("%02x", (val >> 4 & 0xff));
    }

    public static boolean check(String text) {
        char[] chars = text.toCharArray();
        int rawLen = chars.length - 2;
        String crc = String.format("%02x", getCRC32(chars, 0, rawLen) & 0xff);
        // crc error
        if (crc.charAt(0) != chars[rawLen] || crc.charAt(1) != chars[rawLen + 1]) {
            return false;
        }
        int c = rawLen / 2;
        // 校验
        return MOD62.check(chars, 0, c) && MOD62.check(chars, c, rawLen - c);
    }

    private static long getCRC32(char[] chars, int offset, int len) {
        CRC32 crc32 = new CRC32();
        crc32.update(Bytes.toBytes(chars, offset, len));
        return crc32.getValue();
    }

    protected Identifier() {
    }
}