package org.ponly.common.proc.mgt;

import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.Kernel32;
import com.sun.jna.platform.win32.WinNT;

import java.lang.reflect.Field;

/**
 * Windows 进程管理器
 *
 * @author vacoor
 */
class WinProcManagerImpl extends ProcManager {
    private static final Kernel32 KERNEL32 = Kernel32.INSTANCE;

    /**
     * {@inheritDoc}
     */
    @Override
    public int getCurrentProcessId() {
        return KERNEL32.GetCurrentProcessId();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getProcessId(Process process) {
        Class<?> clazz = process.getClass();
        String type = clazz.getName();

        if (!"java.lang.Win32Process".equals(type) && !"java.lang.ProcessImpl".equals(type)) {
            throw new IllegalStateException("system is not windows");
        }

        try {
            // 获取 windows 句柄
            Field handleField = clazz.getDeclaredField("handle");
            handleField.setAccessible(true);
            long handle = (Long) handleField.get(process);

            // 根据句柄获取 PID
            WinNT.HANDLE winHandle = new WinNT.HANDLE();
            winHandle.setPointer(Pointer.createConstant(handle));
            return Kernel32.INSTANCE.GetProcessId(winHandle);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException("system is not windows", e);
        } catch (NoSuchFieldException e) {
            throw new IllegalStateException("system is not windows", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void kill(int pid) {
        // 根据 PID 获取进程句柄
        WinNT.HANDLE handle = KERNEL32.OpenProcess(WinNT.PROCESS_TERMINATE, false, pid);
        // return null != handle && KERNEL32.TerminateProcess(handle, 0);
        if (null != handle) {
            KERNEL32.TerminateProcess(handle, 0);
        }
    }
}
