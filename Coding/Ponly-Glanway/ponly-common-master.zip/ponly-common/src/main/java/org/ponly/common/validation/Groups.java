/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.validation;

import javax.validation.groups.Default;

/**
 * Bean validation groups
 * 注:
 * Hibernate 项目中 如果包含 bean validation 默认会自动启用
 * 默认验证组为 javax.validation.groups.Default
 * 可通过 hibernate.cfg.xml 中 property 配置
 * &lt;property name="javax.persistence.validation.group.pre-persist"&gt;group1,group2&lt;/property&gt;
 * &lt;property name="javax.persistence.validation.group.pre-update"&gt;org.vacoor...Groups$Update&lt;/property&gt;
 * &lt;property name="javax.persistence.validation.group.pre-remove"&gt;Groups$Delete&lt;/property&gt;
 * &lt;property name="org.hibernate.validator.group.ddl"&gt;Groups.DDL&lt;/property&gt;
 * <p>
 * / @see org.hibernate.cfg.beanvalidation.BeanValidationEventListener
 * / @see org.hibernate.cfg.beanvalidation.GroupsPerOperation#JPA_GROUP_PREFIX
 * / @see org.hibernate.cfg.beanvalidation.GroupsPerOperation#HIBERNATE_GROUP_PREFIX
 * / @see org.hibernate.cfg.beanvalidation.GroupsPerOperation#setGroupsForOperation
 *
 * @author vacoor
 */
public interface Groups {
    /**
     * 新增校验组 Create
     */
    interface C extends Default {
    }

    /**
     * 更新校验组 Update
     */
    interface U extends Default {
    }

    /**
     * 删除校验组 Delete
     */
    interface D extends Default {
    }

    /**
     * 查询校验组 Retrieve
     */
    interface R extends Default {
    }
}
