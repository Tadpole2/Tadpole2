package org.ponly.common.util.function;

/**
 * 条件函数接口, 判断给定值是否符合条件
 *
 * @author vacoor
 */
@SuppressWarnings("unchecked")
public interface Condition<T> {
    Condition TRUE = new Condition() {
        @Override
        public boolean value(Object value) {
            return true;
        }
    };

    /**
     * 校验给定值是否符合条件
     *
     * @param value 校验值
     * @return 如果符合条件返回 true ,否则返回 false
     */
    boolean value(T value);

}
