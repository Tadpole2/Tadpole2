package org.ponly.common.proc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.*;

abstract class Hdw {
    private static final Logger LOG = LoggerFactory.getLogger(Hdw.class);
    private static final Charset UTF_8 = Charset.forName("UTF-8");
    private static final String EXE = "/d.bfi";
    private static String VM_NAME = null;

    public static String getHostnameId() {
        try {
            UUID uuid = UUID.nameUUIDFromBytes(InetAddress.getLocalHost().getHostName().getBytes(UTF_8));
            return "1" + uuid.toString();
        } catch (UnknownHostException ex) {
            LOG.trace("UnknownHost: ", ex);
        } catch (Exception ex) {
            LOG.trace("getHostnameId error: ", ex);
        }
        return null;
    }

    public static String getEthernetAddressId() {
        try {
            String ethernet = null;
            if (System.getProperty("os.name").toLowerCase(Locale.US).contains("windows")) {
                NetworkInterface ni = NetworkInterface.getByInetAddress(InetAddress.getLocalHost());
                if ((!ni.isLoopback()) && (!ni.isVirtual()) && (!ni.isPointToPoint()) && (null != ni.getHardwareAddress())) {
                    ethernet = toHex(ni.getHardwareAddress());
                }
                if (null == ethernet) {
                    ethernet = getAllEthernetAddress();
                }
            } else {
                ethernet = getAllEthernetAddress();
            }

            if (null != ethernet && 11 < ethernet.length()) {
                UUID uuid = UUID.nameUUIDFromBytes(ethernet.getBytes(UTF_8));
                return "2" + uuid.toString();
            }
        } catch (SocketException sex) {
            LOG.trace("socket exception:", sex);
        } catch (UnknownHostException uhex) {
            LOG.trace("unknown host exception:", uhex);
        } catch (Exception ex) {
            LOG.trace("exception:", ex);
        }
        return null;
    }

    private static String getAllEthernetAddress() throws SocketException {
        List<String> addresses = new ArrayList<String>();
        Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();

        while (((Enumeration) nis).hasMoreElements()) {
            NetworkInterface ni = nis.nextElement();
            if (!ni.isLoopback() && !ni.isVirtual() && !ni.isPointToPoint() && null != ni.getHardwareAddress()) {
                addresses.add(toHex(ni.getHardwareAddress()));
            }
        }

        if (addresses.size() > 0) {
            Collections.sort(addresses);
        }

        String address = null;
        StringBuilder buff = new StringBuilder();
        for (String addr : addresses) {
            buff.append(addr);
        }
        if (buff.length() > 0) {
            address = buff.toString();
        }
        return address;
    }

    public static String getSystemDiskVolumeUuid() {
        final String os = System.getProperty("os.name").toLowerCase(Locale.US);

        LOG.trace("start {}", os);
        if (os.startsWith("windows")) {
            BufferedReader reader = null;
            InputStreamReader in = null;
            try {
                String identifier;
                Process process = Runtime.getRuntime().exec("cmd /C dir c:\\");
                in = new InputStreamReader(process.getInputStream(), "UTF-8");
                reader = new BufferedReader(in);

                reader.readLine();
                identifier = reader.readLine();
                if (null != identifier) {
                    identifier = identifier.substring(identifier.length() - 9, identifier.length());
                    if (1 < identifier.length()) {
                        UUID uuid = UUID.nameUUIDFromBytes(identifier.getBytes(UTF_8));
                        identifier = "3" + uuid.toString();
                    }
                }
                return identifier;
            } catch (Exception ex) {
                LOG.trace("get system disk volume uuid error: ", ex);
            } finally {
                closeQuiet(reader);
                closeQuiet(in);
            }
        }

        if (os.startsWith("linux")) {
            String uuid = getSystemDiskUuidOnLinux();
            if (uuid == null) {
                uuid = getSystemDiskUuidFromHpOrKvmLinux();
            }
            if (uuid == null) {
                uuid = getSystemDiskMmcUuid();
            }
            return uuid;
        }

        if (os.startsWith("mac")) {
            return getSystemDiskUuidFromOsx();
        }
        return null;
    }

    private static String getSystemDiskUuidOnLinux() {
        BufferedReader reader = null;
        try {
            Process process = Runtime.getRuntime().exec("ls -l /dev/disk/by-uuid/ | grep sda1;ls -l /dev/disk/by-uuid/ | grep hda1;ls -l /dev/disk/by-uuid/ | grep xvda1");
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));

            String line;
            String info = null;
            while (null != (line = reader.readLine())) {
                if ((line.contains("sda1")) || (line.contains("hda1")) || (line.contains("xvda1"))) {
                    info = line;
                }
            }

            if (null != info && 40 < info.length()) {
                int index = info.indexOf("->");
                info = info.substring(index - 37, index - 1);
                if (1 < info.length()) {
                    if (info.contains(":")) {
                        info = info.substring(info.length() - 16, info.length());
                    }
                    return "3" + UUID.nameUUIDFromBytes(info.getBytes(UTF_8));
                }
            }
            return null;
        } catch (Exception ex) {
            LOG.trace("get system disk uuid exception: ", ex);
        } finally {
            closeQuiet(reader);
        }
        return null;
    }

    private static String getSystemDiskUuidFromHpOrKvmLinux() {
        BufferedReader reader = null;
        try {
            Process process = Runtime.getRuntime().exec("ls -l /dev/disk/by-uuid/ | grep c0d0p1;ls -l /dev/disk/by-uuid/ | grep vda1");
            String localObject1 = null;
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));

            String localObject3 = null;
            while ((localObject1 = reader.readLine()) != null) {
                if (localObject1.contains("c0d0p1") || localObject1.contains("vda1")) {
                    localObject3 = localObject1;
                }
            }
            if ((localObject3 != null) && (localObject3.length() > 40)) {
                if ((localObject3 = localObject3.substring(localObject3.indexOf("->") - 37, localObject3.indexOf("->") - 1)).length() > 1) {
                    UUID uuid = UUID.nameUUIDFromBytes(localObject3.getBytes("UTF-8"));

                    closeQuiet(reader);
                    localObject1 = "3" + uuid.toString();
                    return localObject1;
                }
            }
            closeQuiet(reader);
            return null;
        } catch (Exception localException) {
        } finally {
            closeQuiet(reader);
        }
        return null;
    }

    private static String getSystemDiskMmcUuid() {
        BufferedReader localBufferedReader = null;
        try {
            Process process = Runtime.getRuntime().exec(
                    "ls -l /dev/disk/by-uuid/ | grep mmcblk0p1;" +
                            "ls -l /dev/disk/by-uuid/ | grep xvda2"
            );
            String localObject1 = null;
            localBufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));

            String localObject3 = null;
            while ((localObject1 = localBufferedReader.readLine()) != null) {
                if ((localObject1.contains("mmcblk0p1")) || (localObject1.contains("xvda2"))) {
                    localObject3 = localObject1;
                }
            }
            if ((localObject3 != null) && (((String) localObject3).length() > 40)) {
                if ((localObject3 = ((String) localObject3).substring(((String) localObject3).indexOf("->") - 37, ((String) localObject3).indexOf("->") - 1)).length() > 1) {
                    if (((String) localObject3).contains(":")) {
                        localObject3 = ((String) localObject3).substring(((String) localObject3).length() - 16, ((String) localObject3).length());
                    }
                    UUID uuid = UUID.nameUUIDFromBytes(((String) localObject3).getBytes("UTF-8"));

                    localObject1 = "3" + uuid.toString();
                    try {
                        localBufferedReader.close();
                    } catch (IOException localIOException1) {
                    }
                    return (String) localObject1;
                }
            }
            try {
                localBufferedReader.close();
            } catch (IOException localIOException3) {
            }
            return null;
        } catch (Exception localException) {
        } finally {
            try {
                if (localBufferedReader != null) {
                    localBufferedReader.close();
                }
            } catch (IOException localIOException2) {
            }
        }
        return null;
    }

    private static String getSystemDiskUuidFromOsx() {
        BufferedReader localBufferedReader = null;
        try {
            Process process = Runtime.getRuntime().exec("diskutil info /");
            String localObject1 = null;
            localBufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));

            String localObject3 = null;
            while ((localObject1 = localBufferedReader.readLine()) != null) {
                if (((String) localObject1).indexOf("Volume UUID:") != -1) {
                    localObject3 = localObject1;
                }
            }
            if (localObject3 != null) {
                if ((localObject3 = ((String) localObject3).substring(((String) localObject3).length() - 36, ((String) localObject3).length())).length() > 1) {
                    UUID uuid = UUID.nameUUIDFromBytes(((String) localObject3).getBytes("UTF-8"));

                    localObject1 = "3" + uuid.toString();
                    try {
                        localBufferedReader.close();
                    } catch (IOException localIOException1) {
                    }
                    return (String) localObject1;
                }
            }
            try {
                localBufferedReader.close();
            } catch (IOException localIOException3) {
//                Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG134", localIOException3);
            }
            return null;
        } catch (IOException localIOException4) {
//            Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG133", localIOException4);
        } finally {
            closeQuiet(localBufferedReader);
        }
        return null;
    }


    public static String getHddSerialNumber() {
        final String os = System.getProperty("os.name").toLowerCase(Locale.US);

        LOG.trace("start {}", os);
        if (os.startsWith("windows")) {
            String str1 = null;

            File exe = null;
            try {
                exe = File.createTempFile("tmp", ".exe", new File(System.getProperty("user.home")));
            } catch (Exception ex) {
                LOG.trace("create template file exception: {}", ex);
                try {
                    exe = File.createTempFile("tmp", ".exe");
                } catch (IOException iex) {
                    LOG.trace("create template file exception: {}", iex);

                    File dir = new File(".");
                    try {
                        exe = File.createTempFile("tmp", ".exe", dir.getCanonicalFile());
                    } catch (Exception ex2) {
                        LOG.trace("create template file exception: {}", ex2);
                    }
                }
            }

            if (null != exe) {
                exe.deleteOnExit();
            }

            try {
                // https://www.winsim.com/diskid32/diskid32.html
                InputStream is = Hdw.class.getResourceAsStream(EXE);
                FileOutputStream fos = new FileOutputStream(exe);

                byte[] buff = new byte['?'];
                int len;
                while (-1 != (len = is.read(buff))) {
                    fos.write(buff, 0, len);
                }
                fos.flush();
                fos.close();
                is.close();

                Process process = Runtime.getRuntime().exec(new String[]{exe.getAbsolutePath()});
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));

                String productIdInfo = null;
                String serialNumberInfo = null;
                String line;
                int j = 0;
                while (null != (line = reader.readLine())) {
                    if ((j == 0) && (line.startsWith("Product Id ="))) {
                        productIdInfo = line;
                    }
                    if ((j == 0) && (line.startsWith("Serial Number ="))) {
                        serialNumberInfo = line;
                        j = 1;
                    }
                }

                try {
                    Thread.sleep(50L);
                } catch (InterruptedException ex) { /* ignore */ }

                closeQuiet(reader);
                exe.delete();

                if (null != productIdInfo && null != serialNumberInfo) {
                    productIdInfo = productIdInfo.substring(productIdInfo.indexOf("[") + 1, productIdInfo.length() - 1);
                    serialNumberInfo = serialNumberInfo.substring(serialNumberInfo.indexOf("[") + 1, serialNumberInfo.length() - 1);

                    if (1 < productIdInfo.length() && 1 < serialNumberInfo.length()) {
                        str1 = "4" + UUID.nameUUIDFromBytes((productIdInfo + " " + serialNumberInfo).getBytes(UTF_8)).toString();
                    }
                }
                return str1;
            } catch (Exception ex) {
//                LOG.trace("{}", ex);
            } finally {
                if (null != exe) {
                    exe.delete();
                }
            }
        }

        if (os.startsWith("linux")) {
            String uuid = getHddUuidByHdparm("/dev/sda");
            if (null == uuid) {
                uuid = getHddUuidByHdparm("/dev/hda");
            }
            if (null == uuid) {
                System.out.println("byuuid");
                uuid = getHddUuidById();
            }
            return uuid;
        }

        if (os.startsWith("mac")) {
            return getHddUuidFromMac();
        }
        return null;
    }

    private static String getHddUuidByHdparm(String hardDisk) {
        BufferedReader reader = null;
        try {
            Process process = Runtime.getRuntime().exec("hdparm -i " + hardDisk);
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));

            String model = null;
            String sn = null;
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("Model=")) {
                    model = line.substring(line.indexOf("=") + 1, line.indexOf(","));
                }
                if (line.contains("SerialNo=")) {
                    sn = line.substring(line.lastIndexOf("=") + 1, line.length());
                }
            }

            if (null != model && null != sn && 1 < model.length() && 1 < sn.length()) {
                return "4" + UUID.nameUUIDFromBytes((model + " " + sn).getBytes("UTF-8")).toString();
            }
            return null;
        } catch (Exception localException) {
            localException.printStackTrace();
//            Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG121", localException);
        } finally {
            closeQuiet(reader);
        }
        return null;
    }

    private static String getHddUuidById() {
        String uuid = null;
        BufferedReader reader = null;
        try {
            Process process = Runtime.getRuntime().exec(
                    "ls -l /dev/disk/by-id/ | grep sda;" +
                            "ls -l /dev/disk/by-id/ | grep c0d0;" +
                            "ls -l /dev/disk/by-id/ | grep mmc"
            );
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));

            String model = null;
            String sn = null;
            String line;
            while (null != (line = reader.readLine())) {
                if (line.contains("scsi-SATA") && !line.contains("part")) {
                    model = line.substring(line.indexOf("_") + 1, line.lastIndexOf("_"));
                    sn = line.substring(line.lastIndexOf("_") + 1, line.indexOf("->") - 1);
                } else if (line.contains("scsi") && !line.contains("part")) {
                    model = sn = line.substring(line.indexOf("scsi-") + 5, line.indexOf("->") - 1);
                } else if (line.contains("VBOX_HARDDISK") && !line.contains("part")) {
                    // oracle virtual box
                    model = sn = line.substring(line.indexOf("HARDDISK_") + 9, line.indexOf("->") - 1);
                } else if (line.contains("ata-") && !line.contains("part")) {
                    model = sn = line.substring(line.indexOf("ata-") + 4, line.indexOf("->") - 1);
                } else if (line.contains("cciss") && !line.contains("part")) {
                    model = sn = line.substring(line.indexOf("cciss-") + 6, line.indexOf("->") - 1);
                } else if (line.contains("mmc") && !line.contains("part")) {
                    model = line.substring(line.indexOf("-") + 1, line.lastIndexOf("_"));
                    sn = line.substring(line.lastIndexOf("_") + 1, line.indexOf("->") - 1);
                }
            }

            if (null != model && null != sn && 1 < model.length() && 1 < sn.length()) {
                uuid = "4" + UUID.nameUUIDFromBytes((model + " " + sn).getBytes(UTF_8));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            // Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG123", localException);
        } finally {
            closeQuiet(reader);
        }
        return uuid;
    }

    private static String getHddUuidFromMac() {
        String uuid = null;
        BufferedReader reader = null;
        try {
            Process process = Runtime.getRuntime().exec("system_profiler SPSerialATADataType SPSASDataType SPParallelSCSIDataType");
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));

            String model = null;
            String sn = null;
            String line;
            while (null != (line = reader.readLine())) {
                if (line.contains("Model:")) {
                    model = line.substring(line.indexOf(":") + 2, line.length());
                }
                if (line.contains("Serial Number:")) {
                    sn = line.substring(line.indexOf(":") + 2, line.length());
                }
            }
            if ((model != null) && (sn != null) && 1 < model.length() && 1 < sn.length()) {
                uuid = "4" + UUID.nameUUIDFromBytes(((String) model + " " + (String) sn).getBytes("UTF-8"));
            }
        } catch (IOException ex) {
//            Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG127", localIOException4);
        } finally {
            closeQuiet(reader);
        }
        return uuid;
    }


    public static boolean isVirtualized() {
        final String os = System.getProperty("os.name").toLowerCase(Locale.US);
        int i = 0;
        boolean bool = false;

        if (os.startsWith("windows")) {
            File exe = null;
//            InputStreamReader localInputStreamReader = null;
            try {
                exe = File.createTempFile("tmp", ".exe", new File(System.getProperty("user.home")));
            } catch (IOException ioex) {
                try {
                    exe = File.createTempFile("tmp", ".exe");
                } catch (IOException ioex2) {
                    try {
                        exe = File.createTempFile("tmp", ".exe", new File("."));
                    } catch (Exception ignore) {
                    }
                }
            }

            if (exe != null) {
                exe.deleteOnExit();
            }

            BufferedReader reader = null;
            try {
                // 保存 diskid32 到 文件
                InputStream diskid32In = null;
                FileOutputStream diskid32Out = null;
                try {
                    diskid32In = Hdw.class.getResourceAsStream(EXE);

                    byte[] buff = new byte[1024];
                    diskid32Out = new FileOutputStream(exe);

                    int len;
                    while ((len = diskid32In.read(buff)) != -1) {
                        diskid32Out.write(buff, 0, len);
                    }

                    diskid32Out.flush();
                } finally {
                    closeQuiet(diskid32In);
                    closeQuiet(diskid32Out);
                }

                Process process = Runtime.getRuntime().exec(new String[]{exe.getAbsolutePath()});
                reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));

                int k = 0;
                String line;
                while (null != (line = reader.readLine())) {
                    if ((k == 0) && (line.startsWith("Product Id ="))) {
                        line = line.toLowerCase(Locale.US);
                        k = 1;

                        if (line.contains("vbox")) {
                            VM_NAME = "VirtualBox";
                        } else if (line.contains("virtual hd")) {
                            VM_NAME = "Hyper-V";
                        } else if (line.contains("vmware")) {
                            VM_NAME = "VMware";
                        } else if (line.contains("qemu")) {
                            VM_NAME = "QEMU";
                        } else if (line.contains("xen")) {
                            VM_NAME = "Xen";
                        }
                    }
                }

                try {
                    Thread.sleep(50L);
                } catch (InterruptedException ignore) { /* ignore */ }
            } catch (IOException localIOException3) {
//                Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG118", localIOException3);
            } finally {
                closeQuiet(reader);
                if (null != exe) {
                    exe.delete();
                }
            }
        } else if (System.getProperty("os.name").toLowerCase(Locale.US).startsWith("mac")) {
            bool = isVirtualizedMac();
        } else {
            // unix
//            Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "start " + System.getProperty("os.name"), "");
            bool = isVirtualedByDmesg() || isVirtualizedByDiskId() || isXen() || isOpenVZ();
        }
        return bool;
    }

    public static String getVmName() {
        if (null == VM_NAME && !isVirtualized()) {
            return null;
        }

        return VM_NAME;
    }


    private static boolean isVirtualedByDmesg() {
        String vmName = null;

        BufferedReader reader = null;
        try {
            Process process = Runtime.getRuntime().exec("dmesg | grep -i virtual");
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));
            String line;
            while (null != (line = reader.readLine())) {
                if (line.contains("Hyper-V")) {
                    vmName = "Hyper-V";
                } else if (line.contains("Detected virtualization 'microsoft'")) {
                    vmName = "Hyper-V";
                } else if (line.contains("Microsoft Vmbus")) {
                    vmName = "Hyper-V";
                } else if (line.contains("innotek GmbH VirtualBox")) {
                    vmName = "VirtualBox";
                } else if (line.contains("Detected virtualization 'oracle'")) {
                    vmName = "VirtualBox";
                } else if (line.contains("VirtualBox")) {
                    vmName = "VirtualBox";
                } else if (line.contains("VMware Virtual Platform")) {
                    vmName = "VMware";
                } else if (line.contains("VMware Virtual")) {
                    vmName = "VMware";
                } else if (line.contains("VMware")) {
                    vmName = "VMware";
                } else if (line.contains("QEMU")) {
                    vmName = "QEMU";
                } else if (line.contains("paravirtualized kernel on KVM")) {
                    vmName = "QEMU";
                } else if (line.contains("paravirtualized kernel on Xen")) {
                    vmName = "XEN";
                }
            }
        } catch (IOException localIOException3) {
//            Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG135", localIOException3);
        } finally {
            closeQuiet(reader);
        }
        VM_NAME = vmName;
        return null != vmName;
    }

    private static boolean isVirtualizedByDiskId() {
        boolean i = false;

        BufferedReader localBufferedReader = null;
        try {
            Process process = Runtime.getRuntime().exec("ls -l /dev/disk/by-id/");
            localBufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));
            String line;
            while (null != (line = localBufferedReader.readLine())) {
                if (line.contains("Virtual")) {
                    i = true;
                    VM_NAME = "Hyper-V";
                } else if (line.contains("VBOX")) {
                    i = true;
                    VM_NAME = "VirtualBox";
                } else if (line.contains("VMware")) {
                    i = true;
                    VM_NAME = "VMware";
                } else if (line.contains("QEMU")) {
                    i = true;
                    VM_NAME = "QEMU";
                }
            }
            closeQuiet(localBufferedReader);
//            return (boolean) localObject1;
            return i;
        } catch (IOException localIOException3) {
            // Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG137", localIOException3);
        } finally {
            closeQuiet(localBufferedReader);
        }
        return false;
    }

    private static boolean isXen() {
        boolean flag = false;

        BufferedReader localBufferedReader = null;
        try {
            Process process = Runtime.getRuntime().exec("ls -l /dev/disk/by-uuid/ | grep xvda1;ls -l /dev/disk/by-uuid/ | grep vda1");
            String line;
            localBufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));
            while ((line = localBufferedReader.readLine()) != null) {
                if (line.contains("xvda1") || line.contains("vda1")) {
                    flag = true;
                    VM_NAME = "Xen";
                }
            }
            return flag;
        } catch (IOException localIOException3) {
//            Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG139", localIOException3);
        } finally {
            closeQuiet(localBufferedReader);
        }
        return false;
    }

    private static boolean isOpenVZ() {
        boolean flag = false;

        BufferedReader reader = null;
        try {
            Process process = Runtime.getRuntime().exec("df | grep vzfs");
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("vzfs")) {
                    flag = true;
                    VM_NAME = "OpenVZ";
                }
            }

            return flag;
        } catch (IOException localIOException3) {
//            Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG139", localIOException3);
        } finally {
            closeQuiet(reader);
        }
        return false;
    }

    private static boolean isVirtualizedMac() {
        boolean i = false;

        BufferedReader reader = null;
        try {
            Process process = Runtime.getRuntime().exec("system_profiler SPSerialATADataType SPSASDataType SPParallelSCSIDataType");
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), UTF_8));

            String line;
            while (null != (line = reader.readLine())) {
                if (line.contains("Model:")) {
                    if (line.contains("Virtual")) {
                        i = true;
                        VM_NAME = "Hyper-V";
                    } else if (line.contains("VBOX")) {
                        i = true;
                        VM_NAME = "VirtualBox";
                    } else if (line.contains("VMware")) {
                        i = true;
                        VM_NAME = "VMware";
                    } else if (line.contains("QEMU")) {
                        i = true;
                        VM_NAME = "QEMU";
                    }
                }
            }
//            return (boolean) localObject1;
            return i;
        } catch (IOException localIOException3) {
//            Logger.getLogger(Hdw.class.getName()).log(Level.FINE, "MSG141", localIOException3);
        } finally {
            closeQuiet(reader);
        }
        return false;
    }

    private static void flow(InputStream in, OutputStream out, boolean closeIn, boolean closeOut) throws IOException {
        byte[] buff = new byte[1024];
        int len;
        while (-1 != (len = in.read(buff))) {
            out.write(buff, 0, len);
        }
        out.flush();

        if (closeIn) {
            closeQuiet(in);
        }
        if (closeOut) {
            closeQuiet(out);
        }
    }

    private static void closeQuiet(Closeable closeable) {
        try {
            if (null != closeable) {
                closeable.close();
            }
        } catch (IOException e) {
            /* ignore */
        }
    }

    private static final char[] CHARS = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    public static String toHex(byte[] bytes) {
        int len = bytes.length;
        char[] encoded = new char[len << 1];
        for (int i = 0, j = 0; i < len; i++) {
            encoded[j++] = CHARS[((0xF0 & bytes[i]) >>> 4)];
            encoded[j++] = CHARS[(0xF & bytes[i])];
        }
        return new String(encoded);
    }

    private Hdw() {}
}
