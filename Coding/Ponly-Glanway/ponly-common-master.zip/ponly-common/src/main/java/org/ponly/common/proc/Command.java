/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.proc;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 命令行对象
 * <p>
 * 该类主要处理命令行参数特殊字符问题, 默认 ProcessBuilder中命令行会原样执行,例如空格等造成问题.
 *
 * 在 JDK8 中测试不需要转义
 *
 * @author vacoor
 */
@Deprecated
public class Command {
    private List<String> args;

    public Command(String... command) {
        this.args = new ArrayList<String>();
        addArgs(command);
    }

    public Command addArg(String arg) {
        return addArgs(arg);
    }

    public Command addArgs(String... args) {
        for (String arg : args) {
            if (null != arg) {
                this.args.add(quote(arg));
            }
        }

        return this;
    }

    public Command addArgs(Iterable<String> args) {
        for (String arg : args) {
            arg = null != arg ? arg: "";
            this.args.add(quote(arg));
        }
        return this;
    }

    public Command addEqualsArg(String name, String value) {
        if (null != value && 0 < value.length()) {
            this.args.add(quote(name + "=" + value));
        } else {
            this.args.add(quote(name));
        }

        return this;
    }

    public Command addRawArgs(String... args) {
        for (String arg : args) {
            if (null != arg) {
                this.args.add(arg);
            }
        }

        return this;
    }

    public Command addRawArgs(Iterable<String> args) {
        for (String arg : args) {
            arg = null != arg ? arg : "";
            this.args.add(arg);
        }
        return this;
    }

    public List<String> getArgs() {
        return this.args;
    }

    public String[] toArray() {
        return args.toArray(new String[args.size()]);
    }

    public ProcessBuilder asProcessBuilder() {
        return new ProcessBuilder(getArgs());
    }

    public Process start() throws IOException {
        return asProcessBuilder().start();
    }

    public static String quote(String arg) {
        boolean needsQuoting = (arg.indexOf(32) >= 0) || (arg.indexOf(34) >= 0);
        if (!needsQuoting) {
            return arg;
        }
        StringBuilder buf = new StringBuilder();

        boolean escaped = false;
        for (char c : arg.toCharArray()) {
            if ((!escaped) && ((c == '"') || (c == ' '))) {
                buf.append("\\");
            }
            escaped = c == '\\';
            buf.append(c);
        }

        return buf.toString();
    }

    public String toString() {
        StringBuilder buf = new StringBuilder();

        boolean delim = false;
        for (String arg : this.args) {
            if (delim) {
                buf.append(' ');
            }
            buf.append(arg);
            delim = true;
        }

        return buf.toString();
    }
}