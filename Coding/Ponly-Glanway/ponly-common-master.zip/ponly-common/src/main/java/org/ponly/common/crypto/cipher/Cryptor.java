package org.ponly.common.crypto.cipher;

import org.ponly.common.codec.Base64;
import org.ponly.common.codec.Hex;
import org.ponly.common.util.Bytes;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;

/**
 * JCE (Java Cryptography Extension) 加密算法工具.
 */
public abstract class Cryptor {
    public interface Format {
        Format HEX = new Format() {
            @Override
            public String format(final byte[] bytes) {
                return null != bytes ? Hex.encode(bytes) : null;
            }

            @Override
            public byte[] parse(final String text) {
                return null != text ? Hex.decode(text) : null;
            }
        };

        Format BASE64 = new Format() {
            @Override
            public String format(final byte[] bytes) {
                return null != bytes ? Base64.encodeToString(bytes) : null;
            }

            @Override
            public byte[] parse(final String text) {
                return null != text ? Base64.decode(text) : null;
            }
        };

        String format(final byte[] bytes);

        byte[] parse(final String text);
    }

    /**
     * 对称加密.
     */
    public static class Symmetry extends Cryptor {
        private final String transformation;
        private final SecretKey key;

        public Symmetry(final SecretKey key) {
            this(key.getAlgorithm(), key);
        }

        public Symmetry(final String transformation, final byte[] bytes) {
            this(transformation, newSymmetricKey(transformation, bytes));
        }

        public Symmetry(final String transformation, final SecretKey key) {
            final String algorithm = key.getAlgorithm();

            if (!transformation.toUpperCase().startsWith(algorithm)) {
                throw new IllegalArgumentException("key algorithm and transformation algorithm not matches");
            }
            this.transformation = transformation;
            this.key = key;
        }

        @Override
        public byte[] encrypt(final byte[] bytes) {
            return doCrypt(transformation, Cipher.ENCRYPT_MODE, bytes);
        }

        @Override
        public byte[] decrypt(final byte[] bytes) {
            return doCrypt(transformation, Cipher.DECRYPT_MODE, bytes);
        }

        protected byte[] doCrypt(final String transformation, final int jcaMode, final byte[] bytes) {
            final IvParameterSpec ivParameterSpec = null;
            try {
                return crypt(transformation, jcaMode, key, ivParameterSpec, new SecureRandom(), bytes);
            } catch (IllegalBlockSizeException e) {
                throw new IllegalArgumentException(e);
            } catch (InvalidKeyException e) {
                throw new IllegalArgumentException(e);
            } catch (BadPaddingException e) {
                throw new IllegalArgumentException(e);
            } catch (NoSuchPaddingException e) {
                throw new IllegalArgumentException(e);
            } catch (NoSuchAlgorithmException e) {
                throw new IllegalStateException(e);
            } catch (InvalidAlgorithmParameterException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    /**
     * 非对称加密.
     */
    public static class Asymmetry extends Cryptor {
        private final String transformation;
        private final KeyPair key;

        public Asymmetry(final String transformation, final byte[] encodedPublicKey, final byte[] encodedPrivateKey) {
            this(null, newAsymmetricKey(transformation, encodedPublicKey, encodedPrivateKey));
        }

        public Asymmetry(final KeyPair key) {
            this(null, key);
        }

        public Asymmetry(final String transformation, final KeyPair key) {
            final PublicKey publicKey = key.getPublic();
            final PrivateKey privateKey = key.getPrivate();
            final String publicAlgorithm = null != publicKey ? publicKey.getAlgorithm() : null;
            final String privateAlgorithm = null != privateKey ? privateKey.getAlgorithm() : null;

            if (null == publicAlgorithm && null == privateAlgorithm) {
                throw new IllegalArgumentException("key pair does not contain any key");
            }
            if (null != publicAlgorithm && null != privateAlgorithm && !publicAlgorithm.equals(privateAlgorithm)) {
                throw new IllegalArgumentException("public key and private key algorithm not matches");
            }

            final String algorithm = null != publicAlgorithm ? publicAlgorithm : privateAlgorithm;
            if (null != transformation && !transformation.toUpperCase().startsWith(algorithm)) {
                throw new IllegalArgumentException("key algorithm and transformation algorithm not matches");
            }

            this.transformation = null != transformation ? transformation : algorithm;
            this.key = key;
        }

        @Override
        public byte[] encrypt(final byte[] bytes) {
            final PublicKey publicKey = key.getPublic();
            if (null == publicKey) {
                throw new IllegalStateException("public key is not set");
            }
            return doCrypt(Cipher.ENCRYPT_MODE, publicKey, bytes);
        }

        @Override
        public byte[] decrypt(final byte[] bytes) {
            final PrivateKey privateKey = key.getPrivate();
            if (null == privateKey) {
                throw new IllegalStateException("private key is not set");
            }
            return doCrypt(Cipher.DECRYPT_MODE, privateKey, bytes);
        }

        protected byte[] doCrypt(final int jcaMode, final Key key, final byte[] bytes) {
            try {
                return crypt(transformation, jcaMode, key, null, new SecureRandom(), bytes);
            } catch (IllegalBlockSizeException e) {
                throw new IllegalArgumentException(e);
            } catch (InvalidKeyException e) {
                throw new IllegalArgumentException(e);
            } catch (BadPaddingException e) {
                throw new IllegalArgumentException(e);
            } catch (NoSuchPaddingException e) {
                throw new IllegalArgumentException(e);
            } catch (NoSuchAlgorithmException e) {
                throw new IllegalStateException(e);
            } catch (InvalidAlgorithmParameterException e) {
                throw new IllegalStateException(e);
            }
        }
    }


    public String encrypt(final String plain) {
        return encrypt(plain, null);
    }

    public String encrypt(final String plain, final Format format) {
        final Format fmt = null != format ? format : Format.BASE64;
        return null != plain ? fmt.format(encrypt(Bytes.toBytes(plain))) : null;
    }

    public String decrypt(final String cipher) {
        return decrypt(cipher, null);
    }

    public String decrypt(final String cipher, final Format format) {
        final Format fmt = null != format ? format : Format.BASE64;
        return null != cipher ? Bytes.toString(decrypt(fmt.parse(cipher))) : null;
    }

    public abstract byte[] encrypt(final byte[] bytes);

    public abstract byte[] decrypt(final byte[] bytes);

    protected byte[] crypt(final String transformation, final int jcaMode, final Key key,
                           final AlgorithmParameterSpec spec, final SecureRandom random, final byte[] bytes)
            throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
            InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        final Cipher cipher = Cipher.getInstance(transformation);
        if (null == spec) {
            if (null == random) {
                cipher.init(jcaMode, key);
            } else {
                cipher.init(jcaMode, key, random);
            }
        } else {
            if (null == random) {
                cipher.init(jcaMode, key, spec);
            } else {
                cipher.init(jcaMode, key, spec, random);
            }
        }
        return cipher.doFinal(bytes);
    }

    public static SecretKey newSymmetricKey(final String transformation) {
        try {
            final String algorithm = getAlgorithm(transformation);
            return KeyGenerator.getInstance(algorithm).generateKey();
        } catch (final NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static SecretKeySpec newSymmetricKey(final String transformation, final byte[] encodedKey) {
        final String algorithm = getAlgorithm(transformation);
        return new SecretKeySpec(encodedKey, algorithm);
    }

    public static KeyPair newAsymmetricKey(final String transformation) {
        try {
            final String algorithm = getAlgorithm(transformation);
            final KeyPairGenerator keygen = KeyPairGenerator.getInstance(algorithm);
            // keygen.initialize();
            return keygen.generateKeyPair();
        } catch (final NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static KeyPair newAsymmetricKey(final String transformation, final String base64PublicKey, final String base64PrivateKey) {
        final byte[] publicKey = null != base64PublicKey ? Format.BASE64.parse(base64PublicKey) : new byte[0];
        final byte[] privateKey = null != base64PrivateKey ? Format.BASE64.parse(base64PrivateKey) : new byte[0];
        return newAsymmetricKey(transformation, publicKey, privateKey);
    }

    public static KeyPair newAsymmetricKey(final String transformation, final byte[] encodedPublicKey, final byte[] encodedPrivateKey) {
        PublicKey publicKey = null;
        PrivateKey privateKey = null;
        try {
            final String algorithm = getAlgorithm(transformation);
            final KeyFactory factory = KeyFactory.getInstance(algorithm);
            if (null != encodedPublicKey && 0 < encodedPublicKey.length) {
                // new X509EncodedKeySpec(encodedPublicKey);
                if ("RSA".equals(algorithm)) {
                    publicKey = factory.generatePublic(new X509EncodedKeySpec(encodedPublicKey));
                } else {
                    publicKey = factory.generatePublic(new PKCS8EncodedKeySpec(encodedPublicKey));
                }
            }
            if (null != encodedPrivateKey && 0 < encodedPrivateKey.length) {
                privateKey = factory.generatePrivate(new PKCS8EncodedKeySpec(encodedPrivateKey));
            }
            if (null == publicKey && null == privateKey) {
                throw new IllegalArgumentException("public key and private key must be specify at least one");
            }
            return new KeyPair(publicKey, privateKey);
        } catch (final InvalidKeySpecException e) {
            throw new IllegalArgumentException(e);
        } catch (final NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static KeyPair newRSAKey(final BigInteger modulus, final BigInteger publicExponent, final BigInteger privateExponent) {
        PublicKey publicKey = null;
        PrivateKey privateKey = null;
        try {
            final KeyFactory factory = KeyFactory.getInstance("RSA");
            if (null != publicExponent) {
                final KeySpec keySpec = new RSAPublicKeySpec(modulus, publicExponent);
                publicKey = factory.generatePublic(keySpec);
            }
            if (null != privateExponent) {
                final KeySpec keySpec = new RSAPrivateKeySpec(modulus, privateExponent);
                privateKey = factory.generatePrivate(keySpec);
            }
            if (null == publicKey && null == privateKey) {
                throw new IllegalArgumentException("public key and private key must be specify at least one");
            }
            return new KeyPair(publicKey, privateKey);
        } catch (final NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        } catch (final InvalidKeySpecException e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static PublicKey parseOpenSshRsaPublicKey(final String openSshBase64PublicKey) {
        try {
            return KeyFactory.getInstance("RSA").generatePublic(parseOpenSshPublicKey(openSshBase64PublicKey));
        } catch (final NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        } catch (final InvalidKeySpecException e) {
            throw new IllegalArgumentException(e);
        }
    }

    private static KeySpec parseOpenSshPublicKey(final String base64PublicKey) {
        final int start = base64PublicKey.indexOf("ssh-rsa ");
        final int last = base64PublicKey.lastIndexOf(' ');
        final int end = -1 < start ? base64PublicKey.indexOf(' ', start + 7 + 1) : -1;

        if (0 > end || end != last) {
            throw new IllegalArgumentException("is not a OpenSSH public key");
        }
        final byte[] bytes = Base64.decode(base64PublicKey.substring(start + 7 + 1, end));

        int offset = 0;
        final int publicExponentLength = new BigInteger(Arrays.copyOfRange(bytes, offset, offset += 4)).intValue();
        final BigInteger publicExponent = new BigInteger(Arrays.copyOfRange(bytes, offset, offset += publicExponentLength));
        final int modulusLength = new BigInteger(Arrays.copyOfRange(bytes, offset, offset += 4)).intValue();
        final BigInteger modulus = new BigInteger(Arrays.copyOfRange(bytes, offset, offset + modulusLength));

        return new RSAPublicKeySpec(modulus, publicExponent);
    }

    /**
     * RSA/ECB/PKCS1Padding: RSA
     */
    private static String getAlgorithm(final String transformation) {
        final int i = null != transformation ? transformation.indexOf('/') : -1;
        return -1 < i ? transformation.substring(0, i) : transformation;
    }
}
