package org.ponly.common.util;

/**
 */
public abstract class AtomicLazyValue<V> extends LazyValue<V> {
    private volatile V value;
    @Override
    public final V getValue() {
        V v = value;
        if (null != v) {
            return v;
        }
        synchronized (this) {
            v = value;
            if (null == v) {
                v = value = compute();
            }
        }
        return v;
    }

    public static <V> AtomicLazyValue createConstant(final V value) {
        return new AtomicLazyValue() {
            @Override
            protected V compute() {
                return value;
            }
        };
    }
}
