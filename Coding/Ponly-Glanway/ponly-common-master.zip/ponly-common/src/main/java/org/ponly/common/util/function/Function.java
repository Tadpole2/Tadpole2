package org.ponly.common.util.function;

/**
 * 功能函数接口, 实现将输入转换为输出
 *
 * @author vacoor
 */
public interface Function<F, T> {

    T apply(F from);

}
