package org.ponly.common.util;

/**
 * 延迟计算工具类
 * <p>
 * 该类主要用于某些情况下, 并不需要及时获取值, 延迟计算以便减少运算开销,
 * 或者需要获取实际调用时值的情况
 *
 * @author vacoor
 */
public abstract class LazyValue<V> {
    private V value;

    /**
     * 计算当前值
     */
    protected abstract V compute();

    /**
     * 计算当前延迟计算的值
     */
    public V getValue() {
        if (null == value) {
            value = compute();
        }
        return value;
    }

    public static <V> LazyValue createConstant(final V value) {
        return new LazyValue() {
            @Override
            protected V compute() {
                return value;
            }
        };
    }
}
