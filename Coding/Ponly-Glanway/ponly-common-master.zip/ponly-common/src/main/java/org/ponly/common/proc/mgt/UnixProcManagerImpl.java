package org.ponly.common.proc.mgt;

import com.sun.jna.Library;
import com.sun.jna.Native;

import java.lang.reflect.Field;

/**
 * Unix (Linux/OSX) 平台进程管理器
 *
 * @author vacoor
 */
class UnixProcManagerImpl extends ProcManager {
    private static final GNUCLibrary CLIB = (GNUCLibrary) Native.loadLibrary("c", GNUCLibrary.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public int getCurrentProcessId() {
        return CLIB.getpid();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getProcessId(Process process) {
        Class<? extends Process> clazz = process.getClass();
        String type = clazz.getName();

        if (!"java.lang.UNIXProcess".equals(type)) {
            throw new IllegalStateException("os is not unix");
        }
        try {
            Field pidField = clazz.getDeclaredField("pid");
            pidField.setAccessible(true);
            return (Integer) pidField.get(process);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException("os is not unix", e);
        } catch (NoSuchFieldException e) {
            throw new IllegalStateException("os is not unix", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void kill(int pid) {
        // int kill = CLIB.kill(pid, CLIB.SIGINT);
        kill(pid, GNUCLibrary.SIGKILL);
    }

    /**
     * 向给定的 PID 进程发送终止信号量
     */
    protected static int kill(int pid, int signal) {
        return CLIB.kill(pid, signal);
    }

    /**
     * GNU C library JNA 代理接口
     */
    private interface GNUCLibrary extends Library {
        int SIGINT = 2;
        int SIGKILL = 9;
        int SIGTERM = 15;
        int SIGCONT = 19;

        int getpid();

        int kill(int pid, int signal);
    }
}
