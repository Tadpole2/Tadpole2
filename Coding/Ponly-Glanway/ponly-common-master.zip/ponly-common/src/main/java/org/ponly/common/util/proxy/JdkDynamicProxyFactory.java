package org.ponly.common.util.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

/**
 * JDK 动态代理 代理工厂
 *
 * @author vacoor
 */
public class JdkDynamicProxyFactory implements ProxyFactory {

    /**
     * {@inheritDoc}
     */
    @Override
    @SuppressWarnings("unchecked")
    public <T> T getProxy(ClassLoader loader, Class<T> targetClass, InvocationHandler handler) {
        return (T) newProxy(loader, targetClass, handler);
    }

    /**
     * 使用给定的 ClassLoader, Class, InvocationHandler 创建一个 JDK 动态代理对象
     *
     * @param loader      用于创建代理的 {@link ClassLoader}
     * @param targetClass 代理对象的目标类型
     * @param handler     用于处理代理行为的 {@link InvocationHandler} 实现
     * @return 代理对象
     */
    public static Object newProxy(ClassLoader loader, Class<?> targetClass, InvocationHandler handler) {
        return Proxy.newProxyInstance(loader, new Class<?>[]{targetClass}, handler);
    }
}
