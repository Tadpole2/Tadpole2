/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.util;

import java.util.concurrent.TimeUnit;

/**
 * 线程工具类
 *
 * @author vacoor
 */
@SuppressWarnings({"unused"})
public abstract class Threads {

    /**
     * 线程休眠 millis 毫秒
     *
     * @param millis 单位毫秒
     */
    public static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * 线程休眠
     *
     * @param duration 休眠时长
     * @param unit     时长单位
     */
    public static void sleep(long duration, TimeUnit unit) {
        sleep(unit.toMillis(duration));
    }

    private Threads() {
    }
}
