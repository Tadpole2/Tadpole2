package org.ponly.common.proc.mgt;

import org.ponly.common.misc.util.Platform;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 纯 Java 进程管理器
 *
 * @author vacoor
 */
class JavaProcManagerImpl extends ProcManager {

    /**
     * {@inheritDoc}
     */
    public int getCurrentProcessId() {
        int pid = -1;
        String pidStr = System.getProperty("jvm.pid");
        if (null == pidStr) {
            // first, reliable with sun jdk (http://golesny.de/wiki/code:javahowtogetpid)
            final RuntimeMXBean rtb = ManagementFactory.getRuntimeMXBean();
            final String processName = rtb.getName();
            /*-
             * 在以下平台测试:
             * - windows xp sp 2, java 1.5.0_13
             * - mac os x 10.4.10, java 1.5.0
             * - debian linux, java 1.5.0_13
             * 均返回 pid@host, e.g 2204@antonius
             */
            if (processName.indexOf('@') != -1) {
                pidStr = processName.substring(0, processName.indexOf('@'));
            } else {
                pidStr = "0";
                // TODO
                // pid = getPIDFromOS();
                // cmd = new String[] { "/bin/sh", "-c", "echo $$ $PPID" };
            }
            System.setProperty("jvm.pid", pidStr);
        }

        try {
            pid = Integer.parseInt(pidStr);
        } catch (NumberFormatException ignore) {/* ignore */}

        return pid;
    }

    /**
     * {@inheritDoc}
     */
    public int getProcessId(Process process) {
        Class<?> clazz = process.getClass();
        String type = clazz.getName();

        // 尝试通过反射处理
        try {
            /*
            if("java.lang.Win32Process".equals(type) || "java.lang.ProcessImpl".equals(type)) {
                Field handleField = clazz.getDeclaredField("handle");
                handleField.setAccessible(true);
                long handle = (Long) handleField.get(process);
                return getProcessIdByHandle(handle);
            }
            */

            if ("java.lang.UnixProcess".equals(type)) {
                Field pidField = clazz.getDeclaredField("pid");
                pidField.setAccessible(true);
                return (Integer) pidField.get(process);
            }
            throw new UnsupportedOperationException();
        } catch (IllegalAccessException e) {
            throw new IllegalStateException(e);
        } catch (NoSuchFieldException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void kill(int pid) {
        try {
            if (Platform.isX11() || Platform.isMac()) {
                try {
                    JDKUnixProc.kill(pid);
                } catch (Exception ex) {
                    Process proc = Runtime.getRuntime().exec(new String[]{"kill", "-9", pid + ""});
                }
            } else if (Platform.isWindows()) {
                // taskkill /pid 进程序号 -t(结束该进程以及所有子进程) -f(强制结束该进程)
                Process proc = Runtime.getRuntime().exec(new String[]{"taskkill", "/pid", pid + "", "/f"});
            }
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /*
    public static final Charset CP936 = Charset.forName("CP936");
    protected static int getProcessIdByHandle(long handle) {
        int pid = 0;
        InputStream is = null;
        InputStream eis = null;
        try {
            Process proc = Runtime.getRuntime().exec(new String[]{"wmic", "process", "where", "Handle=" + String.valueOf(handle), "get", "ProcessId"});
            is = proc.getInputStream();
            eis = proc.getErrorStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(is, CP936));
            reader.readLine();
            String pidStr = reader.readLine();
            String error = IOUtils.toString(eis, CP936, false);
            int exit = proc.waitFor();

            if (!StringUtils.hasText(error) && StringUtils.hasText(pidStr) && 0 == exit) {
                pid = Integer.parseInt(pidStr);
            }
        } catch (IOException e) {
            // ignore
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            IOUtils.close(is);
            IOUtils.close(eis);
        }
        return pid;
    }
    */


    // unix 可以利用 JDK
    private static final class JDKUnixProc {
        private static final Field PID_FIELD;
        private static final Method DESTROY_PROCESS;
        private static final Method DESTROY_PROCESS_FORCE;

        static {
            try {
                Class<?> clazz = Class.forName("java.lang.UNIXProcess");
                PID_FIELD = clazz.getDeclaredField("pid");
                PID_FIELD.setAccessible(true);

                Method m = null;
                try {
                    // JDK 1.6 之前, 存在 destroyProcess(int)
                    m = clazz.getDeclaredMethod("destroyProcess", int.class);
                    m.setAccessible(true);
                } catch (NoSuchMethodException ignore) {
                    // ignore
                }
                DESTROY_PROCESS = m;

                m = null;
                if (null == DESTROY_PROCESS) {
                    // JDK 1.7 (1.8 ?) 存在 destroyProcess(int, boolean)
                    m = clazz.getDeclaredMethod("destroyProcess", int.class, boolean.class);
                    m.setAccessible(true);
                }
                DESTROY_PROCESS_FORCE = m;
            } catch (ClassNotFoundException e) {
                LinkageError x = new LinkageError();
                x.initCause(e);
                throw x;
            } catch (NoSuchFieldException e) {
                LinkageError x = new LinkageError();
                x.initCause(e);
                throw x;
            } catch (NoSuchMethodException e) {
                LinkageError x = new LinkageError();
                x.initCause(e);
                throw x;
            }
        }

        private static void kill(int pid) throws InvocationTargetException, IllegalAccessException {
            if (null != DESTROY_PROCESS) {
                DESTROY_PROCESS.invoke(null, pid);
            } else {
                DESTROY_PROCESS_FORCE.invoke(null, pid, true);
            }
        }
    }
}
