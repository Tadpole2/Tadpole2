package org.ponly.common.proc;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

/**
 * 执行进程任务
 *
 * @author vacoor
 */
public abstract class ProcTask extends FutureTask<ProcStarter.Feedback> {
    private final ProcStarter starter;

    protected ProcTask(ProcStarter starter, Callable<ProcStarter.Feedback> callable) {
        super(callable);
        this.starter = starter;
    }

    /**
     * 获取创建该进程任务的 {@link ProcStarter}
     */
    public ProcStarter getStarter() {
        return starter;
    }

    /**
     * 取消当前进程任务
     */
    @Override
    public boolean cancel(boolean mayInterruptIfRunning) {
        Process process = getProcess();
        if (null != process && !isDone()) {
            process.destroy();
        }
        return super.cancel(mayInterruptIfRunning);
    }

    /**
     * 拷贝当前进程任务作为一个新任务
     */
    public ProcTask copyAsNew() {
        return starter.newTask(getCommand(), getArguments());
    }

    /**
     * 获取当前进程任务创建时指定的命令
     */
    public abstract String[] getCommand();

    /**
     * 获取当前进程任务创建时的参数
     */
    public abstract String[] getArguments();

    /**
     * 获取当前进程任务中正在执行的进程
     *
     * @return 如果任务已经执行则返回正在执行的进程，否则返回 null
     */
    public abstract Process getProcess();

}
