package org.ponly.common.util.proxy;


import org.ponly.common.util.LazyValue;
import org.ponly.common.util.function.Function;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * 代理工具类
 *
 * @author vacoor
 */
public abstract class ProxyUtils {
    private static final ProxyFactory DEFAULT = new DefaultProxyFactory();

    /**
     * 创建一个延迟计算代理
     *
     * @param targetClass 代理类型
     * @param value       延迟值, 延迟计算值必须不为 null
     * @param <T>         类型
     */
    public static <T> T getProxy(Class<T> targetClass, final LazyValue<T> value) {
        return getProxy(null, targetClass, value);
    }

    /**
     * 创建一个延迟计算代理
     *
     * @param targetClass 代理类型
     * @param lz          延迟值, 延迟计算值必须不为 null
     * @param <T>         类型
     */
    public static <T> T getProxy(ClassLoader loader, Class<T> targetClass, final LazyValue<T> lz) {
        return getProxy(loader, targetClass, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                T value = lz.getValue();
                if (null == value) {
                    throw new IllegalStateException("lazy value is null");
                }
                return method.invoke(value, args);
            }
        });
    }

    /**
     * 获取一个组合代理, 该代理会一次调用代理对象
     *
     * @param loader            类加载器
     * @param targetClass       代理目标类型
     * @param delegates         被代理对象
     * @param returnValueMerger 返回值合并函数
     * @param <T>               代理目标类型
     * @return 组合代理
     */
    public static <T> T getCompositeProxy(final ClassLoader loader,
                                          final Class<T> targetClass,
                                          final Iterable<T> delegates,
                                          final Function<Object[], Object> returnValueMerger) {
        return getProxy(loader, targetClass, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                List<Object> returnValues = new ArrayList<Object>();

                for (T next : delegates) {
                    returnValues.add(method.invoke(next, args));
                }

                return returnValueMerger.apply(returnValues.toArray());
            }
        });
    }

    /**
     * 创建一个代理对象
     *
     * @param targetClass 代理对象类型
     * @param h           InvocationHandler
     * @param <T>         类型
     * @return 代理对象
     */
    public static <T> T getProxy(Class<T> targetClass, InvocationHandler h) {
        return getProxy(null, targetClass, h);
    }

    /**
     * 创建一个代理对象
     *
     * @param targetClass 代理对象类型
     * @param h           InvocationHandler
     * @param <T>         类型
     * @return 代理对象
     */
    public static <T> T getProxy(ClassLoader loader, Class<T> targetClass, InvocationHandler h) {
        if (null == loader) {
            loader = Thread.currentThread().getContextClassLoader();
        }
        if (null == loader) {
            loader = targetClass.getClassLoader();
        }
        if (null == loader) {
            loader = ProxyUtils.class.getClassLoader();
        }
        return getDefaultProxyFactory().getProxy(loader, targetClass, h);
    }

    /**
     * 获取默认的代理工厂
     */
    public static ProxyFactory getDefaultProxyFactory() {
        return DEFAULT;
    }

    private ProxyUtils() {
    }
}
