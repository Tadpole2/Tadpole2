/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.reflect;

import java.lang.reflect.Type;

import static org.ponly.common.reflect.TypeResolver.resolveActualTypeArguments;

/**
 * 泛型类工具类
 * <p>
 * 用于获取泛型类的相应的类型参数
 * <p>
 * 1. 运行时指定
 * <code>
 * <pre>
 *   class A&lt;T&gt; extends GenericBeanSupport&lt;T&gt; {}
 *   new A&lt;String&gt;()  --&gt; getActualTypeArgument() == String.class
 * </pre>
 * </code>
 * 2. 多级继承直接指定
 * <code>
 * <pre>
 *   abstract class B&lt;T, E&gt; extends GenericBeanSupport&lt;T&gt; {}
 *   class C extends B&lt;String,Integer&gt; {}
 *   new C()  --&gt; getActualTypeArgument() == String.class
 * </pre>
 * </code>
 * 3. 多级继承传递运行时指定
 * <code>
 * <pre>
 *    class D&lt;T&gt; extends B&lt;T, String&gt; {}
 *    new D&lt;Integer&gt;() --&gt; getActualTypeArgument() == Integer.class
 * </pre>
 * </code>
 *
 * @author vacoor
 */
public abstract class GenericBeanSupport<T> {
    private Class<T> actualTypeArgument;

    /**
     * 获取当前泛型类的泛型参数, 如果不是一个Class对象将抛出{@link java.lang.IllegalStateException}
     *
     * @return 泛型参数T的Class对象
     */
    @SuppressWarnings("unchecked")
    protected final Class<T> getActualTypeArgument() {
        if (actualTypeArgument != null) {
            return actualTypeArgument;
        }

        Type typeArg = resolveActualTypeArguments(getClass(), GenericBeanSupport.class, 0);
        if (null == typeArg) {
            throw new IllegalStateException("Internal error: without actual type information");
        }

        if (!(typeArg instanceof Class)) {
            throw new IllegalStateException("Internal error: type parameter must be a certain type");
        }
        return actualTypeArgument = (Class<T>) typeArg;
    }

    protected GenericBeanSupport() {}
}
