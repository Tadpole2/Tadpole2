/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.common.util.proxy;

import javassist.util.proxy.MethodHandler;
import javassist.util.proxy.ProxyObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.List;

/**
 * 使用 Javassist 实现的代理工厂
 *
 * @author vacoor
 */
public final class JavassistProxyFactory implements ProxyFactory {
    private static final Logger LOG = LoggerFactory.getLogger(JavassistProxyFactory.class);
    public static final String ENHANCER_NAME = "javassist.util.proxy.ProxyFactory";

    static {
        try {
            Class.forName(ENHANCER_NAME);
        } catch (Throwable e) {
            throw new IllegalStateException("Javassist is not available. Add Javassist to your classpath.", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @SuppressWarnings("unchecked")
    public <T> T getProxy(ClassLoader loader, Class<T> targetClass, InvocationHandler handler) {
        return (T) createProxy(targetClass, handler, true);
    }

    /**
     * 使用给定的 Class, InvocationHandler 创建一个含有给定构造器类型的代理,并使用给定参数创建代理对象
     *
     * @param type 代理超类/接口类型
     * @param h    用于处理代理行为的 {@link InvocationHandler} 实现
     * @return 代理对象
     */
    public static Object createProxy(Class<?> type, InvocationHandler h, boolean override) {
        return createProxy(type, h, override, Collections.<Class<?>>emptyList(), Collections.emptyList());
    }

    /**
     * 使用给定的 Class, InvocationHandler 创建一个含有给定构造器类型的代理,并使用给定参数创建代理对象
     *
     * @param type                代理超类/接口类型
     * @param h                   用于处理代理行为的 {@link InvocationHandler} 实现
     * @param constructorArgTypes 构造器参数类型
     * @param constructorArgs     用户创建代理对象的构造参数
     * @return 代理对象
     */
    public static Object createProxy(Class<?> type, InvocationHandler h, boolean override, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
        return createProxy(type, createCallback(h, override), constructorArgTypes, constructorArgs);
    }

    /**
     * 使用给定的 Class, InvocationHandler 创建一个含有给定构造器类型的代理,并使用给定参数创建代理对象
     *
     * @param type                代理超类/接口类型
     * @param callback            用于处理代理行为的 {@link MethodHandler} 实现
     * @param constructorArgTypes 构造器参数类型
     * @param constructorArgs     用户创建代理对象的构造参数
     * @return 代理对象
     */
    public static Object createProxy(Class<?> type, MethodHandler callback, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
        javassist.util.proxy.ProxyFactory enhancer = createEnhancer();
        if (type.isInterface()) {
            enhancer.setInterfaces(new Class<?>[]{type});
        } else {
            enhancer.setSuperclass(type);
        }

        Object enhanced;
        Class<?>[] typesArray = constructorArgTypes.toArray(new Class[constructorArgTypes.size()]);
        Object[] valuesArray = constructorArgs.toArray(new Object[constructorArgs.size()]);
        try {
            enhanced = enhancer.create(typesArray, valuesArray);
        } catch (Exception e) {
            throw new RuntimeException("Error creating lazy proxy.  Cause: " + e, e);
        }
        ((ProxyObject) enhanced).setHandler(callback);
        return enhanced;
    }

    /**
     * 创建一个 javassist 代理工厂
     */
    private static javassist.util.proxy.ProxyFactory createEnhancer() {
        return new javassist.util.proxy.ProxyFactory();
    }

    /**
     * 创建一个 {@link InvocationHandler} 到 {@link MethodHandler} 的适配对象
     *
     * @param h JDK {@link InvocationHandler}
     * @return JDK {@link InvocationHandler} 的 {@link MethodHandler} 代理对象
     */
    private static MethodHandler createCallback(InvocationHandler h, boolean override) {
        return new InvocationHandlerCallback(h, override);
    }

    /**
     * JDK {@link InvocationHandler} 的 {@link MethodHandler} 代理
     */
    private static class InvocationHandlerCallback implements MethodHandler {
        private final InvocationHandler delegate;
        private final boolean override;

        private InvocationHandlerCallback(final InvocationHandler delegate, final boolean override) {
            this.delegate = delegate;
            this.override = override;
        }

        @Override
        public Object invoke(Object proxy, Method method, Method methodProxy, Object[] args) throws Throwable {
            if (!override && !Modifier.isAbstract(method.getModifiers())) {
                return methodProxy.invoke(proxy, args);
            }
            // delegate abstract method.
            return delegate.invoke(proxy, method, args);
        }
    }
}
