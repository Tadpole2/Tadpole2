package org.ponly.web.util;

import org.ponly.common.reflect.Reflect;
import org.saep.excel.ExcelWriter;
import org.saep.excel.SAEP;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 一个简单的 Excel 下载工具
 */
public abstract class ExcelView<T> extends DownloadView {
    private static final String CONTENT_TYPE = "application/vnd.ms-excel";

    /**
     * The extension to look for existing templates
     */
    private static final String OPEN_OFFICE_EXCEL_EXTENSION = ".xlsx";

    private final Object[] headers;
    private final Iterable<T> data;

    public ExcelView(String filename, Iterable<T> data, Object... headers) {
        super(filename, CONTENT_TYPE, true);
        this.data = data;
        this.headers = headers;
    }

    @Override
    protected void doDownloadInternal(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String filename = getFilename();
        writeTo(response.getOutputStream(), null != filename && filename.endsWith(OPEN_OFFICE_EXCEL_EXTENSION));
    }

    @Override
    protected InputStream getResourceAsStream() {
        throw new UnsupportedOperationException();
    }

    private void writeTo(OutputStream out, boolean excel07) {
        ExcelWriter writer = SAEP.newWriter(out, excel07);
        if (null != headers && 0 < headers.length) {
            writer.writeLine(headers);
        }
        for (T t : data) {
            Object[] line = buildData(t);
            if (null != line && 0 < line.length) {
                writer.writeLine(line);
            }
        }
        writer.close(true);
    }

    protected abstract Object[] buildData(T entry);

    /**
     * 创建一个使用给定 properties 构建数据行的 Excel 视图
     *
     * @param filename   下载的文件名称
     * @param data       下载的数据对象
     * @param headers    数据标题
     * @param properties 导出的数据对象属性
     * @param <T>        数据对象类型
     * @return Excel 视图
     */
    public static <T> ExcelView<T> create(String filename, Iterable<T> data, Object[] headers, final String[] properties) {
        return new ExcelView<T>(filename, data, headers) {

            @Override
            protected Object[] buildData(T entry) {
                Object[] values = new Object[properties.length];
                Reflect reflect = Reflect.from(entry);
                for (int i = 0; i < values.length; i++) {
                    values[i] = reflect.property(properties[i]);
                }
                return values;
            }
        };
    }
}
