package org.ponly.web.servlet.jsp.func;

import org.ponly.common.reflect.Reflect;

import java.util.*;

/**
 */
public abstract class Functions {

    /**
     * 追加给定参数的参数值
     */
    public static Map<String, String[]> merge(Map<String, String[]> params, String p, Object v) {
        Map<String, String[]> clone = clone(params);
        v = null == v ? "" : v;

        String[] newValues = clone.get(p);
        newValues = null == newValues ? new String[1] : Arrays.copyOf(newValues, newValues.length + 1);
        newValues[newValues.length - 1] = String.valueOf(v);

        clone.put(p, newValues);
        return clone;
    }

    /**
     * 用给定的参数值覆盖给定的参数
     *
     * @param params 参数 Map
     * @param p      参数名
     * @param value  新的参数值, 如果值为 null, 则移除该参数
     */
    public static Map<String, String[]> override(Map<String, String[]> params, String p, String value) {
        Map<String, String[]> clone = clone(params);
        if (value == null || "".equals(value)) {
            clone.remove(p);
        } else {
            clone.put(p, new String[]{value});
        }
        return clone;
    }

    /**
     * 移除给定的参数值
     *
     * @param params 参数
     * @param p      参数名
     * @param v      要移除的参数值
     */
    public static Map<String, String[]> remove(Map<String, String[]> params, String p, String v) {
        Map<String, String[]> clone = clone(params);
        String[] values = clone.get(p);
        List<String> newValues = new ArrayList<String>();

        if (null != values) {
            for (String value : values) {
                if (v == value || (null != v && v.equals(value))) {
                    continue;
                }
                newValues.add(value);
            }
            clone.put(p, newValues.toArray(new String[newValues.size()]));
        }
        return clone;
    }


    /**
     * 将给定 Map 转换为 query string (以第一个参数名开头,不是?/&)
     *
     * @param params 参数 Map
     * @return 对应的 query string
     */
    public static String asQuery(Map<String, String[]> params) {
        StringBuilder buff = new StringBuilder();
        for (Map.Entry<String, String[]> param : params.entrySet()) {
            String key = param.getKey();
            String[] values = param.getValue();

            for (String value : values) {
                buff.append("&").append(key).append("=").append(value);
            }
        }
        // return buff.replace(0, 1, "?").toString();
        if (buff.length() > 0) {
            buff.deleteCharAt(0);
        }
        return buff.toString();
    }

    /**
     * @param it
     * @param target
     * @return
     */
    public static boolean contains(Iterable<?> it, Object target) {
        if (null == it) {
            return false;
        }
        for (Object e : it) {
            if (e == target || (e != null && e.equals(target))) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param it
     * @param target
     * @param prop
     * @return
     */
    public static boolean containsEqPropInstance(Iterable<?> it, Object target, String prop) {
        if (null == it || null == target) {
            return false;
        }
        Object value = Reflect.from(target).get(prop);
        for (Object el : it) {
            if (null != el && value.equals(Reflect.from(el).get(prop))) {
                return true;
            }
        }
        return false;
    }

    public static Object find(Iterable<?> it, String prop, Object value) {
        if (null == it) {
            return null;
        }

        String[] path = prop.split("\\.");
        for (Object o : it) {
            final Object obj = o;
            Object val = null;
            for (int i = 0; i < path.length; i++) {
                String m = path[i];
                m = "get" + m.substring(0, 1).toUpperCase() + m.substring(1);
                val = Reflect.from(o).call(m);
                if (null == val) {
                    return null;
                }
                o = val;
            }
            if (val == value || (null != val && val.equals(value))) {
                return obj;
            }
        }

        return null;
    }

    private static <V> Map<String, V> clone(Map<String, V> map) {
        if (map instanceof SortedMap) {
            return new LinkedHashMap<String, V>(map);
        }
        return null != map ? new HashMap<String, V>(map) : new HashMap<String, V>();
    }
}
