package org.ponly.web.servlet;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 403 Forbidden
 *
 * @author vacoor
 */
public class ForbiddenFilter extends AbstractFilter {
    private boolean enabled = true;

    @Override
    public void init() throws ServletException {
        String enabledStr = getInitParam("enabled");
        if (null != enabledStr && !"".equals(enabledStr)) {
            setEnabled(Boolean.valueOf(enabledStr));
        }
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (isEnabled() && response instanceof HttpServletResponse) {
            ((HttpServletResponse) response).sendError(HttpServletResponse.SC_FORBIDDEN);
        } else {
            chain.doFilter(request, response);
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
