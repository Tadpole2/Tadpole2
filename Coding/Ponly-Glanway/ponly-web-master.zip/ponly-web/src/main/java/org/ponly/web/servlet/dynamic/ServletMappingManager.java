package org.ponly.web.servlet.dynamic;

import javax.servlet.*;
import java.io.IOException;
import java.util.AbstractList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 */
class ServletMappingManager {
    private Map<String/*path name*/, List<ServletMapping>> servletMappingMap = new ConcurrentHashMap<String, List<ServletMapping>>();

    public Set<String> getChainNames() {
        return servletMappingMap.keySet();
    }

    FilterChain proxy(FilterChain chain, String chainName) {
        final List<ServletMapping> mappings = servletMappingMap.get(chainName);
        List<Servlet> servlets = new AbstractList<Servlet>() {
            @Override
            public Servlet get(int index) {
                return mappings.get(index).getServlet();
            }

            @Override
            public int size() {
                return mappings.size();
            }
        };
        return new ServletDispatcherFilterChain(servlets, chain);
    }

    class ServletDispatcherFilterChain implements FilterChain {
        private final List<Servlet> servlets;
        private final FilterChain chain;

        public ServletDispatcherFilterChain(List<Servlet> servlets, FilterChain chain) {
            this.servlets = servlets;
            this.chain = chain;
        }

        @Override
        public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
            for (Servlet servlet : servlets) {
                servlet.service(request, response);

                if (response.isCommitted()) {
                    break;
                }
            }
            if (!response.isCommitted()) {
                chain.doFilter(request, response);
            }
        }
    }
}
