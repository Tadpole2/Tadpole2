package org.ponly.web.servlet.dynamic;

import org.ponly.web.util.WebUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 */
class DelegatingServletProxy implements Filter {
    private PatternMatcher pathMatcher = new ServletPathMatcher();
    private ServletMappingManager mgr = new ServletMappingManager();

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void destroy() {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (request instanceof HttpServletRequest && response instanceof HttpServletResponse) {
            chain = getChain(WebUtils.toHttp(request), WebUtils.toHttp(response), chain);
        }
        chain.doFilter(request, response);
    }

    public FilterChain getChain(HttpServletRequest request, HttpServletResponse response, FilterChain chain) {
        final String requestUri = WebUtils.getPathWithinApplication(request);
        for (String pathPattern : mgr.getChainNames()) {
            if (pathMatches(pathPattern, requestUri)) {
                chain = mgr.proxy(chain, pathPattern);
            }
        }
        return chain;
    }

    private boolean pathMatches(String pattern, String path) {
        return pathMatcher.matches(pattern, path);
    }


}
