package org.ponly.web.servlet;

import org.ponly.common.util.ThreadContext;
import org.ponly.common.util.ThreadState;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * WebRequestContextFilter 用于设置 {@link WebRequestContext}
 *
 * @author vacoor
 * @see WebRequestContext
 */
public class WebRequestContextFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        WebRequestContextThreadState contextState = createContextState(httpRequest, httpResponse);

        try {
            if (null != contextState) {
                contextState.bind();
            }
            chain.doFilter(httpRequest, httpResponse);
        } finally {
            if (null != contextState) {
                contextState.restore();
            }
        }
    }

    @Override
    public void destroy() {
    }

    protected WebRequestContextThreadState createContextState(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
        return new WebRequestContextThreadState(httpRequest, httpResponse);
    }

    protected class WebRequestContextThreadState implements ThreadState {
        private Map<Object, Object> originalResources;
        private final HttpServletRequest httpRequest;
        private final HttpServletResponse httpResponse;
        private transient WebRequestContext requestContext;

        public WebRequestContextThreadState(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
            this.httpRequest = httpRequest;
            this.httpResponse = httpResponse;
        }

        @Override
        public void bind() {
            this.originalResources = ThreadContext.getResources();
            ThreadContext.remove();

            this.requestContext = WebRequestContext.begin(httpRequest, httpResponse, getServletContext());
        }

        @Override
        public void restore() {
            if (null != requestContext) {
                requestContext.end();
            }

            ThreadContext.remove();
            if (null != this.originalResources && !this.originalResources.isEmpty()) {
                ThreadContext.setResources(this.originalResources);
            }
        }

        @Override
        public void clear() {
            ThreadContext.remove();
        }

        public HttpServletRequest getHttpRequest() {
            return httpRequest;
        }

        public HttpServletResponse getHttpResponse() {
            return httpResponse;
        }

        public WebRequestContext getRequestContext() {
            return requestContext;
        }

    }

    private static String buildLogMessage(HttpServletRequest httpRequest, long duration, boolean systemError, int responseSize) {
        final StringBuilder msg = new StringBuilder();

        String remoteAddr = httpRequest.getRemoteAddr();
        if ("0:0:0:0:0:0:0:1".equals(remoteAddr)) {
            remoteAddr = "127.0.0.1";
        }
        msg.append("remoteAddr = ").append(remoteAddr);
        try {
            //  msg.append("(").append(new TaobaoIPLocator().locate(remoteAddr)).append(")");
        } catch (Exception ignore) {/* ignore */}

        final String forwardedFor = httpRequest.getHeader("X-Forwarded-For");
        if (forwardedFor != null) {
            msg.append(", forwardedFor = ").append(forwardedFor);
        }
        // msg.append(", request = ").append(httpRequest.getRequestURI().substring(httpRequest.getContextPath().length()));
        msg.append(", request = ").append(httpRequest.getRequestURI().substring(httpRequest.getContextPath().length()));
        if (httpRequest.getQueryString() != null) {
            msg.append('?').append(httpRequest.getQueryString());
        }
        msg.append(' ').append(httpRequest.getMethod());
        msg.append(": ").append(duration).append(" ms");
        if (systemError) {
            msg.append(", erreur");
        }
        msg.append(", ").append(responseSize / 1024).append(" Ko");
        return msg.toString();
    }
}
