package org.ponly.web.servlet;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.ponly.web.util.WebUtils.*;

/**
 */
public class GzipFilter extends OncePerRequestFilter {
    private static final int DEFAULT_BUFFER_SIZE = 8192;
    private int buffSize;

    @Override
    public void init() throws ServletException {
        int size = DEFAULT_BUFFER_SIZE;
        String buff = getInitParam("buff");
        if (null != buff) {
            size = Integer.valueOf(buff);
        }
        this.buffSize = size;
    }

    @Override
    protected void doFilterInternal(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest httpRequest = toHttp(request);
        HttpServletResponse httpResponse = toHttp(response);

        if (!isGzipSupported(httpRequest) || response instanceof GzipHttpResponseWrapper) {
            chain.doFilter(request, response);
            return;
        }

        int buff = 1 > this.buffSize ? this.buffSize : DEFAULT_BUFFER_SIZE;
        GzipHttpResponseWrapper gzipHttpResponse = new GzipHttpResponseWrapper(httpResponse, buff);
        try {
            chain.doFilter(request, gzipHttpResponse);
        } finally {
            gzipHttpResponse.finish();
        }
    }
}
