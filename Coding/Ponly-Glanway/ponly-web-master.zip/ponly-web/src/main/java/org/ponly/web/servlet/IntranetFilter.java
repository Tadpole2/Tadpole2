package org.ponly.web.servlet;

import org.ponly.common.util.IPAddress;
import org.ponly.web.util.WebUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

import static org.ponly.web.util.WebUtils.getRequestClientIP;
import static org.ponly.web.util.WebUtils.toHttp;

/**
 * 内部网络访问过滤器
 */
public class IntranetFilter extends AbstractFilter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        IPAddress ip = getRequestClientIP(toHttp(request));
        if (ip.isClassA() || ip.isClassB() || ip.isClassC()) {
            chain.doFilter(request, response);
        } else {
            WebUtils.toHttp(response).sendError(403, "Not intranet.");
        }
    }

}
