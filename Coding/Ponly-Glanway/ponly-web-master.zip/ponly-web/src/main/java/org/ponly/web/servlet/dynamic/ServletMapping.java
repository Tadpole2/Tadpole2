package org.ponly.web.servlet.dynamic;

import javax.servlet.Servlet;

/**
 */
class ServletMapping {
    private final String [] pathPatterns;
    private final Servlet servlet;

    public ServletMapping(String[] pathPatterns, Servlet servlet) {
        this.pathPatterns = pathPatterns;
        this.servlet = servlet;
    }

    public String[] getPathPatterns() {
        return pathPatterns;
    }

    public Servlet getServlet() {
        return servlet;
    }
}
