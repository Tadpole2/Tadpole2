package org.ponly.web.servlet;

import javax.servlet.Filter;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import java.util.Enumeration;

/**
 * 抽象 Filter 提供便捷获取 Filter 配置方法
 *
 * @author vacoor
 */
public abstract class AbstractFilter implements Filter {
    protected transient FilterConfig config;

    public void init() throws ServletException {
    }

    @Override
    public void destroy() {
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.config = filterConfig;
        this.init();
    }

    protected String getName() {
        return getRequiredFilterConfig().getFilterName();
    }

    protected String getInitParam(String s) {
        return getRequiredFilterConfig().getInitParameter(s);
    }

    @SuppressWarnings("unchecked")
    public Enumeration<String> getInitParamNames() {
        return getRequiredFilterConfig().getInitParameterNames();
    }

    protected ServletContext getServletContext() {
        return getRequiredFilterConfig().getServletContext();
    }

    protected FilterConfig getFilterConfig() {
        return this.config;
    }

    private FilterConfig getRequiredFilterConfig() {
        FilterConfig filterConfig = getFilterConfig();
        if (null == filterConfig) {
            throw new IllegalStateException("filter config not initialized");
        }
        return filterConfig;
    }
}
