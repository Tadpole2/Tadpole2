package org.ponly.spring.namespace;

import org.springframework.aop.framework.ProxyFactoryBean;
import org.springframework.aop.target.LazyInitTargetSource;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

import static org.springframework.beans.factory.support.BeanDefinitionBuilder.rootBeanDefinition;

/**
 */
public abstract class ParsingUtils {

    /**
     * Configures a property value for the given property name reading the attribute of the given name from the given
     * {@link Element} if the attribute is configured.
     *
     * @param builder   must not be {@literal null}.
     * @param element   must not be {@literal null}.
     * @param attribute must not be {@literal null} or empty.
     * @param property  must not be {@literal null} or empty.
     */
    public static void setPropertyValue(BeanDefinitionBuilder builder, Element element, String attribute, String property) {

        Assert.notNull(builder, "BeanDefinitionBuilder must not be null!");
        Assert.notNull(element, "Element must not be null!");
        Assert.hasText(attribute, "Attribute name must not be null!");
        Assert.hasText(property, "Property name must not be null!");

        String value = element.getAttribute(attribute);

        if (StringUtils.hasText(value)) {
            builder.addPropertyValue(property, value);
        }
    }

    /**
     * Configures a bean property reference with the value of the attribute of the given name if it is configured.
     *
     * @param builder   must not be {@literal null}.
     * @param element   must not be {@literal null}.
     * @param attribute must not be {@literal null} or empty.
     * @param property  must not be {@literal null}or empty.
     */
    public static void setPropertyReference(BeanDefinitionBuilder builder, Element element, String attribute, String property) {

        Assert.notNull(builder, "BeanDefinitionBuilder must not be null!");
        Assert.notNull(element, "Element must not be null!");
        Assert.hasText(attribute, "Attribute name must not be null!");
        Assert.hasText(property, "Property name must not be null!");

        String value = element.getAttribute(attribute);

        if (StringUtils.hasText(value)) {
            builder.addPropertyReference(property, value);
        }
    }

    /**
     * Configures a bean property lazy reference with the value of the attribute of the given name if it is configured.
     *
     * @param builder   must not be {@literal null}.
     * @param element   must not be {@literal null}.
     * @param attribute must not be {@literal null} or empty.
     * @param property  must not be {@literal null}or empty.
     */
    public static void setPropertyLazyReference(BeanDefinitionBuilder builder, Element element, String attribute, String property) {

        Assert.notNull(builder, "BeanDefinitionBuilder must not be null!");
        Assert.notNull(element, "Element must not be null!");
        Assert.hasText(attribute, "Attribute name must not be null!");
        Assert.hasText(property, "Property name must not be null!");

        String value = element.getAttribute(attribute);

        if (StringUtils.hasText(value)) {
            builder.addPropertyValue(property, createLazyInitTargetSourceBeanDefinition(value));
        }
    }

    public static void setPropertyBeanDefinition(BeanDefinitionBuilder builder, Element element, String attribute, String property) {
        Assert.notNull(builder, "BeanDefinitionBuilder must not be null!");
        Assert.notNull(element, "Element must not be null!");
        Assert.hasText(attribute, "Attribute name must not be null!");
        Assert.hasText(property, "Property name must not be null!");

        String value = element.getAttribute(attribute);

        if (StringUtils.hasText(value)) {
            builder.addPropertyValue(property, rootBeanDefinition(value).getBeanDefinition());
        }
    }

    public static BeanDefinition createLazyInitTargetSourceBeanDefinition(String targetBeanName) {
        BeanDefinitionBuilder targetSourceBuilder = rootBeanDefinition(LazyInitTargetSource.class);
        targetSourceBuilder.addPropertyValue("targetBeanName", targetBeanName);

        BeanDefinitionBuilder builder = rootBeanDefinition(ProxyFactoryBean.class);
        builder.addPropertyValue("targetSource", targetSourceBuilder.getBeanDefinition());

        return builder.getBeanDefinition();
    }

    private ParsingUtils() {
    }
}
