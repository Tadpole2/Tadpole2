package org.ponly.spring.namespace;

import org.ponly.web.servlet.WebContextFilter;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.w3c.dom.Element;

import static org.ponly.spring.namespace.ParsingUtils.*;

/**
 * @author vacoor
 */
class WebContextFilterBeanDefinitionParser extends AbstractSingleBeanDefinitionParser {
    @Override
    protected boolean shouldGenerateIdAsFallback() {
        return true;
    }

    @Override
    protected Class<?> getBeanClass(Element element) {
        return WebContextFilter.class;
    }

    @Override
    protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
        super.doParse(element, parserContext, builder);

        setPropertyReference(builder, element, "config-manager-ref", "configManager");
        setPropertyReference(builder, element, "nls-bundle-manager-ref", "nlsBundleManager");
    }
}
