package org.ponly.solr;

import org.apache.solr.core.CoreContainer;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;

/**
 * Solr webapp 过滤器 FactoryBean
 * @author vacoor
 */
public class SolrWebAppDispatchFilterFactoryBean extends SolrCoreContainerFactoryBase implements FactoryBean<SolrWebAppDispatchFilter>, DisposableBean {
    private SolrWebAppDispatchFilter solrDispatchFilter;
    private CoreContainer coreContainer;

    public SolrWebAppDispatchFilter getSolrDispatchFilter() {
        if (null == solrDispatchFilter) {
            initSolrDispatchFilter();
        }
        return solrDispatchFilter;
    }

    protected void initSolrDispatchFilter() {
        if (null == coreContainer) {
            setCoreContainer(createSolrCoreContainer());
        }

        this.solrDispatchFilter = new SolrWebAppDispatchFilter() {
            @Override
            protected CoreContainer createCoreContainer() {
                return getCoreContainer();
            }
        };
    }

    @Override
    public void destroy() throws Exception {
        if (null != coreContainer) {
            if (!coreContainer.isShutDown()) {
                coreContainer.shutdown();
            }
        }
    }

    @Override
    public SolrWebAppDispatchFilter getObject() throws Exception {
        return getSolrDispatchFilter();
    }

    @Override
    public Class<?> getObjectType() {
        return SolrWebAppDispatchFilter.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

    public CoreContainer getCoreContainer() {
        return coreContainer;
    }

    public void setCoreContainer(CoreContainer coreContainer) {
        this.coreContainer = coreContainer;
    }
}
