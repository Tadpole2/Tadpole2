package org.ponly.spring.namespace;

import org.ponly.spring.nls.NlsBundleManagerMessageSource;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
import org.w3c.dom.Element;

import static org.ponly.spring.namespace.ParsingUtils.setPropertyReference;

/**
 * @author vacoor
 */
public class NlsBundleManagerMessageSourceBeanDefinitionParser extends AbstractSingleBeanDefinitionParser {

    @Override
    protected boolean shouldGenerateIdAsFallback() {
        return true;
    }

    @Override
    protected Class<?> getBeanClass(Element element) {
        return NlsBundleManagerMessageSource.class;
    }

    @Override
    protected void doParse(Element element, BeanDefinitionBuilder builder) {
        super.doParse(element, builder);
        setPropertyReference(builder, element, "nls-bundle-manager-ref", "nlsBundleManager");
    }
}