package org.ponly.shiro;

import org.apache.shiro.authc.AuthenticationException;

/**
 */
public class IncorrectCaptchaException extends AuthenticationException {
    public IncorrectCaptchaException() {
    }

    public IncorrectCaptchaException(final String message) {
        super(message);
    }

    public IncorrectCaptchaException(final Throwable cause) {
        super(cause);
    }

    public IncorrectCaptchaException(final String message, Throwable cause) {
        super(message, cause);
    }
}
