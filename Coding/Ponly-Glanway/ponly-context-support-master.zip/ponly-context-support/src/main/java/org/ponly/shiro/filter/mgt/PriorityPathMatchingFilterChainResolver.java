package org.ponly.shiro.filter.mgt;

import org.apache.shiro.util.AntPathMatcher;
import org.apache.shiro.util.PatternMatcher;
import org.apache.shiro.web.filter.mgt.FilterChainManager;
import org.apache.shiro.web.filter.mgt.PathMatchingFilterChainResolver;

import javax.servlet.FilterChain;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.util.*;

/**
 */
public class PriorityPathMatchingFilterChainResolver extends PathMatchingFilterChainResolver {
    private boolean enabledPriority;

    @Override
    public FilterChain getChain(ServletRequest request, ServletResponse response, FilterChain originalChain) {
        FilterChainManager filterChainManager = getFilterChainManager();
        if (!filterChainManager.hasChains()) {
            return null;
        }

        String requestURI = getPathWithinApplication(request);

        //the 'chain names' in this implementation are actually path patterns defined by the user.  We just use them
        //as the chain name for the FilterChainManager's requirements
        List<String> matchedPatterns = new ArrayList<String>();
        for (String pathPattern : filterChainManager.getChainNames()) {
            // If the path does match, then pass on to the subclass implementation for specific checks:
            if (pathMatches(pathPattern, requestURI)) {
                /*
                if (log.isTraceEnabled()) {
                    log.trace("Matched path pattern [" + pathPattern + "] for requestURI [" + requestURI + "].  " +
                            "Utilizing corresponding filter chain...");
                }
                */
                if (!enabledPriority) {
                    return filterChainManager.proxy(originalChain, pathPattern);
                }
            }
        }

        return 1 > matchedPatterns.size() ? null : getPriorityChain(requestURI, originalChain, unique(matchedPatterns));
    }

    protected List<String> unique(List<String> collections) {
        if (null == collections || 1 > collections.size()) {
            return collections;
        }
        List<String> uniqueMatchedPatterns = new ArrayList<String>();
        for (String matchedPattern : collections) {
            if (uniqueMatchedPatterns.contains(matchedPattern)) {
                continue;
            }
            uniqueMatchedPatterns.add(matchedPattern);
        }
        return uniqueMatchedPatterns;
    }

    protected FilterChain getPriorityChain(final String requestUri, FilterChain originalChain, List<String> uniqueMatchedPatterns) {
        PatternMatcher pathMatcher = getPathMatcher();

        if (pathMatcher instanceof AntPathMatcher) {
            final AntPathMatcher patcher = (AntPathMatcher) pathMatcher;
            Collections.sort(uniqueMatchedPatterns, new Comparator<String>() {
                @Override
                public int compare(String pattern1, String pattern2) {
                    String patternPath1 = patcher.extractPathWithinPattern(pattern1, requestUri);
                    String patternPath2 = patcher.extractPathWithinPattern(pattern2, requestUri);
                    return patternPath1.length() < patternPath2.length() ? -1 : (patternPath1.length() > patternPath2.length() ? 1 : 0);
                }
            });
        }

        // 获取匹配度最高的 chainName
        uniqueMatchedPatterns = 0 < uniqueMatchedPatterns.size()
                ? Arrays.asList(uniqueMatchedPatterns.get(0))
                : Collections.<String>emptyList();
        return proxy(originalChain, uniqueMatchedPatterns);
    }

    protected FilterChain proxy(FilterChain originalChain, List<String> chainNames) {
        FilterChain chain = originalChain;
        FilterChainManager filterChainManager = getFilterChainManager();
        for (int i = chainNames.size(); i > 0; i--) {
            String chainName = chainNames.get(i - 1);
            if (null != chainName) {
                chain = filterChainManager.proxy(chain, chainName);
            }
        }
        return chain;
    }
}
