package org.ponly.solr;

import org.apache.solr.core.CoreContainer;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;

/**
 * Solr Core Container Factory Bean
 *
 * @author vacoor
 */
public class SolrCoreContainerFactoryBean extends SolrCoreContainerFactoryBase implements FactoryBean<CoreContainer>, DisposableBean {
    private CoreContainer coreContainer;

    public CoreContainer getSolrCoreContainer() {
        if (null == coreContainer) {
            this.coreContainer = createSolrCoreContainer();
        }
        return coreContainer;
    }

    @Override
    public void destroy() throws Exception {
        if (null != coreContainer) {
            if (!coreContainer.isShutDown()) {
                coreContainer.shutdown();
            }
        }
    }

    @Override
    public CoreContainer getObject() throws Exception {
        return getSolrCoreContainer();
    }

    @Override
    public Class<?> getObjectType() {
        return CoreContainer.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }
}
