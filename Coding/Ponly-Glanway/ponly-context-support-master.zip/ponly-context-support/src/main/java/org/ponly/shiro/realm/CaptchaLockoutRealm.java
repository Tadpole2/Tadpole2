package org.ponly.shiro.realm;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.util.StringUtils;
import org.ponly.shiro.authc.UsernamePasswordCaptchaToken;

/**
 */
public abstract class CaptchaLockoutRealm extends LockoutJdbcRealm {
    private static int DEFAULT_CAPTCHA_FOR_RETRIES = 3;
    private int captchaForRetries = DEFAULT_CAPTCHA_FOR_RETRIES;

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(final AuthenticationToken authenticationToken) throws AuthenticationException {
        final UsernamePasswordCaptchaToken upct = (UsernamePasswordCaptchaToken) authenticationToken;
        final String username = upct.getUsername();
        if (!StringUtils.hasText(username)) {
            throw new UnknownAccountException("username or password is invalid");
        }

        final LockoutJdbcRealm.Lock lock = getAuthenticationLock(authenticationToken);
        final int reties = lock.getCount();
        if (captchaForRetries < reties) {
            assertCaptchaMatch(upct);
        }

        return super.doGetAuthenticationInfo(authenticationToken);
    }

    protected abstract void assertCaptchaMatch(final UsernamePasswordCaptchaToken token) throws AuthenticationException;

    public int getCaptchaForRetries() {
        return captchaForRetries;
    }

    public void setCaptchaForRetries(int captchaForRetries) {
        this.captchaForRetries = captchaForRetries;
    }
}
