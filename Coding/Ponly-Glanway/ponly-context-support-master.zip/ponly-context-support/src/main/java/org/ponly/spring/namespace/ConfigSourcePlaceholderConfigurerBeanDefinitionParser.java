package org.ponly.spring.namespace;

import org.ponly.spring.support.ConfigSourcePlaceholderConfigurer;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
import org.springframework.util.StringUtils;
import org.w3c.dom.Element;

import static org.ponly.spring.namespace.ParsingUtils.setPropertyLazyReference;

/**
 * 配置源占位符解析器
 * {@link ConfigSourcePlaceholderConfigurer}
 *
 * @author vacoor
 */
class ConfigSourcePlaceholderConfigurerBeanDefinitionParser extends AbstractSingleBeanDefinitionParser {

    @Override
    protected boolean shouldGenerateIdAsFallback() {
        return true;
    }

    @Override
    protected Class<?> getBeanClass(Element element) {
        return ConfigSourcePlaceholderConfigurer.class;
    }

    @Override
    protected void doParse(Element element, BeanDefinitionBuilder builder) {
        super.doParse(element, builder);
        setPropertyLazyReference(builder, element, "config-manager-ref", "configManager");
        // builder.addPropertyValue("ignoreResourceNotFound", true);
        // builder.addPropertyValue("ignoreUnresolvablePlaceholders", true);

        String location = element.getAttribute("static-props-location");
        if (StringUtils.hasLength(location)) {
            String[] locations = StringUtils.commaDelimitedListToStringArray(location);
            builder.addPropertyValue("locations", locations);
        }
    }
}