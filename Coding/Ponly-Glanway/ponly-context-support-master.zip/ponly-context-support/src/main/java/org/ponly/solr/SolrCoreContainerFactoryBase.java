package org.ponly.solr;

import org.apache.solr.core.CoreContainer;
import org.springframework.beans.BeanInstantiationException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.util.ClassUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StringUtils;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.net.URLDecoder;

/**
 * @author vacoor
 */
public abstract class SolrCoreContainerFactoryBase {
    private static final String SOLR_HOME_SYSTEM_PROPERTY = "solr.solr.home";

    protected String solrHome;

    protected CoreContainer createSolrCoreContainer() {
        try {
            return createPathConfiguredSolrServer(this.solrHome);
        } catch (ParserConfigurationException e) {
            throw new BeanInstantiationException(SolrWebAppDispatchFilter.class, e.getMessage(), e);
        } catch (IOException e) {
            throw new BeanInstantiationException(SolrWebAppDispatchFilter.class, e.getMessage(), e);
        } catch (SAXException e) {
            throw new BeanInstantiationException(SolrWebAppDispatchFilter.class, e.getMessage(), e);
        }
    }

    /**
     * @param path Any Path expression valid for use with {@link ResourceUtils}
     * @return new instance of {@link org.apache.solr.client.solrj.embedded.EmbeddedSolrServer}
     * @throws ParserConfigurationException
     * @throws IOException
     * @throws SAXException
     */
    public final CoreContainer createPathConfiguredSolrServer(String path) throws ParserConfigurationException,
            IOException, SAXException {
        String solrHomeDirectory = System.getProperty(SOLR_HOME_SYSTEM_PROPERTY);

        if (!StringUtils.hasText(solrHomeDirectory)) {
            solrHomeDirectory = ResourceUtils.getURL(path).getPath();
        }

        solrHomeDirectory = URLDecoder.decode(solrHomeDirectory, "utf-8");

        return createCoreContainer(solrHomeDirectory);
    }

    private CoreContainer createCoreContainer(String solrHomeDirectory) {
        File solrXmlFile = new File(solrHomeDirectory + "/solr.xml");
        if (ClassUtils.hasConstructor(CoreContainer.class, String.class, File.class)) {
            return createCoreContainerViaConstructor(solrHomeDirectory, solrXmlFile);
        }
        return createCoreContainer(solrHomeDirectory, solrXmlFile);
    }

    /**
     * Create {@link CoreContainer} via its constructor (Solr 3.6.0 - 4.3.1)
     *
     * @param solrHomeDirectory
     * @param solrXmlFile
     * @return
     */
    private CoreContainer createCoreContainerViaConstructor(String solrHomeDirectory, File solrXmlFile) {
        Constructor<CoreContainer> constructor = ClassUtils.getConstructorIfAvailable(
                CoreContainer.class, String.class, File.class
        );
        return BeanUtils.instantiateClass(constructor, solrHomeDirectory, solrXmlFile);
    }

    /**
     * Create {@link CoreContainer} for Solr version 4.4+
     *
     * @param solrHomeDirectory
     * @param solrXmlFile
     * @return
     */
    private CoreContainer createCoreContainer(String solrHomeDirectory, File solrXmlFile) {
        return CoreContainer.createAndLoad(solrHomeDirectory, solrXmlFile);
    }

    public String getSolrHome() {
        return solrHome;
    }

    public void setSolrHome(String solrHome) {
        this.solrHome = solrHome;
    }
}
