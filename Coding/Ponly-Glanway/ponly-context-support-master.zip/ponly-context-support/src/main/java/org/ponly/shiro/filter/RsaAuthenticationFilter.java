/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.shiro.filter;

import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.codec.Base64;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.servlet.Cookie;
import org.apache.shiro.web.servlet.SimpleCookie;
import org.ponly.common.util.Bytes;

import javax.crypto.Cipher;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

/**
 * redirect=1&redirectUrl=&style=mini
 * https://login.taobao.com/member/login.jhtml?style=mini&redirectURL=
 *
 * @author vacoor
 */
public class RsaAuthenticationFilter extends AuthenticationFilter {
    public static final String PRIVATE_KEY = RsaAuthenticationFilter.class + ".PRIVATE_KEY";
    private static final int BIT_SIZE = 1024;
    public static final boolean DEFAULT_ENABLED_RSA_PASSWORD = true;
    public static final String DEFAULT_PUBLIC_KEY_COOKIE_NAME = "npk";

    private boolean enabledRsaPassword = DEFAULT_ENABLED_RSA_PASSWORD;
    private Cookie cookie;

    public RsaAuthenticationFilter() {
        Cookie cookie = new SimpleCookie(DEFAULT_PUBLIC_KEY_COOKIE_NAME);
        cookie.setHttpOnly(false);

        this.cookie = cookie;
    }

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        boolean allowed = super.onAccessDenied(request, response);

        if (enabledRsaPassword && isLoginRequest(request, response)) {
            // if request login page or (login submit but login failed)
            if (!isLoginSubmission(request, response) || (isLoginSubmission(request, response) && !allowed)) {
                KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
                generator.initialize(BIT_SIZE);
                KeyPair keyPair = generator.generateKeyPair();
                RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
                Session session = getSubject(request, response).getSession();
                session.setAttribute(PRIVATE_KEY, privateKey);

                RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
                BigInteger modulus = publicKey.getModulus();
                BigInteger exponent = publicKey.getPublicExponent();

                String base64 = Base64.encodeToString(modulus.toByteArray()) + ":" + Base64.encodeToString(exponent.toByteArray());
                Cookie cookie = new SimpleCookie(this.cookie);
                cookie.setValue(base64);
                cookie.saveTo((HttpServletRequest) request, (HttpServletResponse) response);
            }
        }

        return allowed;
    }

    @Override
    protected boolean onLoginSuccess(AuthenticationToken token, Subject subject, ServletRequest request, ServletResponse response) throws Exception {
        cookie.removeFrom((HttpServletRequest) request, (HttpServletResponse) response);
        return super.onLoginSuccess(token, subject, request, response);
    }

    @Override
    protected AuthenticationToken createToken(ServletRequest request, ServletResponse response) {
        String username = getUsername(request);
        String password = getPassword(request);

        if (enabledRsaPassword) {
            try {
                RSAPrivateKey privateKey = (RSAPrivateKey) getSubject(request, response).getSession().getAttribute(PRIVATE_KEY);
                byte[] encoded = Base64.decode(password);
                Cipher cipher = Cipher.getInstance("RSA");
                cipher.init(Cipher.DECRYPT_MODE, privateKey);
                byte[] bytes = cipher.doFinal(encoded);
                password = Bytes.toString(bytes);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return createToken(username, password, request, response);
    }
}
