package org.ponly.spring.namespace;

//import org.ponly.captcha.support.SimpleCaptchaServiceImpl;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.w3c.dom.Element;

import static org.ponly.spring.namespace.ParsingUtils.setPropertyReference;
import static org.ponly.spring.namespace.ParsingUtils.setPropertyValue;

/**
 * @author vacoor
 */
public class CaptchaServiceBeanDefinitionParser extends AbstractSingleBeanDefinitionParser {
    @Override
    protected boolean shouldGenerateIdAsFallback() {
        return true;
    }

    @Override
    protected Class<?> getBeanClass(Element element) {
//        return SimpleCaptchaServiceImpl.class;
        return null;
    }

    @Override
    protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
        super.doParse(element, parserContext, builder);

        setPropertyValue(builder, element, "timeout", "timeout");
        setPropertyReference(builder, element, "captcha-engine-ref", "captchaEngine");
        setPropertyReference(builder, element, "captcha-dao-ref", "captchaDao");
        setPropertyReference(builder, element, "captcha-validation-scheduler-ref", "imageCaptchaValidationScheduler");
        setPropertyValue(builder, element, "validation-enabled", "validationSchedulerEnabled");
        setPropertyValue(builder, element, "validation-interval", "validationInterval");
    }
}
