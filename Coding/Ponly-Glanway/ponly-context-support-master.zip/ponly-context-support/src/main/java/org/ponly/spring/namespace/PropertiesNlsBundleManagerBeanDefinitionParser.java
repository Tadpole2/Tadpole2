package org.ponly.spring.namespace;

import org.ponly.nls.mgt.PropertyNlsBundleManager;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
import org.w3c.dom.Element;

import static org.ponly.spring.namespace.ParsingUtils.setPropertyReference;
import static org.ponly.spring.namespace.ParsingUtils.setPropertyValue;

/**
 * 基于 properties 文件的本地语言支持管理器定义解析器
 * {@link PropertyNlsBundleManager}
 *
 * @author vacoor
 */
class PropertiesNlsBundleManagerBeanDefinitionParser extends AbstractSingleBeanDefinitionParser {

    @Override
    protected boolean shouldGenerateIdAsFallback() {
        return true;
    }

    @Override
    protected Class<?> getBeanClass(Element element) {
        return PropertyNlsBundleManager.class;
    }

    @Override
    protected void doParse(Element element, BeanDefinitionBuilder builder) {
        super.doParse(element, builder);
        setPropertyValue(builder, element, "basename", "basename");
        setPropertyValue(builder, element, "text-locale", "textLocale");
        setPropertyReference(builder, element, "plugin-manager-ref", "pluginManager");
    }
}