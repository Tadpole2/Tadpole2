/**
 * SolrServer configuration and spring integration.
 */
package org.ponly.solr.server;