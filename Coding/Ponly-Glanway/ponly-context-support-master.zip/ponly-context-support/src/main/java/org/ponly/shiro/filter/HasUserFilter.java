package org.ponly.shiro.filter;

import org.apache.shiro.web.filter.authc.UserFilter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import static org.ponly.web.util.WebUtils.isAsyncRequest;
import static org.ponly.web.util.WebUtils.toHttp;

/**
 * 仅仅是增加了异步支持, 默认会重定向到登录页面
 */
public class HasUserFilter extends UserFilter {
    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        if (isAsyncRequest(toHttp(request))) {
            HttpServletResponse httpResponse = toHttp(response);
            /**
             * Http 401 未授权包含: 1. ACL 2. 未登录 3. ... 因为
             * org.apache.shiro.web.filter.authz.AuthorizationFilter.onAccessDenied()
             * 中已经使用了 401 这里需要区别
             */
            httpResponse.setHeader("X-UNAUTHORIZED-TYPE", "UNAUTHENTICATED");
            httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, "UNAUTHENTICATED");
            return false;
        } else {
            return super.onAccessDenied(request, response);
        }
    }
}
