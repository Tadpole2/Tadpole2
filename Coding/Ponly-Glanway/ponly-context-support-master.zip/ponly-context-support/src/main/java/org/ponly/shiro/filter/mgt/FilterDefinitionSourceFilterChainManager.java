/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.shiro.filter.mgt;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.shiro.util.CollectionUtils;
import org.apache.shiro.web.filter.mgt.DefaultFilterChainManager;
import org.apache.shiro.web.filter.mgt.NamedFilterList;

import javax.servlet.FilterConfig;
import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 对于每个请求
 * AbstractShiroFilter#doFilterInternal --> executeChain --> getExecutionChain --> resolver.getChain --> getFilterChainManager() --> matches(getChainNames)
 *
 * @author vacoor
 */
public class FilterDefinitionSourceFilterChainManager extends DefaultFilterChainManager {
    private final ReadWriteLock lock = new ReentrantReadWriteLock();
    private final Lock readLock = lock.readLock();
    private final Lock writeLock = lock.writeLock();

    private Map<String, String> staticFilterChainDefinitionMap;
    private List<FilterDefinitionSource> filterDefinitionSources;
    private boolean sourceChainFirst = true;

    public FilterDefinitionSourceFilterChainManager() {
        staticFilterChainDefinitionMap = Maps.newLinkedHashMap();
        filterDefinitionSources = Lists.newArrayList();
    }

    public FilterDefinitionSourceFilterChainManager(FilterConfig filterConfig) {
        super(filterConfig);
        staticFilterChainDefinitionMap = Maps.newLinkedHashMap();
        filterDefinitionSources = Lists.newArrayList();
    }

    public void reconfigure() {
        writeLock.lock();
        final Map<String, NamedFilterList> origFilterChains = Maps.newLinkedHashMap(getFilterChains());
        try {

            Map<String, String> dynamicChains = Maps.newLinkedHashMap();
            Map<String, String> defaultChains = getStaticFilterChainDefinitionMap();

            for (FilterDefinitionSource source : filterDefinitionSources) {
                dynamicChains.putAll(source.getFilterDefinitions());
            }

            getFilterChains().clear();

            if (sourceChainFirst) {
                createChain(dynamicChains);
                createChain(defaultChains);
            } else {
                createChain(defaultChains);
                createChain(dynamicChains);
            }
            System.out.println();
        } catch (RuntimeException ex) {
            setFilterChains(origFilterChains);
            throw ex;
        } finally {
            writeLock.unlock();
        }
    }

    protected void createChain(Map<String, String> chainDefinitionMap) {
        if (!CollectionUtils.isEmpty(chainDefinitionMap)) {
            for (Map.Entry<String, String> entry : chainDefinitionMap.entrySet()) {
                String url = entry.getKey();
                String chainDefinition = entry.getValue();
                createChain(url, chainDefinition);
            }
        }
    }

    @Override
    public NamedFilterList getChain(String chainName) {
        readLock.lock();
        try {
            return super.getChain(chainName);
        } finally {
            readLock.unlock();
        }
    }


    @Override
    public Set<String> getChainNames() {
        readLock.lock();
        try {
            return super.getChainNames();
        } finally {
            readLock.unlock();
        }
    }

    public List<FilterDefinitionSource> getFilterDefinitionSources() {
        return filterDefinitionSources;
    }

    @SuppressWarnings("unchecked")
    public void setFilterDefinitionSources(List<FilterDefinitionSource> filterDefinitionSources) {
        this.filterDefinitionSources = null != filterDefinitionSources ? filterDefinitionSources : Collections.<FilterDefinitionSource>emptyList();
        afterFilterDefinitionSourcesSet();
    }

    protected void afterFilterDefinitionSourcesSet() {
        Collections.sort(filterDefinitionSources, new Comparator<FilterDefinitionSource>() {
            @Override
            public int compare(FilterDefinitionSource o1, FilterDefinitionSource o2) {
                if (o1 == o2) return 0;
                if (null == o1) return -1;
                Integer order1 = o1.getOrder();
                Integer order2 = o2.getOrder();
                if (order1 == order2) return 0;
                if (null == order1) return -1;
                return order1.compareTo(order2);
            }
        });
    }

    public void setStaticFilterChainDefinitionMap(Map<String, String> staticFilterChainDefinitionMap) {
        this.staticFilterChainDefinitionMap = staticFilterChainDefinitionMap;
    }

    public Map<String, String> getStaticFilterChainDefinitionMap() {
        return staticFilterChainDefinitionMap;
    }

    public boolean isSourceChainFirst() {
        return sourceChainFirst;
    }

    public void setSourceChainFirst(boolean sourceChainFirst) {
        this.sourceChainFirst = sourceChainFirst;
    }

}
