package org.ponly.solr.server.support;

import org.springframework.util.ClassUtils;

public final class VersionUtil {

    private VersionUtil() {
        // hide utility class constructor
    }

    private static final boolean IS_SOLR_3_X_AVAILABLE = isPresent("org.apache.solr.client.solrj.impl.CommonsHttpSolrServer");

    private static final boolean IS_SOLR_4_2_AVAILABLE = isPresent("org.apache.solr.parser.ParseException");

    private static final boolean IS_SOLR_4_X_AVAILABLE = isPresent("org.apache.solr.client.solrj.impl.CloudSolrServer");

    /**
     * @return true if {@link org.apache.solr.client.solrj.impl.CommonsHttpSolrServer} (removed in solr 4.0.0) is in path
     */
    public static boolean isSolr3XAvailable() {
        return IS_SOLR_3_X_AVAILABLE;
    }

    /**
     * @return true if {@link org.apache.solr.client.solrj.impl.CloudSolrServer} (introduced in solr 4.0.0) is in path
     */
    public static boolean isSolr4XAvailable() {
        return IS_SOLR_4_X_AVAILABLE;
    }

    /**
     * @return true if {@code org.apache.solr.parser.ParseException} is in path
     */
    public static boolean isSolr420Available() {
        return IS_SOLR_4_2_AVAILABLE;
    }

    private static boolean isPresent(String className) {
        return ClassUtils.isPresent(className, VersionUtil.class.getClassLoader());
    }
}