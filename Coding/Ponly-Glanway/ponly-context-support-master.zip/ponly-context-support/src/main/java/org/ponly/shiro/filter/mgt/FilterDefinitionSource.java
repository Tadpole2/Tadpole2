/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.shiro.filter.mgt;

import java.util.Map;

/**
 * @author vacoor
 */
public interface FilterDefinitionSource {
    int HIGHEST_PRECEDENCE = Integer.MIN_VALUE;
    int LOWEST_PRECEDENCE = Integer.MAX_VALUE;

    Map<String, String> getFilterDefinitions();

    int getOrder();

}
