package org.ponly.spring.namespace;

import org.ponly.common.util.StringUtils;
import org.ponly.config.mgt.support.PropertiesReadOnlyConfigManager;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.support.EncodedResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.Properties;

import static org.ponly.spring.namespace.ParsingUtils.*;

/**
 */
public class PropertiesConfigManagerBeanDefinitionParser extends AbstractSingleBeanDefinitionParser {
    private static final String CACHE_MGR_REF_ATTR = "cache-manager-ref";
    private static final String PROPS_LOCATION_ATTR = "props-location";
    private static final String PROPS_ENCODING_ATTR = "props-encoding";
    private static final String PROPS_REF_ATTR = "props-ref";

    @Override
    protected boolean shouldGenerateIdAsFallback() {
        return true;
    }

    @Override
    protected Class<?> getBeanClass(Element element) {
        return PropertiesReadOnlyConfigManager.class;
    }

    @Override
    protected void doParse(Element element, BeanDefinitionBuilder builder) {
        super.doParse(element, builder);
        setPropertyReference(builder, element, CACHE_MGR_REF_ATTR, "cacheManager");

        String location = element.getAttribute(PROPS_LOCATION_ATTR);
        String encoding = element.getAttribute(PROPS_ENCODING_ATTR);
        if (StringUtils.hasLength(location)) {
            // setPropertyValue(builder, element, PROPS_LOCATION_ATTR, "properties");
            try {
                Properties props = PropertiesLoaderUtils.loadProperties(
                        new EncodedResource(new DefaultResourceLoader().getResource(location), encoding)
                );
                builder.addPropertyValue("properties", props);
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        } else if (StringUtils.hasLength(PROPS_REF_ATTR)) {
            setPropertyReference(builder, element, PROPS_REF_ATTR, "properties");
        } else {
            throw new IllegalStateException("no props-ref or props-location configure");
        }
    }
}
