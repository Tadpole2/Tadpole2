/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.shiro.filter;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.util.SavedRequest;
import org.ponly.shiro.authc.UsernamePasswordCaptchaToken;
import org.ponly.web.util.WebUtils;


import static org.apache.shiro.util.StringUtils.hasText;
import static org.apache.shiro.web.util.WebUtils.*;

/**
 * @author vacoor
 */
public class AuthenticationFilter extends org.apache.shiro.web.filter.authc.FormAuthenticationFilter {
    public static final String DEFAULT_ERROR_EXCEPTION_KEY_ATTRIBUTE_NAME = "shiroLoginFailure.exception";
    public static final String DEFAULT_CAPTCHA_PARAM = "captcha";
    public static final String DEFAULT_REDIRECT_PARAM = "redirect";

    private String failureExceptionKeyAttribute = DEFAULT_ERROR_EXCEPTION_KEY_ATTRIBUTE_NAME;
    private String captchaParam = DEFAULT_CAPTCHA_PARAM;
    private String redirectUrlParam = DEFAULT_REDIRECT_PARAM;

    @Override
    protected AuthenticationToken createToken(String username, String password, ServletRequest request, ServletResponse response) {
        final String captcha = getCaptcha(request);
        final boolean rememberMe = isRememberMe(request);
        final String host = getHost(request);
        return new UsernamePasswordCaptchaToken(username, password, captcha, rememberMe, host);
    }

    @Override
    protected AuthenticationToken createToken(final String username, final String password, final boolean rememberMe, final String host) {
        // return super.createToken(username, password, rememberMe, host);
        return new UsernamePasswordCaptchaToken(username, password, null, rememberMe, host);
    }

    @Override
    protected boolean onLoginSuccess(AuthenticationToken token, Subject subject, ServletRequest request, ServletResponse response) throws Exception {
        // 登录成功 重置 session
        resetSession(subject);
        return super.onLoginSuccess(token, subject, request, response);
    }

    /**
     * 重写登录成功重定向为通过 success 来重定向
     * 1. 获取 redirectUrl
     * 2. 获取 savedRequest
     */
    @Override
    protected void issueSuccessRedirect(ServletRequest request, ServletResponse response) throws Exception {
        // super.issueSuccessRedirect(request, response);

        // 如果登录成功 redirect 地址, 依然为空, 使用默认
        String successUrl = getSuccessUrl();
        boolean contextRelative = true;
        Map<String, String> params = new HashMap<String, String>();

        if (successUrl == null) {
            throw new IllegalStateException("Success URL not available via saved request or via the " +
                    "successUrlFallback method parameter. One of these must be non-null for " +
                    "issueSuccessRedirect() to work.");
        }

        // 优先使用客户端指定的 redirect 地址
        String redirectUrl = getRedirectUrl(request);
        // don't has schema
        contextRelative = !(null != redirectUrl && redirectUrl.indexOf(":") > redirectUrl.indexOf("/"));

        // 如果客户端没有指定 redirect 地址, 尝试使用保存的请求
        if (!hasText(redirectUrl)) {
            SavedRequest savedRequest = getAndClearSavedRequest(request);
            if (null != savedRequest && savedRequest.getMethod().equalsIgnoreCase(GET_METHOD)) {
                String contextPath = getContextPath(toHttp(request));
                redirectUrl = savedRequest.getRequestUrl();
                contextRelative = false;
                /*
                if (redirectUrl.startsWith(contextPath)) {
                    redirectUrl = redirectUrl.substring(contextPath.length());
                }
                */
            }
        }

        if (hasText(redirectUrl)) {
            params.put(getRedirectUrlParam(), redirectUrl);
        }

        issueRedirect(request, response, successUrl, params, contextRelative);
    }

    @Override
    protected void saveRequest(final ServletRequest request) {
        final HttpServletRequest httpRequest = WebUtils.toHttp(request);
        if (!WebUtils.isAsyncRequest(httpRequest) && "GET".equals(httpRequest.getMethod())) {
            super.saveRequest(httpRequest);
        } else {
            // final String referer = httpRequest.getHeader("Referer");
            // TODO
        }
    }

    @Override
    protected void redirectToLogin(ServletRequest request, ServletResponse response) throws IOException {
        super.redirectToLogin(request, response);
    }

    /**
     * 增加将异常对象写入 request
     */
    @Override
    protected void setFailureAttribute(ServletRequest request, AuthenticationException ae) {
        super.setFailureAttribute(request, ae);
        request.setAttribute(getFailureExceptionKeyAttribute(), ae);
    }

    /**
     * 重置 subject session
     *
     * @param subject
     */
    protected void resetSession(Subject subject) {
        Session session = subject.getSession(false);
        if (session == null) {
            return;
        }

        Map<Object, Object> transfer = new HashMap<Object, Object>();
        Collection<Object> attrKeys = session.getAttributeKeys();
        for (Object key : attrKeys) {
            transfer.put(key, session.getAttribute(key));
        }

        /**
         * 重置 session 后会引起 URL 重写 ....;JSESSIONID=newSessionId
         * 在 spring mvc 中存在问题需要使用
         * @RequestMapping(value = {"/{successUrl:successUrl;?.*}"})
         * spring3.2.2 bug see  http://jinnianshilongnian.iteye.com/blog/1831408
         * 可以通过重写 ShiroFilter 的 isEncodeable
         * @see org.talmud.support.shiro.spring.FilterDefinitionSourceShiroFilterFactoryBean#SpringShiroFilter
         */
        session.stop();

        session = subject.getSession();
        for (Map.Entry<Object, Object> entry : transfer.entrySet()) {
            session.setAttribute(entry.getKey(), entry.getValue());
        }
    }

    public String getFailureExceptionKeyAttribute() {
        return failureExceptionKeyAttribute;
    }

    public void setFailureExceptionKeyAttribute(String failureExceptionKeyAttribute) {
        this.failureExceptionKeyAttribute = failureExceptionKeyAttribute;
    }

    public String getCaptchaParam() {
        return captchaParam;
    }

    public void setCaptchaParam(String captchaParam) {
        this.captchaParam = captchaParam;
    }

    public String getRedirectUrlParam() {
        return redirectUrlParam;
    }

    public void setRedirectUrlParam(String redirectParam) {
        this.redirectUrlParam = redirectParam;
    }

    @Override
    protected String getHost(final ServletRequest request) {
        return org.ponly.web.util.WebUtils.getRemoteHost(request);
        // return super.getHost(request);
    }

    public String getCaptcha(final ServletRequest request) {
        return getCleanParam(request, getCaptchaParam());
    }

    public String getRedirectUrl(ServletRequest request) {
        return getCleanParam(request, getRedirectUrlParam());
    }
}
