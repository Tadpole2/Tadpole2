package org.ponly.shiro.authc;

import org.apache.shiro.authc.UsernamePasswordToken;

/**
 */
public class UsernamePasswordCaptchaToken extends UsernamePasswordToken {
    /**
     * The captcha.
     */
    private String captcha;

    public UsernamePasswordCaptchaToken(final String username, final char[] password, final String captcha) {
        super(username, password);
        this.captcha = captcha;
    }

    public UsernamePasswordCaptchaToken(final String username, final String password, final String captcha) {
        super(username, password);
        this.captcha = captcha;
    }

    public UsernamePasswordCaptchaToken(final String username, final char[] password, final String captcha, final String host) {
        super(username, password, host);
        this.captcha = captcha;
    }

    public UsernamePasswordCaptchaToken(final String username, final String password, final String captcha, final String host) {
        super(username, password, host);
        this.captcha = captcha;
    }

    public UsernamePasswordCaptchaToken(final String username, final char[] password, final String captcha, final boolean rememberMe) {
        super(username, password, rememberMe);
        this.captcha = captcha;
    }

    public UsernamePasswordCaptchaToken(final String username, final String password, final String captcha, final boolean rememberMe) {
        super(username, password, rememberMe);
        this.captcha = captcha;
    }

    public UsernamePasswordCaptchaToken(final String username, final char[] password, final String captcha, final boolean rememberMe, final String host) {
        super(username, password, rememberMe, host);
        this.captcha = captcha;
    }

    public UsernamePasswordCaptchaToken(final String username, final String password, final String captcha, final boolean rememberMe, final String host) {
        super(username, password, rememberMe, host);
        this.captcha = captcha;
    }

    /**
     * Returns the captcha submitted during an authentication attempt.
     *
     * @return the captcha submitted during an authentication attempt.
     */
    public String getCaptcha() {
        return captcha;
    }

    /**
     * Sets the captcha for submission during an authentication attempt.
     *
     * @param captcha the username to be used for submission during an authentication attempt.
     */
    public void setCaptcha(final String captcha) {
        this.captcha = captcha;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void clear() {
        super.clear();
        this.captcha = null;
    }

    /**
     * Returns the String representation.
     * It does not include the password in the resulting string for security reasons to prevent accidentially
     * printing out a password that might be widely viewable).
     *
     * @return the String representation of the <tt>UsernamePasswordCaptchaToken</tt>, omitting the password.
     */
    @Override
    public String toString() {
        final String host = getHost();
        final String captcha = getCaptcha();
        final StringBuilder sb = new StringBuilder();
        sb.append(getClass().getName());
        sb.append(" - ");
        sb.append(getUsername());
        if (null != captcha) {
            sb.append(", captcha=").append(captcha);
        }
        sb.append(", rememberMe=").append(isRememberMe());
        if (null != host) {
            sb.append(" (").append(host).append(")");
        }
        return sb.toString();
    }
}
