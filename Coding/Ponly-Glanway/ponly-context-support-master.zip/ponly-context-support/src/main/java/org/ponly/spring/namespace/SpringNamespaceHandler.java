/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.spring.namespace;

import org.springframework.beans.factory.xml.BeanDefinitionParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
//import org.talmud.mgt.auditing.config.AuditingHandlerBeanDefinitionParser;
//import org.talmud.mgt.logging.config.MethodLoggingBeanDefinitionParser;
//import org.talmud.mgt.solr.server.config.EmbeddedSolrServerBeanDefinitionParser;
//import org.talmud.mgt.solr.server.config.HttpSolrServerBeanDefinitionParser;


/**
 * @author vacoor
 */
/*
<bean class="org.springframework.beans.factory.config.MethodInvokingFactoryBean">
<property name="targetClass" value="org.talmud.mgt.util.SettingsUtils"/>
<property name="targetMethod" value="setConfigurationManager"/>
<property name="arguments" ref="configurationManager" />
</bean>
*/
public class SpringNamespaceHandler extends NamespaceHandlerSupport {
    private static final BeanDefinitionParser GENERIC_INJECT_BDP = new GenericInjectBeanDefinitionParser();
    private static final BeanDefinitionParser CS_PH_BDP = new ConfigSourcePlaceholderConfigurerBeanDefinitionParser();
    private static final BeanDefinitionParser NLS_MS_BDP = new NlsBundleManagerMessageSourceBeanDefinitionParser();
    //
    private static final BeanDefinitionParser PROPS_CFG_MGR_BDP = new PropertiesConfigManagerBeanDefinitionParser();
    private static final BeanDefinitionParser JDBC_CFG_MGR_BDP = new JdbcConfigManagerBeanDefinitionParser();

    private static final BeanDefinitionParser PLUGIN_MGR_BDP = new PluginManagerBeanDefinitionParser();

    private static final BeanDefinitionParser PROP_NLS_MGR_BDP = new PropertiesNlsBundleManagerBeanDefinitionParser();
    //    private static final BeanDefinitionParser METHOD_LOGGING_BDP = new MethodLoggingBeanDefinitionParser();
//    private static final BeanDefinitionParser AUDT_BDP = new AuditingHandlerBeanDefinitionParser();
    private static final BeanDefinitionParser FILTER_BDP = new WebContextFilterBeanDefinitionParser();
    private static final BeanDefinitionParser ICS_BDP = new CaptchaServiceBeanDefinitionParser();
//    private static final BeanDefinitionParser EM_SOLR_SERVER_BDP = new EmbeddedSolrServerBeanDefinitionParser();
//    private static final BeanDefinitionParser SOLR_SERVER_BDP = new HttpSolrServerBeanDefinitionParser();

    @Override
    public void init() {
        registerBeanDefinitionParser("generic-inject", GENERIC_INJECT_BDP);
        registerBeanDefinitionParser("property-placeholder", CS_PH_BDP);
        registerBeanDefinitionParser("message-source", NLS_MS_BDP);
        //
        registerBeanDefinitionParser("props-config-manager", PROPS_CFG_MGR_BDP);
        registerBeanDefinitionParser("jdbc-config-manager", JDBC_CFG_MGR_BDP);
        registerBeanDefinitionParser("plugin-manager", PLUGIN_MGR_BDP);
        registerBeanDefinitionParser("props-nls-bundle-manager", PROP_NLS_MGR_BDP);
//        registerBeanDefinitionParser("method-logging", METHOD_LOGGING_BDP);
//        registerBeanDefinitionParser("auditing-handler", AUDT_BDP);
        registerBeanDefinitionParser("captcha-service", ICS_BDP);
        registerBeanDefinitionParser("context-filter", FILTER_BDP);

//        registerBeanDefinitionParser("embedded-solr-server", EM_SOLR_SERVER_BDP);
//        registerBeanDefinitionParser("solr-server", SOLR_SERVER_BDP);
    }
}
