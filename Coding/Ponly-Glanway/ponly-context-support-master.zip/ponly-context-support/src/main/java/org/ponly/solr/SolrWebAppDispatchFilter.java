package org.ponly.solr;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.solr.core.SolrCore;
import org.apache.solr.servlet.SolrDispatchFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.Charset;

import static org.apache.solr.core.SolrResourceLoader.locateSolrHome;
import static org.apache.solr.core.SolrResourceLoader.normalizeDir;

/**
 * 开发专用 嵌入 Solr Server
 * <p/>
 * 主要实现功能就一个, 获取 solr core container 创建一个 EmbeddedSolrServer
 * 配置:
 * web.xml
 * <pre>
 *   <env-entry>
 *      <env-entry-name>solr/home</env-entry-name>
 *      <env-entry-type>java.lang.String</env-entry-type>
 *      <env-entry-value>solr</env-entry-value>
 *   </env-entry>
 *   <filter>
 *      <filter-name>solr</filter-name>
 *      <filter-class>SolrWebAppDispatchFilter</filter-class>
 *      <init-param>
 *          <param-name>path-prefix</param-name>
 *          <param-value>/admin/solr</param-value>
 *      </init-param>
 *   </filter>
 *   <filter-mapping>
 *      <filter-name>solr</filter-name>
 *      <url-pattern>/admin/solr/*</url-pattern> <!-- or /* -->
 *   </filter-mapping>
 * </pre>
 * 也可以配置在 spring 中
 * <pre>
 * <filter>
 *    <filter-name>solrFilter</filter-name>
 *    <filter-class>org.ponly.spring.RefreshableDelegatingFilterProxy</filter-class>
 *    <init-param>
 *      <param-name>targetFilterLifecycle</param-name>
 *      <param-value>true</param-value>
 *    </init-param>
 * </filter>
 * </pre>
 * -------------
 * <pre>
 * solr.home
 *    | -- solr.xml
 *    | -- instance
 *           | -- conf
 *                  | -- solrconfig.xml         solr 实例配置, 查询, 补全等
 *                  | -- schema.xml             document 字段配置
 *                  | -- dataimport.properties  自动生成, 记录最后导入时间
 *           | -- data
 *                 | -- index      索引文件
 *                 | -- tlog       日志文件
 *           | -- core.properties  内容为 name = core name
 * </pre>
 *
 * @author vacoor
 */
public class SolrWebAppDispatchFilter extends SolrDispatchFilter {
    public static final String SOLR_CORE_SERVLET_CONTEXT_KEY = SolrWebAppDispatchFilter.class + ".CORES";
    private static final Logger LOG = LoggerFactory.getLogger(SolrWebAppDispatchFilter.class);
    private static final Charset UTF_8 = Charset.forName("UTF-8");
    private static final String SOLR_HOME_SYSTEM_PROPERTY = "solr.solr.home";

    protected String solrWebAppRoot = "/support/web/solr";
    private FilterConfig config;

    @Override
    public void init(FilterConfig config) throws ServletException {
        LOG.info("SolrWebAppDispatchFilter.init()");
        /**
         *  path-prefix
         *  config.getInitParameter("path-prefix");
         *  <p />
         *  默认 solr home 定位 (SolrResourceLoader#locateSolrHome())
         *  1. JNDI: java:comp/env/solr/home   (这个方便)
         *  2. System Property: solr.solr.home (这个方便)
         *  3. solr/ (user.dir/solr)
         *
         *  首先从 JNDI 因此可以在 web.xml
         *  &lt;env-entry&gt;
         *     &lt;env-entry-name&gt;solr/home&lt;/env-entry-name&gt;
         *     &lt;env-entry-type&gt;java.lang.String&lt;/env-entry-type&gt;
         *     &lt;env-entry-value&gt;/usr/app/solr/home&lt;/env-entry-value&gt;
         *  &lt;/env-entry&gt;
         *  {@link org.apache.solr.servlet.SolrDispatchFilter#init(FilterConfig)}
         *  {@link org.apache.solr.servlet.SolrDispatchFilter#createCoreContainer()}
         *  {@link org.apache.solr.core.SolrResourceLoader#locateSolrHome()}
         *  {@link org.apache.solr.servlet.SolrDispatchFilter#loadConfigSolr(org.apache.solr.core.SolrResourceLoader)}
         */

        this.config = config;

        try {
            String systemSolrHome = System.getProperty(SOLR_HOME_SYSTEM_PROPERTY);
            // 如果没有设置 solr home 且 classpath 存在 solr 文件夹
            if (null == systemSolrHome && normalizeDir("solr/").equals(locateSolrHome())) {
                URL url = getClass().getClassLoader().getResource("/solr/");

                if (null != url) {
                    systemSolrHome = URLDecoder.decode(url.getPath(), "utf-8");
                }
                if (null != systemSolrHome) {
                    System.setProperty(SOLR_HOME_SYSTEM_PROPERTY, systemSolrHome);
                }
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }

        super.init(config);
        config.getServletContext().setAttribute(SOLR_CORE_SERVLET_CONTEXT_KEY, getCores());
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain, boolean retry) throws IOException, ServletException {
        // 这里处理下静态资源, 避免需要配置那么多
        if (request instanceof HttpServletRequest) {
            HttpServletRequest req = (HttpServletRequest) request;
            HttpServletResponse resp = (HttpServletResponse) response;
            String requestPath = req.getServletPath();

            if (req.getPathInfo() != null) {
                // this lets you handle /update/commit when /update is a servlet
                requestPath += req.getPathInfo();
            }

            // 如果 path-prefix 为空 或者 path 以 path-prefix 开头才需要处理
            String pathPrefix = getPathPrefix();
            if (pathPrefix == null || requestPath.startsWith(pathPrefix)) {
                // 去除filter前缀的路径
                if (pathPrefix != null && requestPath.startsWith(pathPrefix)) {
                    requestPath = requestPath.substring(pathPrefix.length());
                }

                if ("".equals(requestPath)) {
                    /*
                    // jetty bug sendRedirect("/") --> schema://host:port/[/context]/, eg:http://localhost:8888//admin
                    String url = WebUtils.getUrlWithoutApplication(req, req.getServletPath() + "/");
                    */
                    String url = req.getContextPath() + req.getServletPath() + "/";
                    resp.sendRedirect(url);
                    return;
                } else if ("/".equals(requestPath)) {
                    requestPath = "/admin.html";
                }

                // 实际的资源路径
                requestPath = solrWebAppRoot + (requestPath.startsWith("/") ? requestPath : "/" + requestPath);
                InputStream in = getClass().getClassLoader().getResourceAsStream(requestPath);
                // 存在资源
                if (null != in && null != cores) {
                    resp.setCharacterEncoding("UTF-8");
                    ServletOutputStream out = response.getOutputStream();
                    if (requestPath.endsWith(".html")) {
                        Writer writer = new OutputStreamWriter(out, UTF_8);
                        resp.setContentType("text/html");
                        String html = IOUtils.toString(in, "UTF-8");
                        Package pack = SolrCore.class.getPackage();

                        // 变量替换
                        String[] search = new String[]{
                                "${contextPath}",
                                "${adminPath}",
                                "${version}"
                        };
                        String[] replace = new String[]{
                                StringEscapeUtils.escapeJavaScript(req.getContextPath() + getPathPrefix()),
                                StringEscapeUtils.escapeJavaScript(cores.getAdminPath()),
                                StringEscapeUtils.escapeJavaScript(pack.getSpecificationVersion())
                        };

                        writer.write(StringUtils.replaceEach(html, search, replace));
                        writer.flush();
                    } else {
                        if (requestPath.endsWith(".js")) {
                            resp.setContentType("text/javascript");
                        } else if (requestPath.endsWith(".css")) {
                            resp.setContentType("text/css");
                        } else if (requestPath.endsWith(".png")) {
                            resp.setContentType("image/png");
                        } else if (requestPath.endsWith(".gif")) {
                            resp.setContentType("image/gif");
                        } else if (requestPath.endsWith(".ico")) {
                        }
                        IOUtils.copy(in, out);
                        out.flush();
                    }
                    IOUtils.closeQuietly(in);
                    return;
                }
            }
        }

        super.doFilter(request, response, chain, retry);
    }

    @Override
    public void destroy() {
        super.destroy();
        this.config.getServletContext().removeAttribute(SOLR_CORE_SERVLET_CONTEXT_KEY);
        this.config = null;
    }
}
