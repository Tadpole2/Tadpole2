/*
 * Copyright (c) 2005, 2014 vacoor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.ponly.shiro;

import org.apache.shiro.authc.IncorrectCredentialsException;

/**
 */
public class RetryLimitIncorrectCredentialsException extends IncorrectCredentialsException {
    private final int reties;
    private final int fail;

    public RetryLimitIncorrectCredentialsException(int reties, int fail) {
        this(reties, fail, null);
    }

    public RetryLimitIncorrectCredentialsException(int reties, int fail, String message) {
        super("credential is incorrect, remain count of retries:" + (reties - fail) + (null != message ? ", " + message : ""));
        this.reties = reties;
        this.fail = fail;
    }

    public int getReties() {
        return reties;
    }

    public int getFail() {
        return fail;
    }
}
