package org.ponly.solr.server.config;

import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

class SolrNamespaceHandler extends NamespaceHandlerSupport {

    /*
     * (non-Javadoc)
     * @see org.springframework.beans.factory.xml.NamespaceHandler#init()
     */
    @Override
    public void init() {
        registerBeanDefinitionParser("embedded-solr-server", new EmbeddedSolrServerBeanDefinitionParser());
        registerBeanDefinitionParser("solr-server", new HttpSolrServerBeanDefinitionParser());
    }
}