package org.ponly.solr;

import org.apache.solr.client.solrj.SolrRequest;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.embedded.EmbeddedSolrServer;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.core.CoreContainer;
import org.ponly.solr.server.support.EmbeddedSolrServerFactoryBean;
import org.ponly.solr.server.support.HttpSolrServerFactoryBean;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.web.context.ServletContextAware;

import javax.servlet.ServletContext;
import java.io.IOException;

/**
 * {@link EmbeddedSolrServerFactoryBean}
 * {@link HttpSolrServerFactoryBean}
 * @author vacoor
 * @deprecated
 */
@Deprecated
public class DevelopSolrServerFactoryBean implements FactoryBean, ServletContextAware {
    protected ServletContext servletContext;

    private SolrServer solrServer;
    protected CoreContainer coreContainer;
    protected String coreName;

    @Override
    public Object getObject() throws Exception {
        if (null == solrServer) {
            solrServer = createSolrServer();
        }
        return solrServer;
    }

    @Override
    public Class<?> getObjectType() {
        return EmbeddedSolrServer.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    public CoreContainer getCoreContainer() {
        return coreContainer;
    }

    public void setCoreContainer(CoreContainer coreContainer) {
        this.coreContainer = coreContainer;
    }

    public String getCoreName() {
        return coreName;
    }

    public void setCoreName(String coreName) {
        this.coreName = coreName;
    }

    protected SolrServer createSolrServer() {
        CoreContainer cores = coreContainer;
        SolrServer solrServer = null;
        if (null != cores) {
            solrServer = new EmbeddedSolrServer(cores, coreName);
        } else if (null != servletContext) {
            String key = SolrWebAppDispatchFilter.SOLR_CORE_SERVLET_CONTEXT_KEY;
            cores = (CoreContainer) servletContext.getAttribute(key);
            // 已经设置直接创建 EmbeddedSolrServer, 没有设置创建一个延迟对象
            solrServer = null != cores ? new EmbeddedSolrServer(cores, coreName) : new LazyServletContextSolrServer(servletContext, key, coreName);
        }

        if (null == solrServer) {
            throw new IllegalArgumentException("不能创建 SolrServer, 因为没有设置 core container 也没有配置 servlet context");
        }
        return solrServer;
    }


    protected static class LazyServletContextSolrServer extends SolrServer {
        private final Object lock = new Object();
        private final ServletContext servletContext;
        private final String servletContextCoresKey;
        private final String coreName;
        private EmbeddedSolrServer embeddedSolrServer;

        public LazyServletContextSolrServer(ServletContext servletContext, String coresKey, String coreName) {
            this.servletContext = servletContext;
            this.servletContextCoresKey = coresKey;
            this.coreName = coreName;
        }

        public EmbeddedSolrServer getEmbeddedSolrServer() {
            if (null != embeddedSolrServer) {
                return embeddedSolrServer;
            }
            synchronized (lock) {
                if (null == embeddedSolrServer) {
                    CoreContainer cores = (CoreContainer) servletContext.getAttribute(servletContextCoresKey);
                    if (null == cores) {
                        throw new IllegalStateException("不能在 servlet context 中发现 没有配置 core container using key:" + servletContextCoresKey);
                    }
                    embeddedSolrServer = new EmbeddedSolrServer(cores, coreName);
                }
            }
            return embeddedSolrServer;
        }

        @Override
        public NamedList<Object> request(SolrRequest request) throws SolrServerException, IOException {
            return getEmbeddedSolrServer().request(request);
        }

        @Override
        public void shutdown() {
            EmbeddedSolrServer solrServer = embeddedSolrServer;
            embeddedSolrServer = null;
            if (null != solrServer) {
                solrServer.shutdown();
            }
        }
    }
}
