package org.ponly.shiro.realm;

import java.io.Serializable;
import java.util.Date;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheManager;
import org.ponly.shiro.RetryLimitIncorrectCredentialsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 */
public class LockoutJdbcRealm extends JdbcRealm {
    private static final Logger LOGGER = LoggerFactory.getLogger(LockoutJdbcRealm.class);
    private static final String AUTHENTICATION_LOCK_NS = "authenticationLock_";
    private static final int DEFAULT_LOCKOUT_TIME = 5 * 60;

    private boolean authenticationLockEnabled = false;
    private int retryLimit = 3;
    private int lockOutTime = DEFAULT_LOCKOUT_TIME;
    private Cache<Object, Lock> authenticationLockCache;

    protected static class Lock implements Serializable {
        private int count;
        private long timestamp;

        public int getCount() {
            return count;
        }

        public long getTimestamp() {
            return timestamp;
        }
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(final AuthenticationToken authenticationToken) throws AuthenticationException {
        assertPrincipalLockoutUnlimit(authenticationToken);
        return super.doGetAuthenticationInfo(authenticationToken);
    }

    protected void assertPrincipalLockoutUnlimit(final AuthenticationToken authenticationToken) throws AuthenticationException {
        final Object principal = authenticationToken.getPrincipal();
        if (isAuthenticationLockEnabled() && null != principal) {
            final int limit = getRetryLimit();
            final Lock lock = getAuthenticationLock(authenticationToken);
            final int count = lock.count;

            // already locked.
            if (limit <= count) {
                final long now = new Date().getTime();
                final long lockedTime = 0 < lock.timestamp ? lock.timestamp : now;

                // 仍在锁定时间内
                if (now - lockedTime < lockOutTime * 1000) {
                    throw new LockedAccountException(String.format("principal [%s] is locked", principal));
                }

                lock.timestamp = lock.count = 0;
                this.cacheAuthenticationLockIfPossible(authenticationToken, lock);
            }
        }
    }

    /**
     * 重写Credential比对, 处理失败次数记录和锁定用户
     */
    @Override
    protected void assertCredentialsMatch(final AuthenticationToken authenticationToken, AuthenticationInfo info) throws AuthenticationException {
        final CredentialsMatcher matcher = getCredentialsMatcher();

        // 如果密码匹配器不是空, 并且启用重试次数限制, 并且不是超级管理员
        if (matcher != null && isAuthenticationLockEnabled()) {
            final Lock lock = getAuthenticationLock(authenticationToken);
            // 匹配失败
            if (!matcher.doCredentialsMatch(authenticationToken, info)) {
                final int limit = getRetryLimit();
                lock.count += 1;

                // 失败次数达到重试上限
                if (lock.count >= limit) {
                    lock.timestamp = new Date().getTime();
                    this.cacheAuthenticationLockIfPossible(authenticationToken, lock);
                    throw new LockedAccountException();
                } else {
                    // 未达重试上限, 更新失败次数
                    this.cacheAuthenticationLockIfPossible(authenticationToken, lock);

                    throw new RetryLimitIncorrectCredentialsException(limit, lock.count);
                }
                // throw new IncorrectCredentialsException("credential is incorrect, remain count of retries: " + remainCount);
            } else {
                // 匹配成功清空, 失败信息
                lock.timestamp = lock.count = 0;
                this.cacheAuthenticationLockIfPossible(authenticationToken, lock);
            }
        } else {
            super.assertCredentialsMatch(authenticationToken, info);
        }
    }

    protected Lock getAuthenticationLock(final AuthenticationToken authenticationToken) {
        final Cache<Object, Lock> cache = getAvailableAuthenticationLockCache();
        final Lock lock = cache.get(getAuthenticationLockKey(authenticationToken));
        return null != lock ? lock : new Lock();
    }

    private void cacheAuthenticationLockIfPossible(final AuthenticationToken token, final Lock lock) {
        final Cache<Object, Lock> cache = getAvailableAuthenticationLockCache();
        if (null == lock) {
            cache.remove(getAuthenticationLockKey(token));
        }
        cache.put(getAuthenticationLockKey(token), lock);
    }

    private Object getAuthenticationLockKey(final AuthenticationToken token) {
        return null != token ? AUTHENTICATION_LOCK_NS + token.getPrincipal() : null;
    }

    private Cache<Object, Lock> getAvailableAuthenticationLockCache() {
        Cache<Object, Lock> cache = getAuthenticationLockCache();
        if (null == cache && isAuthenticationLockEnabled()) {
            cache = getAuthenticationLockLazy();
        }
        return cache;
    }

    private Cache<Object, Lock> getAuthenticationLockLazy() {
        if (null == this.authenticationLockCache) {
            LOGGER.trace("No authenticationCache instance set.  Checking for a cacheManager...");

            final CacheManager cacheManager = getCacheManager();
            if (null != cacheManager) {
                final String cacheName = getAuthenticationCacheName();
                LOGGER.debug("CacheManager [{}] configured.  Building authentication lock cache '{}'", cacheManager, cacheName);
                this.authenticationLockCache = cacheManager.getCache(cacheName);
            }
        }

        return this.authenticationLockCache;
    }


    public boolean isAuthenticationLockEnabled() {
        return authenticationLockEnabled;
    }

    public void setAuthenticationLockEnabled(boolean authenticationLockEnabled) {
        this.authenticationLockEnabled = authenticationLockEnabled;
    }

    public int getRetryLimit() {
        return retryLimit;
    }

    public void setRetryLimit(final int retryLimit) {
        this.retryLimit = retryLimit;
    }

    public int getLockOutTime() {
        return lockOutTime;
    }

    public void setLockOutTime(final int lockOutTime) {
        this.lockOutTime = lockOutTime;
    }

    public Cache<Object, Lock> getAuthenticationLockCache() {
        return authenticationLockCache;
    }

    public void setAuthenticationLockCache(Cache<Object, Lock> authenticationLockCache) {
        this.authenticationLockCache = authenticationLockCache;
    }
}
