package org.ponly.shiro.realm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.sql.DataSource;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.authz.permission.AllPermission;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.config.ConfigurationException;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.apache.shiro.util.JdbcUtils;
import org.ponly.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 */
public class JdbcRealm extends AuthorizingRealm {
    /*--------------------------------------------
    |             C O N S T A N T S             |
    ============================================*/
    /**
     * The default query used to retrieve account data for the user.
     */
    protected static final String DEFAULT_AUTHENTICATION_QUERY = "select password from users where username = ?";

    /**
     * The default query used to retrieve account data for the user when {@link #saltStyle} is COLUMN.
     */
    protected static final String DEFAULT_SALTED_AUTHENTICATION_QUERY = "select password, password_salt from users where username = ?";

    /**
     * The default query used to retrieve the roles that apply to a user.
     */
    protected static final String DEFAULT_USER_ROLES_QUERY = "select role_name from user_roles where username = ?";

    /**
     * The default query used to retrieve permissions that apply to a particular user.
     */
    protected static final String DEFAULT_USER_PERMISSIONS_QUERY = "select permission from users_permissions where username = ?";

    /**
     * The default query used to retrieve permissions that apply to a particular role.
     */
    protected static final String DEFAULT_ROLE_PERMISSIONS_QUERY = "select permission from roles_permissions where role_name = ?";

    /**
     * Password hash salt configuration. <ul>
     * <li>NO_SALT - password hashes are not salted.</li>
     * <li>CRYPT - password hashes are stored in unix crypt format.</li>
     * <li>COLUMN - salt is in a separate column in the database.</li>
     * <li>EXTERNAL - salt is not stored in the database. {@link #getExternalSaltForUser(String)} will be called
     * to get the salt</li></ul>
     */
    public enum SaltStyle {
        NO_SALT, CRYPT, COLUMN, EXTERNAL
    }

    ;

    private static final Logger LOGGER = LoggerFactory.getLogger(JdbcRealm.class);

    protected DataSource dataSource;
    protected String authenticationQuery = DEFAULT_AUTHENTICATION_QUERY;
    protected String userRolesQuery = DEFAULT_USER_ROLES_QUERY;
    protected String userPermissionsQuery = DEFAULT_USER_PERMISSIONS_QUERY;
    protected String rolePermissionsQuery = DEFAULT_ROLE_PERMISSIONS_QUERY;

    protected boolean userPermissionsLookupEnabled = false;
    protected boolean rolePermissionsLookupEnabled = true;

    protected SaltStyle saltStyle = SaltStyle.NO_SALT;
    protected String systemAdminUsername;

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(final AuthenticationToken authenticationToken) throws AuthenticationException {
        final UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        final String username = token.getUsername();

        // 用户名密码都不存在
        if (null == username || null == token.getPassword()) {
            throw new UnknownAccountException("username or password is invalid");
        }

        Connection conn = null;
        try {
            conn = getConnection();

            String password = null;
            Object salt = null;

            final Object[] queryResults = this.doGetAuthenticationQuery(conn, username);

            doPreAuthenticated(authenticationToken, queryResults);

            switch (this.saltStyle) {
                case NO_SALT:
                    password = null != queryResults[0] ? queryResults[0].toString() : null;
                    break;
                case CRYPT:
                    // TODO: separate password and hash.
                    throw new ConfigurationException("Not implemented yet");
                    //break;
                case COLUMN:
                    password = null != queryResults[0] ? queryResults[0].toString() : null;
                    salt = queryResults[1];
                    break;
                case EXTERNAL:
                    password = null != queryResults[0] ? queryResults[0].toString() : null;
                    salt = getExternalSaltForUser(username);
            }

            // 密码校验交由 CredentialsMatcher 来处理, 不硬编码加密算法, 返回 authcInfo 后 CredentialsMatcher 会进行比对

            final SimpleAuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(toPrincipal(username), password, getName());
            if (null != salt) {
                authenticationInfo.setCredentialsSalt(toSaleByteSource(salt));
            }

            doPostAuthenticated(authenticationToken, authenticationInfo);

            return authenticationInfo;
        } catch (final SQLException e) {
            final String message = "There was a SQL error while authenticating user [" + username + "]";
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(message, e);
            }

            // Rethrow any SQL errors as an authentication exception
            throw new AuthenticationException(message, e);
        } finally {
            JdbcUtils.closeConnection(conn);
        }
    }

    protected void doPreAuthenticated(final AuthenticationToken authenticationToken, final Object[] authenticationQueryResult) throws AuthenticationException {
    }

    protected void doPostAuthenticated(final AuthenticationToken authenticationToken, final AuthenticationInfo authenticationInfo) throws AuthenticationException {
    }

    protected Object getExternalSaltForUser(final String username) {
        return username;
    }

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(final PrincipalCollection principals) {
        if (null == principals) {
            throw new AuthorizationException("PrincipalCollection method argument cannot be null.");
        }

        final String username = toUsername(getAvailablePrincipal(principals));

        final Set<String> permissions = new LinkedHashSet<String>();
        Set<String> roleNames = null;
        Connection conn = null;
        try {
            conn = getConnection();

            // Retrieve roles and permissions from database
            roleNames = doGetUserRoleNamesQuery(conn, username);
            if (userPermissionsLookupEnabled) {
                final Set<String> perms = doGetUserPermissionsQuery(conn, username);
                if (null != perms) {
                    permissions.addAll(perms);
                }
            }
            if (rolePermissionsLookupEnabled) {
                final Set<String> perms = doGetRolePermissionsQuery(conn, username, roleNames);
                if (null != perms) {
                    permissions.addAll(perms);
                }
            }
        } catch (final SQLException e) {
            final String message = "There was a SQL error while authorizing user [" + username + "]";
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(message, e);
            }

            // Rethrow any SQL errors as an authorization exception
            throw new AuthorizationException(message, e);
        } finally {
            JdbcUtils.closeConnection(conn);
        }

        final SimpleAuthorizationInfo info = new SimpleAuthorizationInfo(roleNames);
        info.addStringPermissions(permissions);

        // add all permission if system admin.
        if (isSystemAdmin(username)) {
            info.addObjectPermission(new AllPermission());
        }

        return info;
    }

    /* **************************************************************************** *
     *                              .
     * **************************************************************************** */

    // event trigger.
    private void onUserPermissionsChanged(final String username) {
        final Object principal = toPrincipal(username);
        this.clearCachedAuthorizationInfo(toPrincipalCollection(principal));
    }

    // event trigger.
    private void onPermissionsChanged() {
        final Cache<Object, AuthorizationInfo> authorizationCache = getAuthorizationCache();
        if (null != authorizationCache) {
            authorizationCache.clear();
        }
    }

    protected ByteSource toSaleByteSource(final Object salt) {
        return ByteSource.Util.bytes(salt);
    }

    protected Object toPrincipal(final String username) {
        return username;
    }

    protected String toUsername(final Object principal) {
        return (String) principal;
    }

    protected PrincipalCollection toPrincipalCollection(final Object principal) {
        // 上面返回的是 SimpleAuthenticationInfo
        return new SimplePrincipalCollection(principal, getName());
    }

    protected boolean isSystemAdmin(final String username) {
        return (null != this.systemAdminUsername && this.systemAdminUsername.equals(username));
    }

    /* **************************************************************************** *
     *                             JDBC OPERATIONS.
     * **************************************************************************** */

    protected Object[] doGetAuthenticationQuery(final Connection conn, final String username) throws SQLException {
        Object[] result;
        boolean returningSeparatedSalt = false;
        switch (saltStyle) {
            case NO_SALT:
            case CRYPT:
            case EXTERNAL:
                // result = returningLocked ? new String[3] : new String[1];
                break;
            default:
                // result = returningLocked ? new String[4] : new String[2];
                returningSeparatedSalt = true;
        }

        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(authenticationQuery);
            ps.setString(1, username);

            // Execute query
            rs = ps.executeQuery();

            // Loop over results - although we are only expecting one result, since usernames should be unique
            boolean foundResult = false;
            result = new Object[rs.getMetaData().getColumnCount()];

            int i = 0;
            while (rs.next()) {

                // Check to ensure only one row is processed
                if (foundResult) {
                    throw new AuthenticationException("More than one user row found for user [" + username + "]. Usernames must be unique.");
                }

                result[i++] = rs.getString(i);
                if (returningSeparatedSalt) {
                    result[i++] = rs.getObject(i);
                }
                /*
                if (returningLocked) {
                    Object ret = rs.getObject(3);
                    result[2] = null != ret ? ret.toString() : null;
                    ret = rs.getObject(4);
                    result[3] = null != ret ? ret.toString() : null;
                }
                */
                for (; i < result.length; i++) {
                    result[i] = rs.getObject(i + 1);
                }

                foundResult = true;
            }
        } finally {
            JdbcUtils.closeResultSet(rs);
            JdbcUtils.closeStatement(ps);
        }

        return result;
    }

    protected Set<String> doGetUserRoleNamesQuery(final Connection conn, final String username) throws SQLException {
        final Set<String> roleNames = new LinkedHashSet<String>();

        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(userRolesQuery);
            ps.setString(1, username);

            rs = ps.executeQuery();
            while (rs.next()) {
                final String roleName = rs.getString(1);
                if (StringUtils.hasText(roleName)) {
                    roleNames.add(roleName);
                } else if (LOGGER.isWarnEnabled()) {
                    LOGGER.warn("Null role name found while retrieving role names for user [" + username + "]");
                }
            }
        } finally {
            JdbcUtils.closeResultSet(rs);
            JdbcUtils.closeStatement(ps);
        }
        return roleNames;
    }

    protected Set<String> doGetUserPermissionsQuery(final Connection conn, final String username) throws SQLException {
        final Set<String> perms = new LinkedHashSet<String>();

        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(userPermissionsQuery);
            ps.setString(1, username);

            rs = ps.executeQuery();
            while (rs.next()) {
                final String perm = rs.getString(1);
                if (StringUtils.hasText(perm)) {
                    perms.add(perm);
                } else if (LOGGER.isWarnEnabled()) {
                    LOGGER.warn("Null permisson name found while retrieving user permissions for user [" + username + "]");
                }
            }
        } finally {
            JdbcUtils.closeResultSet(rs);
            JdbcUtils.closeStatement(ps);
        }

        return perms;
    }

    protected Set<String> doGetRolePermissionsQuery(final Connection conn, final String username, final Collection<String> roleNames) throws SQLException {
        final Set<String> permissions = new LinkedHashSet<String>();

        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(rolePermissionsQuery);

            for (final String roleName : roleNames) {
                ps.setString(1, roleName);

                ResultSet rs = null;
                try {
                    // Execute query
                    rs = ps.executeQuery();

                    // Loop over results and add each returned role to a set
                    while (rs.next()) {
                        final String permissionString = rs.getString(1);
                        // Add the permission to the set of permissions
                        if (StringUtils.hasText(permissionString)) {
                            permissions.add(permissionString);
                        } else if (LOGGER.isWarnEnabled()) {
                            LOGGER.warn("Null permisson name found while retrieving role permissions for role [" + roleName + "]");
                        }
                    }
                } finally {
                    JdbcUtils.closeResultSet(rs);
                }
            }
        } finally {
            JdbcUtils.closeStatement(ps);
        }
        return permissions;
    }

    protected Connection getConnection() throws SQLException {
        if (null == this.dataSource) {
            throw new IllegalStateException("datasource is null, no datasource configure?");
        }
        return this.dataSource.getConnection();
    }

    /* **************************************************************************** *
     *                             GETTER / SETTER.
     * **************************************************************************** */

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public String getAuthenticationQuery() {
        return authenticationQuery;
    }

    public void setAuthenticationQuery(String authenticationQuery) {
        this.authenticationQuery = authenticationQuery;
    }

    public String getUserRolesQuery() {
        return userRolesQuery;
    }

    public void setUserRolesQuery(String userRolesQuery) {
        this.userRolesQuery = userRolesQuery;
    }

    public String getUserPermissionsQuery() {
        return userPermissionsQuery;
    }

    public void setUserPermissionsQuery(String userPermissionsQuery) {
        this.userPermissionsQuery = userPermissionsQuery;
    }

    public String getRolePermissionsQuery() {
        return rolePermissionsQuery;
    }

    public void setRolePermissionsQuery(String rolePermissionsQuery) {
        this.rolePermissionsQuery = rolePermissionsQuery;
    }

    public boolean isUserPermissionsLookupEnabled() {
        return userPermissionsLookupEnabled;
    }

    public void setUserPermissionsLookupEnabled(boolean userPermissionsLookupEnabled) {
        this.userPermissionsLookupEnabled = userPermissionsLookupEnabled;
    }

    public boolean isRolePermissionsLookupEnabled() {
        return rolePermissionsLookupEnabled;
    }

    public void setRolePermissionsLookupEnabled(boolean rolePermissionsLookupEnabled) {
        this.rolePermissionsLookupEnabled = rolePermissionsLookupEnabled;
    }

    public SaltStyle getSaltStyle() {
        return saltStyle;
    }

    public void setSaltStyle(SaltStyle saltStyle) {
        this.saltStyle = saltStyle;
    }

    public String getSystemAdminUsername() {
        return systemAdminUsername;
    }

    public void setSystemAdminUsername(String systemAdminUsername) {
        this.systemAdminUsername = systemAdminUsername;
    }
}
