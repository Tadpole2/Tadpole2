package org.ponly.web.servlet;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.IOException;

import static org.ponly.common.util.Barcode.encodeToEAN13;
import static org.ponly.common.util.Barcode.encodeToQRCode;

/**
 * 条码生成
 *
 * @author vacoor
 */
public class BarcodeServlet extends HttpServlet {
    public static final String QR_CODE = "qrcode";
    public static final String EAN_13 = "ean-13";

    public static final String IMAGE_FORMAT_KEY = "imageFormat";    // 条码图片格式
    public static final String CONTENT_PREFIX_KEY = "contentPrefix";// 条码内容前缀
    public static final String CONTENT_PARAM_KEY = "contentParam";  // 条码内容参数
    // fixed
    public static final String FIXED_BARCODE_KEY = "barcode";       // 固定条码类型
    public static final String FIXED_WIDTH_KEY = "width";           // 固定条码宽度
    public static final String FIXED_HEIGHT_KEY = "height";         // 固定条码高度
    // dynamic
    public static final String BARCODE_PARAM_KEY = "barcodeParam";  // 条码类型参数
    public static final String WIDTH_PARAM_KEY = "widthParam";      // 条码宽度参数
    public static final String HEIGHT_PARAM_KEY = "heightParam";    // 条码高度参数

    public static final String DEFAULT_IMAGE_FORMAT = "png";
    public static final String DEFAULT_BARCODE = EAN_13;
    public static final int DEFAULT_WIDTH = 230;
    public static final int DEFAULT_HEIGHT = 230;
    public static final String DEFAULT_CONTENT_PARAM = "content";

    private String imageFormat;
    private String contentPrefix;
    private String contentParam;

    private String fixedBarcode;
    private Integer fixedWidth;
    private Integer fixedHeight;

    private String barcodeParam;
    private String widthParam;
    private String heightParam;

    @Override
    public void init() throws ServletException {
        super.init();
        // 图片格式, 内容前缀, 内容参数名
        imageFormat = getInitParameter(IMAGE_FORMAT_KEY);
        contentPrefix = getInitParameter(CONTENT_PREFIX_KEY);
        contentParam = getInitParameter(CONTENT_PARAM_KEY);

        // 条码类型, 宽度, 高度
        barcodeParam = getInitParameter(BARCODE_PARAM_KEY);
        widthParam = getInitParameter(WIDTH_PARAM_KEY);
        heightParam = getInitParameter(HEIGHT_PARAM_KEY);

        // 固定条码类型, 固定宽度, 高度
        fixedBarcode = getInitParameter(FIXED_BARCODE_KEY);
        String widthStr = getInitParameter(FIXED_WIDTH_KEY);
        String heightStr = getInitParameter(FIXED_HEIGHT_KEY);

        imageFormat = null != imageFormat ? imageFormat : DEFAULT_IMAGE_FORMAT;
        contentParam = null != contentParam ? contentParam : DEFAULT_CONTENT_PARAM;
        fixedBarcode = (null == fixedBarcode && null == barcodeParam) ? DEFAULT_BARCODE : fixedBarcode;
        fixedWidth = (null == widthStr && null == widthParam) ? DEFAULT_WIDTH : fixedWidth;
        fixedHeight = (null == heightStr && null == heightParam) ? DEFAULT_HEIGHT : fixedHeight;

        if (null != widthStr) {
            Integer w;
            try {
                w = Integer.valueOf(widthStr);
            } catch (NumberFormatException nfe) {
                throw new ServletException("illegal init-param: " + FIXED_WIDTH_KEY + ": not a positive number?");
            }
            if (1 > w) {
                throw new ServletException("illegal init-param: " + FIXED_WIDTH_KEY + ": not a positive number?");
            }
            fixedWidth = w;
        }
        if (null != heightStr) {
            Integer h;
            try {
                h = Integer.valueOf(heightStr);
            } catch (NumberFormatException nfe) {
                throw new ServletException("illegal init-param: " + FIXED_HEIGHT_KEY + ": not a positive number?");
            }
            if (1 > h) {
                throw new ServletException("illegal init-param: " + FIXED_HEIGHT_KEY + ": not a positive number?");
            }
            fixedHeight = h;
        }
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String content = req.getParameter(contentParam);
        String barcode = null != fixedBarcode ? fixedBarcode : req.getParameter(barcodeParam);
        String widthStr = null != fixedWidth ? fixedWidth + "" : req.getParameter(widthParam);
        String heightStr = null != fixedHeight ? fixedHeight + "" : req.getParameter(heightParam);
        Integer w = null;
        Integer h = null;

        // 如果宽度
        if (null != widthStr) {
            try {
                w = Integer.valueOf(widthStr);
            } catch (NumberFormatException ignore) {
                // ignore
            }
        }
        if (null != heightStr) {
            try {
                h = Integer.valueOf(heightStr);
            } catch (NumberFormatException ignore) {
                // ignore
            }
        }

        BufferedImage img = null;
        String error = "illegal_param";
        if (null != content) {
            content = null != contentPrefix ? contentPrefix + content : content;
            w = null != w && w > 0 ? w : DEFAULT_WIDTH;
            h = null != h && h > 0 ? h : DEFAULT_HEIGHT;

            try {
                if (QR_CODE.equals(barcode)) {
                    img = encodeToQRCode(content, w, h);
                } else if (EAN_13.equals(barcode)) {
                    img = encodeToEAN13(content, w, h);
                }
            } catch (Exception ex) {
                error = ex.getMessage();
                // ignore
            }
        }

        if (null == img) {
            resp.sendError(400, error);
            return;
        }

        ImageIO.write(img, imageFormat, resp.getOutputStream());
    }
}
