#ponly-license
## 文件说明
本项目核心包含两个类:
1. `LicenseKeygen` 为License生成类, 用于根据 `机器码` 生成`给定天数`的License.
2. `LicenseServlet` 为远程验证服务, 用于进行远程验证客户端传递的License是否和数据库中一致, 当前数据库使用gitool.glanway.com 数据库 PONLY.
   同时该类也提供生成服务，默认有效期3个月， 对于是否启用生成服务可以通过web.xml中设置
```
<servlet>
    <servlet-name>license</servlet-name>
    <servlet-class>org.ponly.license.LicenseServlet</servlet-class>
    <init-param>
        <param-name>generate</param-name>
        <!-- 这里设置是否允许生成 -->
        <param-value>true</param-value>
    </init-param>
</servlet>
<servlet-mapping>
    <servlet-name>license</servlet-name>
    <url-pattern>/</url-pattern>
</servlet-mapping>
```
`WARNING: 如果开启允许生成，请保证URL对外保密`

## License 生成说明
机器码： 用来区分计算机的字符串， 每个机器码会绑定一个License才能运行。
机器码的获取，一般没有授权的电脑，启动相关应用后会抛出类似以下错误
`License invalid: W1BdVVNFUi0yMDE1MTIyMEdROjQ4NWQ2MDkyNjQyNQ==:00705-8WZR1-BO1N8-NHX7F-Y7CUO-FVJL3`
其中 `W1BdVVNFUi0yMDE1MTIyMEdROjQ4NWQ2MDkyNjQyNQ==` 即为机器码, `00705-8WZR1-BO1N8-NHX7F-Y7CUO-FVJL3` 即为License
如果说没有相关信息，则需要通过`ipconfig /all`命令查看网卡地址，到服务器数据库查找(如果没有启动过查找不到)
查找是网卡地址需要使用处理后的网卡， 即如果是 `0F-00-A0-CC-EF` 则实际网卡为 `f0a0ccef` (第一位0去除).
也可直接通过以下 1 中的网卡字段直接尝试生成license.

1. 开启 `LicenseServlet` 自动生成功能, 通过 `license.html` 进行生成.
   `license.html` 就是一个简单的表单, 修改 `<form action="">` 指向对应地址.
   需要填写一下几个信息:
   用户名: 英文用于区分人员
   机器码：绑定的机器码，和网卡，主机名等信息有关，如果开启VPN, 等可能会引发改变
   网  卡：其中一个网卡地址(去0后网卡)，不可靠
   一般来讲，生成使用`用户名+机器码`, 提交表单后即可看到生成的License, 同时也会存入数据库，重启相应应用即可.
   `注意： 如果伪造网卡地址或存在虚拟网卡等，可能会造成机器码冲突，此时可以通过同一机器码多次提交表单，看生成的License是否一致, 如果一致, 则说明冲突，需要到数据库删除对应记录重新生成`

2. 使用 `LicenseKeygent` 生成
修改 LicenseKeygen 中
```java
public static void main(String[] args) throws Exception {
	// 这里是机器码
    args = new String[] {"W1BdVGhpbmtwYWQtUEM6MDUwNTZjMDAx"};
    if (args.length == 0) {
        System.err.printf("*** Usage: %s machineId%n", LicenseKeyGen.class.getCanonicalName());
        System.exit(1);
    }
    final Random r = new Random();
    // 180 为有效期 180天
    final String license = generatorKey(args[0], 180, r.nextInt(100000));
    System.out.println("ponly.key: " + license);
}
```
运行后，看到 `ponly.key: 23299-220J1-YZVQV-VR6IS-4QYDS-JL4O1` 中 `23299-220J1-YZVQV-VR6IS-4QYDS-JL4O1` 即为 license, 覆盖数据库对应字段即可

## License 验证说明
License 验证分为两种模式:
1. 在线模式
   在线模式即上述提到的需要部署 license 服务的方式， 当前已部署在 gitool.glanway.com/license
   每次验证客户端发起请求到服务器，提交 机器码和 license , 服务器从数据库中取出对应数据进行校验
2. 离线模式
   对于内网开发等没有网络的条件下，也支持离线模式，离线模式的使用，配置环境变量 JAVA_OPTS=`-Dponly.license=23299-220J1-YZVQV-VR6IS-4QYDS-JL4O1` 即可
   `一般TOMCAT 可以在 catalina.sh 中设置`
   `eclipse/idea可以在jvm参数中配置`
  其中 ponly.license 后面的是上面生成的 license.