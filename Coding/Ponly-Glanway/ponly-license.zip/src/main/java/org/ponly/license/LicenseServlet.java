package org.ponly.license;

import org.ponly.common.codec.Base64;
import org.ponly.common.util.Bytes;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import org.ponly.common.util.StringUtils;

/**
 */
public class LicenseServlet extends HttpServlet {
    // CREATE TABLE T_LICENSE(ID INT PRIMARY KEY AUTO_INCREMENT, NAME VARCHAR(255), MACHINE VARCHAR(255), HOSTNAME VARCHAR(255), ETHERNET VARCHAR(500), LICENSE VARCHAR(500));
    private static final String QUERY_LICENSE = "SELECT LICENSE FROM T_LICENSE WHERE ETHERNET LIKE ?";
    private static final String INSERT_LICENSE = "INSERT T_LICENSE(NAME, MACHINE, HOSTNAME, ETHERNET, LICENSE) VALUES(?, ?, ?, ?, ?)";
    private boolean generateLicense;

    @Override
    public void init() throws ServletException {
        super.init();
        generateLicense = "true".equals(getInitParameter("generate"));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String license = null;
        String xMachine = req.getHeader("X-MACHINE");
        String vacoor = req.getParameter("vacoor");

        if (null != vacoor) {
            xMachine = null != xMachine && !"".equals(xMachine) ? xMachine : req.getParameter("X-MACHINE");
        }

        if (null != xMachine && !"".equals(xMachine)) {
            try {
                license = doGetLicense(null, xMachine, generateLicense || null != vacoor);
            } catch (Exception ex) {
                // ignore
                ex.printStackTrace();
            }
        }

        if (null != license) {
            resp.getOutputStream().print(license);
            return;
        }
        resp.sendError(403, "UNKNOWN X-MACHINE");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        final String admin = req.getParameter("admin");
        final String name = req.getParameter("name");
        final String ethernet = req.getParameter("ethernet");
        String machine = req.getParameter("machine");

        if (!"vacoor".equals(admin)) {
            resp.sendError(400);
            return;
        }

        try {
            machine = doInternalDeleteLicense(getConnection(), ethernet, machine);
            String s = doGetLicense(name, machine, true);
            resp.getWriter().write(s);
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    protected String doGetLicense(String name, String xMachine, boolean generate) {
        String license = null;

        try {
            byte[] bytes = Base64.decode(xMachine);
            String machineId = Bytes.toString(bytes);
            int index = machineId.indexOf("[P]");

            if (0 == index) {
                index = machineId.indexOf(":");

                if (-1 < index) {
                    final String hostname = machineId.substring(3, index);
                    final List<String> ethernets = new LinkedList<String>();

                    int end = index;
                    while (end < machineId.length() && -1 < (end = machineId.indexOf("-", index + 1))) {
                        ethernets.add(machineId.substring(index + 1, end));
                        index = end;
                    }
                    if (index + 1 < machineId.length()) {
                        ethernets.add(machineId.substring(index + 1));
                    }

                    Connection conn = getConnection();

                    String[] ethernetArray = ethernets.toArray(new String[ethernets.size()]);
                    license = doInternalGetLicense(conn, hostname, ethernetArray);

                    if (null == license) {
                        license = doInternalGetDefaultLicense(conn, name, xMachine, hostname, ethernetArray, generate);
                    }
                }
            }
        } catch (Exception ex) {
            // ignore
            ex.printStackTrace();
        }
        return license;
    }

    protected static String doInternalDeleteLicense(Connection conn, String ethernet, String xMachine) throws SQLException {
        String machine = xMachine;
        final String query = "SELECT MACHINE FROM T_LICENSE WHERE ETHERNET LIKE ?";
        if (!StringUtils.hasText(machine)) {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, ethernet);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                machine = rs.getString(1);
            }
            rs.close();
            ps.close();
        }
        String sql = "DELETE FROM T_LICENSE WHERE ";
        if (StringUtils.hasText(ethernet)) {
            sql += "ETHERNET = ? ";

            if (StringUtils.hasText(xMachine)) {
                sql += "AND ";
            }
        }
        if (StringUtils.hasText(xMachine)) {
            sql += "MACHINE = ? ";
        }

        PreparedStatement ps = conn.prepareStatement(sql);
        try {
            int i = 1;
            if (StringUtils.hasText(ethernet)) {
                ps.setString(i++, ethernet);
            }
            if (StringUtils.hasText(xMachine)) {
                ps.setString(i++, xMachine);
            }
            ps.executeUpdate();
            return machine;
        } finally {
            ps.close();
        }
    }

    protected static String doInternalGetLicense(Connection conn, String hostname, String[] ethernet) throws SQLException {
        conn.setReadOnly(true);
        PreparedStatement ps = conn.prepareStatement(QUERY_LICENSE);
        ResultSet rs;

        String license = null;
        for (int i = 0; i < ethernet.length; i++) {
            ps.clearParameters();
            ps.setString(1, '%' + ethernet[i] + '%');
            rs = ps.executeQuery();

            if (rs.next()) {
                license = rs.getString(1);
                license = null != license ? license : "";
                break;
            }

            rs.close();
        }

        ps.close();

        return license;
    }

    protected String doInternalGetDefaultLicense(Connection conn, String name, String xMachine, String hostname, String[] ethernets, boolean generateLicense) throws SQLException {
        String license = null;
        if (generateLicense) {
            Random random = new Random();
            license = LicenseKeyGen.generatorKey(xMachine, 3 * 30, random.nextInt(100000));
        }
        StringBuilder mac = new StringBuilder();

        for (int i = 0; i < ethernets.length; i++) {
            if (0 < i) {
                mac.append(",");
            }
            mac.append(ethernets[i]);
        }

        conn.setReadOnly(false);
        PreparedStatement ps = conn.prepareStatement(INSERT_LICENSE);
        if (StringUtils.hasText(name)) {
            ps.setString(1, name);
        } else {
            ps.setNull(1, Types.NULL);
        }
        ps.setString(2, xMachine);
        ps.setString(3, hostname);
        ps.setString(4, mac.toString());
        ps.setString(5, license);

        int i = ps.executeUpdate();
        if (1 > i) {
            // TODO insert fail
        }

        ps.close();

        if (!conn.getAutoCommit()) {
            conn.commit();
        }
        return license;
    }

    protected Connection getConnection() throws SQLException {
        // com.mysql.jdbc.Driver
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        String url = "jdbc:mysql://121.40.102.225:3306/PONLY?characterEncoding=UTF-8";
        String user = "ponly";
        String password = "ponly@glanway";
        return DriverManager.getConnection(url, user, password);
    }
}
