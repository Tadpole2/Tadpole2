package org.ponly.license;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAKeyGenParameterSpec;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Random;
import java.util.zip.CRC32;
import org.ponly.common.codec.Base64;
import org.ponly.common.util.Bytes;

/**
 */
 /*
 License 信息包含如下内容
0. 机器码/用户名
1. 产品类型
2. 产品版本
3. 生成时间
4. 有效天数

前提：
   生成 RSA 公私钥对， 私钥生成 License 方保存， 公钥验证方保存。

License生成算法:
   1. 将产品类型，产品版本，生成日期，有效天数按照顺序组合为字节数组 bytes
   2. 生成随机数 random
   3. 计算 机器码/用户名(暂取主机名+MAC地址) ,随机数r, 字节数组 bytes 的crc32校验和
   4. 将 bytes + crc32 校验和 组成新的bytes字节数组 (确保完成性没有被修改)
   5. 使用 RSA 算法(非对称加密)的私钥 计算 bytes 字节数组的值 key
   6. 将 key 转换为 36 进制字符并按照5个一组分割为"XXXXX-XXXXX-..."形式即为 License key

License验证算法:
   验证流程:
     1.验证本地License文件是否有效
     2.如果无效，则向服务器请求最新的License验证是否有效
     3.如果无效，则抛出错误信息
   验证算法：
     1. 将 Licnese Key 解组并还原为10进制 key
     2. 校验并解密key, 还原为原始数组 bytes
     3. 计算 bytes 的 crc32 校验和是否正确
     4. 去除 crc32 校验和 得到原始的license 信息 bytes
     5. 解析产品类型，生成日期，有效天数等信息校验
  */
abstract class LicenseKeyGen {
    private static BigInteger MOD = new BigInteger("86d1ee98953ca32058c98ef923bd23ea316e2a45e48de0913154253eac682e05ffdc75106fcf8c6eecc701dbe0309abd83bcd837be11af584457de0217d056a1e0580e9003d3bd5ee0300f0650fc4b6bb9be44b3091c70fdbb047e7889c873c9c6c30a2ab2e17727e58e92303456b0e7cff0909138a025c9fc3977d80c80d96d", 16);
    private static BigInteger PRIVATE_EXP = new BigInteger("1ea4b8c695a522aec77f88afb81fd579f5a244997e4981317f34d1025dcd90286cef7eec2d7dcf3da733d488557cb6af3cb23fb2ebd0b93a26ce91f787d222de737b289945f808bfd45910d9a7d5ad204fd1087dcfbdaf7c25009065689912ba3a34fad3e000c65eb0c8c8265455c2702521e1a3c03b5f067ce34949c6f64f41", 16);

    /**
     * @param s
     * @param i
     * @param bytes
     * @return
     */
    public static short getCRC32(String s, int i, byte bytes[]) {
        CRC32 crc32 = new CRC32();
        if (s != null) {
            for (int j = 0; j < s.length(); j++) {
                char c = s.charAt(j);
                crc32.update(c);
            }
        }
        crc32.update(i);
        crc32.update(i >> 8);
        crc32.update(i >> 16);
        crc32.update(i >> 24);
        for (int k = 0; k < bytes.length - 2; k++) {
            byte byte0 = bytes[k];
            crc32.update(byte0);
        }
        return (short) (int) crc32.getValue();
    }

    /**
     * @param biginteger
     * @return String
     */
    public static String encodeGroups(BigInteger biginteger) {
        BigInteger beginner1 = BigInteger.valueOf(0x39aa400L);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; biginteger.compareTo(BigInteger.ZERO) != 0; i++) {
            int j = biginteger.mod(beginner1).intValue();
            String s1 = encodeGroup(j);
            if (i > 0) {
                sb.append("-");
            }
            sb.append(s1);
            biginteger = biginteger.divide(beginner1);
        }
        return sb.toString();
    }

    /**
     * @param i
     * @return
     */
    public static String encodeGroup(int i) {
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < 5; j++) {
            int k = i % 36;
            char c;
            if (k < 10) {
                c = (char) (48 + k);
            } else {
                c = (char) ((65 + k) - 10);
            }
            sb.append(c);
            i /= 36;
        }
        return sb.toString();
    }

    /**
     * @param name
     * @param days
     * @param id
     * @return
     */
    public static String generatorKey(String name, int days, int id) {
        id %= 100000;
        byte bkey[] = new byte[12];
        bkey[0] = (byte) 1; // Product type: IntelliJ IDEA is 1
        bkey[1] = 13; // version

        Date d = new Date();

        // 时间
        long ld = (d.getTime() >> 16);  // 取出高 48 bit
        // 取出中间32位
        bkey[2] = (byte) (ld & 255);    // 8 bit
        bkey[3] = (byte) ((ld >> 8) & 0xFF); // 8bit
        bkey[4] = (byte) ((ld >> 16) & 0xFF);    // 8bit
        bkey[5] = (byte) ((ld >> 24) & 0xFF);    // 8 bit

        days &= 0xFFFF; // 65535

        bkey[6] = (byte) (days & 0xFF);
        bkey[7] = (byte) ((days >> 8) & 0xFF);

        bkey[8] = 105;
        bkey[9] = -59;
        bkey[10] = 0;
        bkey[11] = 0;
        int w = getCRC32(name, id % 100000, bkey);
        bkey[10] = (byte) (w & 0xFF);
        bkey[11] = (byte) ((w >> 8) & 0xFF);
        BigInteger k0 = new BigInteger(bkey);

        BigInteger exp = new BigInteger("89126272330128007543578052027888001981", 10);
        BigInteger mod = new BigInteger("86f71688cdd2612ca117d1f54bdae029", 16);
        BigInteger k1 = k0.modPow(exp, mod);
//        BigInteger k1 = k0.modPow(PRIVATE_EXP, MOD);
        String customerId = Integer.toString(id);
        String sz = "0";
        while (customerId.length() != 5) {
            customerId = sz.concat(customerId);
        }
        customerId = customerId.concat("-");

        String s1 = encodeGroups(k1);

        customerId = customerId.concat(s1);
        return customerId;
    }


    private static String __getMachineId() {
        String hostname = null;
        String ethernet = null;
        InetAddress localhost = null;
        try {
            localhost = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            // ignore
        }

        try {
            // 获取 hostname 和 网卡地址
            if (null == localhost) {
                hostname = "UNKNOWN";
            } else {
                hostname = localhost.getHostName();
                NetworkInterface ni = NetworkInterface.getByInetAddress(localhost);
                if (!ni.isLoopback() && !ni.isVirtual() && !ni.isPointToPoint() && null != ni.getHardwareAddress()) {
                    byte[] bytes = ni.getHardwareAddress();
                    StringBuilder hex = new StringBuilder(bytes.length << 1);
                    for (byte aByte : bytes) {
                        hex.append(Integer.toHexString(0xff & aByte));
                    }
                    ethernet = hex.toString();
                }
            }

            // 如果获取 localhost 网卡失败, 则获取所有网卡地址, 以 "-" 分割
            if (null == ethernet) {
                StringBuilder buff = new StringBuilder();
                Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
                while (nis.hasMoreElements()) {
                    NetworkInterface ni = nis.nextElement();
                    if (!ni.isLoopback() && !ni.isVirtual() && !ni.isPointToPoint() && null != ni.getHardwareAddress()) {
                        byte[] bytes = ni.getHardwareAddress();
                        for (byte aByte : bytes) {
                            buff.append(Integer.toHexString(0xff & aByte));
                        }
                        buff.append("-");
                    }
                }
                if (1 < buff.length()) {
                    ethernet = buff.deleteCharAt(buff.length() - 1).toString();
                }
            }

            if (null == ethernet) {
                throw new IllegalStateException("invalid client");
            }
            return Base64.encodeToString(("[P]" + hostname + ":" + ethernet).getBytes(Charset.forName("UTF-8")));
        } catch (SocketException ex) {
            // throw
            throw new IllegalStateException("");
        }
    }

    private static BigInteger __decodeGroups(String encoded) throws IllegalStateException {
        BigInteger orig = BigInteger.ZERO;
        BigInteger max = BigInteger.valueOf(60466176L);
        int i = encoded.length();
        while (i >= 0) {
            int j = encoded.lastIndexOf('-', i - 1) + 1;

            String str = encoded.substring(j, i);
            int k = __decodeGroup(str);
            orig = orig.multiply(max);
            orig = orig.add(BigInteger.valueOf(k));

            i = j - 1;
        }
        return orig;
    }

    private static int __decodeGroup(String grouped) throws IllegalStateException {
        if (grouped.length() != 5) {
            throw new IllegalStateException();
        }
        int i = 36;
        int j = 0;
        for (int k = grouped.length() - 1; k >= 0; k--) {
            int m = grouped.charAt(k);
            int n;
            if ((48 <= m) && (m <= 57)) {
                n = m - 48;
            } else if ((65 <= m) && (m <= 90)) {
                n = m - 65 + 10;
            } else {
                throw new IllegalStateException();
            }

            j *= 36;
            j += n;
        }
        return j;
    }

    private static short __calculateCRC32(String mid, int i, byte[] bytes) {
        CRC32 crc32 = new CRC32();
        if (mid != null) {
            for (int j = 0; j < mid.length(); j++) {
                crc32.update(mid.charAt(j));
            }
        }
        crc32.update(i);
        crc32.update(i >> 8);
        crc32.update(i >> 16);
        crc32.update(i >> 24);
        for (int j = 0; j < bytes.length - 2; j++) {
            crc32.update(bytes[j]);
        }
        return (short) (int) crc32.getValue();
    }

    private static void decodeLicense(final String machineId, final String fullLicense) {
        final BigInteger PUBLIC_MOD = new BigInteger("86f71688cdd2612ca117d1f54bdae029", 16);
        final BigInteger PUBLIC_EXP = RSAKeyGenParameterSpec.F4;
        String license = fullLicense;
        String message = "License invalid: " + machineId + ":" + fullLicense;
        int i = fullLicense.indexOf("-");
        int customerId = -1;
        // 用户类型+授权类型+产品类型+产品版本+生成时间+过期时间
        if (5 == i) {
            customerId = Integer.parseInt(fullLicense.substring(0, i));
            license = fullLicense.substring(i + 1);
        }

        BigInteger lic = null;
        try {
            lic = __decodeGroups(license).modPow(PUBLIC_EXP, PUBLIC_MOD);
        } catch (IllegalStateException ise) {
            throw new IllegalStateException(message);
        }
        byte[] bytes = lic.toByteArray();
        short checksum = __calculateCRC32(machineId, customerId, bytes);

        // 校验和无效
        if (bytes[10] != (byte) (checksum & 0xff) || bytes[11] != (byte) ((checksum >> 8) & 0xff)) {
            throw new IllegalStateException(message);
        }

        int licenseType = (bytes[0] >> 4) & 0xf;        // license 类型
        int productId = (bytes[0] & 0xf);               // 产品id
        int majorVersion = bytes[1] & 0xf;              // 大版本
        int minorVersion = (bytes[1] >> 4) & 0xf;       // 小版本
        long generationTime = (bytes[2] & 0xffL) + ((bytes[3] & 0xFF) << 8) + ((bytes[4] & 0xFF) << 16) + ((bytes[5] & 0xFF) << 24) << 16;
        int days = (bytes[6] & 0xFF) + ((bytes[7] & 0xFF) << 8);
        Date expirationDate = 0 != days ? new Date(generationTime + days * 24L * 60L * 60L * 1000L) : null;
        Date now = new Date();

        System.out.println("=======================================");
        System.out.println("Machine: " + machineId);
        System.out.println("License: " + license);
        System.out.println("生成时间:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(generationTime)));
        System.out.println("有效期:" + days + "天");
        System.out.println("过期时间:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(expirationDate));
        System.out.println("=======================================");

        // 无效
        if (generationTime > now.getTime()) {
            System.clearProperty("ponly.license");

            System.out.println("已经过期");
//            throw new IllegalStateException(message);
        }

        // 如果是会过期的
        if (null != expirationDate) {
            // 如果生成时间大于当前时间或过期时间小于当前时间, 则已经过期
            if (expirationDate.getTime() < now.getTime()) {
                System.clearProperty("ponly.license");

                throw new IllegalStateException(message);
            } else if (now.getTime() + 15 * 24L * 60L * 60L * 1000L > expirationDate.getTime()) {
                // 如果 15 天以内将过期
                /*
                String newLicense = __fetchLicense(machineId);
                if (null != newLicense && !"".equals(newLicense)) {
                    fullLicense = newLicense;
                }
                */
                System.out.println("将要过期.");
            }
        }
        System.setProperty("ponly.license", fullLicense);
    }

    private LicenseKeyGen() {
    }

    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException, UnsupportedEncodingException {
//        String s = Base64.encodeToString("[P]UNKNOWN:0163ed15b2".getBytes("UTF-8"));
//        args = new String[] {s};
         args = new String[] {"W1BdVGhpbmtwYWQtUEM6MDUwNTZjMDAx"};
        if (args.length == 0) {
            System.err.printf("*** Usage: %s machineId%n", LicenseKeyGen.class.getCanonicalName());
            System.exit(1);
        }
        final Random r = new Random();
        final String license = generatorKey(args[0], 180, r.nextInt(100000));
        System.out.println("ponly.key: " + license);
        /*
        decodeLicense(args[0], "05403-8CTYL-V8CSV-AZCJD-PKBFV-OQIM4");//license);
        System.out.println("@echo off");
        System.out.println("md %userprofile%\\.ponly");
        System.out.println("echo " + license + ">%userprofile%\\.ponly\\ponly.key");
        */
    }
}





















